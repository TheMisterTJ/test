package com.google.android.gms.internal;

@zzhb
public class zzhc {
    public final zzib zzIH;
    public final zzbo zzII;
    public final zzhl zzIJ;
    public final zzek zzIK;
    public final zzfy zzIL;
    public final zzie zzIM;
    public final zzhn zzIN;
    public final zzhm zzIO;
    public final zzhh zzIP;

    zzhc(zzib com_google_android_gms_internal_zzib, zzbo com_google_android_gms_internal_zzbo, zzhl com_google_android_gms_internal_zzhl, zzek com_google_android_gms_internal_zzek, zzfy com_google_android_gms_internal_zzfy, zzie com_google_android_gms_internal_zzie, zzhn com_google_android_gms_internal_zzhn, zzhm com_google_android_gms_internal_zzhm, zzhh com_google_android_gms_internal_zzhh) {
        this.zzIH = com_google_android_gms_internal_zzib;
        this.zzII = com_google_android_gms_internal_zzbo;
        this.zzIJ = com_google_android_gms_internal_zzhl;
        this.zzIK = com_google_android_gms_internal_zzek;
        this.zzIL = com_google_android_gms_internal_zzfy;
        this.zzIM = com_google_android_gms_internal_zzie;
        this.zzIN = com_google_android_gms_internal_zzhn;
        this.zzIO = com_google_android_gms_internal_zzhm;
        this.zzIP = com_google_android_gms_internal_zzhh;
    }

    public static zzhc zzgA() {
        return new zzhc(new zzic(), new zzbn(), new zzho(), new zzel(), new zzfx(), new zzid(), new zzhq(), new zzhp(), null);
    }
}
