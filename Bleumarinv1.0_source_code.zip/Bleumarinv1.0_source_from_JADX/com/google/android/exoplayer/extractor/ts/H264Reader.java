package com.google.android.exoplayer.extractor.ts;

import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.extractor.TrackOutput;
import com.google.android.exoplayer.util.CodecSpecificDataUtil;
import com.google.android.exoplayer.util.CodecSpecificDataUtil.SpsData;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.NalUnitUtil;
import com.google.android.exoplayer.util.ParsableBitArray;
import com.google.android.exoplayer.util.ParsableByteArray;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class H264Reader extends ElementaryStreamReader {
    private static final int FRAME_TYPE_ALL_I = 7;
    private static final int FRAME_TYPE_I = 2;
    private static final int NAL_UNIT_TYPE_AUD = 9;
    private static final int NAL_UNIT_TYPE_IDR = 5;
    private static final int NAL_UNIT_TYPE_IFR = 1;
    private static final int NAL_UNIT_TYPE_PPS = 8;
    private static final int NAL_UNIT_TYPE_SEI = 6;
    private static final int NAL_UNIT_TYPE_SPS = 7;
    private boolean foundFirstSample;
    private boolean hasOutputFormat;
    private final IfrParserBuffer ifrParserBuffer;
    private boolean isKeyframe;
    private long pesTimeUs;
    private final NalUnitTargetBuffer pps;
    private final boolean[] prefixFlags = new boolean[3];
    private long samplePosition;
    private long sampleTimeUs;
    private final NalUnitTargetBuffer sei;
    private final SeiReader seiReader;
    private final ParsableByteArray seiWrapper;
    private final NalUnitTargetBuffer sps;
    private long totalBytesWritten;

    private static final class IfrParserBuffer {
        private static final int DEFAULT_BUFFER_SIZE = 128;
        private static final int NOT_SET = -1;
        private byte[] ifrData = new byte[128];
        private int ifrLength;
        private boolean isFilling;
        private final ParsableBitArray scratchSliceType = new ParsableBitArray(this.ifrData);
        private int sliceType;

        public IfrParserBuffer() {
            reset();
        }

        public final void reset() {
            this.isFilling = false;
            this.ifrLength = 0;
            this.sliceType = -1;
        }

        public final boolean isCompleted() {
            return this.sliceType != -1;
        }

        public final void startNalUnit(int i) {
            if (i == 1) {
                reset();
                this.isFilling = true;
            }
        }

        public final void appendToNalUnit(byte[] bArr, int i, int i2) {
            if (this.isFilling) {
                int i3 = i2 - i;
                if (this.ifrData.length < this.ifrLength + i3) {
                    this.ifrData = Arrays.copyOf(this.ifrData, (this.ifrLength + i3) * 2);
                }
                System.arraycopy(bArr, i, this.ifrData, this.ifrLength, i3);
                this.ifrLength = i3 + this.ifrLength;
                this.scratchSliceType.reset(this.ifrData, this.ifrLength);
                this.scratchSliceType.skipBits(8);
                i3 = this.scratchSliceType.peekExpGolombCodedNumLength();
                if (i3 != -1 && i3 <= this.scratchSliceType.bitsLeft()) {
                    this.scratchSliceType.skipBits(i3);
                    i3 = this.scratchSliceType.peekExpGolombCodedNumLength();
                    if (i3 != -1 && i3 <= this.scratchSliceType.bitsLeft()) {
                        this.sliceType = this.scratchSliceType.readUnsignedExpGolombCodedInt();
                        this.isFilling = false;
                    }
                }
            }
        }

        public final int getSliceType() {
            return this.sliceType;
        }
    }

    public H264Reader(TrackOutput trackOutput, SeiReader seiReader, boolean z) {
        super(trackOutput);
        this.seiReader = seiReader;
        this.ifrParserBuffer = z ? new IfrParserBuffer() : null;
        this.sps = new NalUnitTargetBuffer(7, 128);
        this.pps = new NalUnitTargetBuffer(8, 128);
        this.sei = new NalUnitTargetBuffer(6, 128);
        this.seiWrapper = new ParsableByteArray();
    }

    public final void seek() {
        NalUnitUtil.clearPrefixFlags(this.prefixFlags);
        this.sps.reset();
        this.pps.reset();
        this.sei.reset();
        if (this.ifrParserBuffer != null) {
            this.ifrParserBuffer.reset();
        }
        this.foundFirstSample = false;
        this.totalBytesWritten = 0;
    }

    public final void packetStarted(long j, boolean z) {
        this.pesTimeUs = j;
    }

    public final void consume(ParsableByteArray parsableByteArray) {
        if (parsableByteArray.bytesLeft() > 0) {
            int position = parsableByteArray.getPosition();
            int limit = parsableByteArray.limit();
            byte[] bArr = parsableByteArray.data;
            this.totalBytesWritten += (long) parsableByteArray.bytesLeft();
            this.output.sampleData(parsableByteArray, parsableByteArray.bytesLeft());
            while (true) {
                int findNalUnit = NalUnitUtil.findNalUnit(bArr, position, limit, this.prefixFlags);
                if (findNalUnit == limit) {
                    feedNalUnitTargetBuffersData(bArr, position, limit);
                    return;
                }
                int nalUnitType = NalUnitUtil.getNalUnitType(bArr, findNalUnit);
                int i = findNalUnit - position;
                if (i > 0) {
                    feedNalUnitTargetBuffersData(bArr, position, findNalUnit);
                }
                switch (nalUnitType) {
                    case 5:
                        this.isKeyframe = true;
                        break;
                    case 9:
                        int i2 = limit - findNalUnit;
                        if (this.foundFirstSample) {
                            if (this.ifrParserBuffer != null && this.ifrParserBuffer.isCompleted()) {
                                position = this.ifrParserBuffer.getSliceType();
                                boolean z = this.isKeyframe;
                                position = (position == 2 || position == 7) ? 1 : 0;
                                this.isKeyframe = position | z;
                                this.ifrParserBuffer.reset();
                            }
                            if (this.isKeyframe && !this.hasOutputFormat && this.sps.isCompleted() && this.pps.isCompleted()) {
                                this.output.format(parseMediaFormat(this.sps, this.pps));
                                this.hasOutputFormat = true;
                            }
                            this.output.sampleMetadata(this.sampleTimeUs, this.isKeyframe ? 1 : 0, ((int) (this.totalBytesWritten - this.samplePosition)) - i2, i2, null);
                        }
                        this.foundFirstSample = true;
                        this.samplePosition = this.totalBytesWritten - ((long) i2);
                        this.sampleTimeUs = this.pesTimeUs;
                        this.isKeyframe = false;
                        break;
                }
                feedNalUnitTargetEnd(this.pesTimeUs, i < 0 ? -i : 0);
                feedNalUnitTargetBuffersStart(nalUnitType);
                position = findNalUnit + 3;
            }
        }
    }

    public final void packetFinished() {
    }

    private void feedNalUnitTargetBuffersStart(int i) {
        if (this.ifrParserBuffer != null) {
            this.ifrParserBuffer.startNalUnit(i);
        }
        if (!this.hasOutputFormat) {
            this.sps.startNalUnit(i);
            this.pps.startNalUnit(i);
        }
        this.sei.startNalUnit(i);
    }

    private void feedNalUnitTargetBuffersData(byte[] bArr, int i, int i2) {
        if (this.ifrParserBuffer != null) {
            this.ifrParserBuffer.appendToNalUnit(bArr, i, i2);
        }
        if (!this.hasOutputFormat) {
            this.sps.appendToNalUnit(bArr, i, i2);
            this.pps.appendToNalUnit(bArr, i, i2);
        }
        this.sei.appendToNalUnit(bArr, i, i2);
    }

    private void feedNalUnitTargetEnd(long j, int i) {
        this.sps.endNalUnit(i);
        this.pps.endNalUnit(i);
        if (this.sei.endNalUnit(i)) {
            this.seiWrapper.reset(this.sei.nalData, NalUnitUtil.unescapeStream(this.sei.nalData, this.sei.nalLength));
            this.seiWrapper.setPosition(4);
            this.seiReader.consume(j, this.seiWrapper);
        }
    }

    private static MediaFormat parseMediaFormat(NalUnitTargetBuffer nalUnitTargetBuffer, NalUnitTargetBuffer nalUnitTargetBuffer2) {
        List arrayList = new ArrayList();
        arrayList.add(Arrays.copyOf(nalUnitTargetBuffer.nalData, nalUnitTargetBuffer.nalLength));
        arrayList.add(Arrays.copyOf(nalUnitTargetBuffer2.nalData, nalUnitTargetBuffer2.nalLength));
        NalUnitUtil.unescapeStream(nalUnitTargetBuffer.nalData, nalUnitTargetBuffer.nalLength);
        ParsableBitArray parsableBitArray = new ParsableBitArray(nalUnitTargetBuffer.nalData);
        parsableBitArray.skipBits(32);
        SpsData parseSpsNalUnit = CodecSpecificDataUtil.parseSpsNalUnit(parsableBitArray);
        return MediaFormat.createVideoFormat(null, MimeTypes.VIDEO_H264, -1, -1, -1, parseSpsNalUnit.width, parseSpsNalUnit.height, arrayList, -1, parseSpsNalUnit.pixelWidthAspectRatio);
    }
}
