package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zzhn.zza;

@zzhb
public final class zzhq implements zzhn {
    public final zza zzF(Context context) {
        return null;
    }
}
