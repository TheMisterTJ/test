package com.google.android.exoplayer.upstream;

import android.text.TextUtils;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.Predicate;
import com.google.android.exoplayer.util.Util;
import com.mopub.common.AdType;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface HttpDataSource extends UriDataSource {
    public static final Predicate<String> REJECT_PAYWALL_TYPES = new C19341();

    static class C19341 implements Predicate<String> {
        C19341() {
        }

        public final boolean evaluate(String str) {
            String toLowerInvariant = Util.toLowerInvariant(str);
            return (TextUtils.isEmpty(toLowerInvariant) || ((toLowerInvariant.contains(MimeTypes.BASE_TYPE_TEXT) && !toLowerInvariant.contains(MimeTypes.TEXT_VTT)) || toLowerInvariant.contains(AdType.HTML) || toLowerInvariant.contains("xml"))) ? false : true;
        }
    }

    public static class HttpDataSourceException extends IOException {
        public final DataSpec dataSpec;

        public HttpDataSourceException(DataSpec dataSpec) {
            this.dataSpec = dataSpec;
        }

        public HttpDataSourceException(String str, DataSpec dataSpec) {
            super(str);
            this.dataSpec = dataSpec;
        }

        public HttpDataSourceException(IOException iOException, DataSpec dataSpec) {
            super(iOException);
            this.dataSpec = dataSpec;
        }

        public HttpDataSourceException(String str, IOException iOException, DataSpec dataSpec) {
            super(str, iOException);
            this.dataSpec = dataSpec;
        }
    }

    public static final class InvalidContentTypeException extends HttpDataSourceException {
        public final String contentType;

        public InvalidContentTypeException(String str, DataSpec dataSpec) {
            super("Invalid content type: " + str, dataSpec);
            this.contentType = str;
        }
    }

    public static final class InvalidResponseCodeException extends HttpDataSourceException {
        public final Map<String, List<String>> headerFields;
        public final int responseCode;

        public InvalidResponseCodeException(int i, Map<String, List<String>> map, DataSpec dataSpec) {
            super("Response code: " + i, dataSpec);
            this.responseCode = i;
            this.headerFields = map;
        }
    }

    void clearAllRequestProperties();

    void clearRequestProperty(String str);

    void close() throws HttpDataSourceException;

    Map<String, List<String>> getResponseHeaders();

    long open(DataSpec dataSpec) throws HttpDataSourceException;

    int read(byte[] bArr, int i, int i2) throws HttpDataSourceException;

    void setRequestProperty(String str, String str2);
}
