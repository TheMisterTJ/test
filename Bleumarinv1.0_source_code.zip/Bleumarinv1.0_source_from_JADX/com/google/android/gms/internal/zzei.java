package com.google.android.gms.internal;

public interface zzei extends zzeh {
    void zzew();
}
