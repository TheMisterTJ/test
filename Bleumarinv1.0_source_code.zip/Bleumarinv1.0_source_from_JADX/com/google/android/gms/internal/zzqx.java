package com.google.android.gms.internal;

import com.google.android.gms.plus.zzb;

public final class zzqx implements zzb {
}
