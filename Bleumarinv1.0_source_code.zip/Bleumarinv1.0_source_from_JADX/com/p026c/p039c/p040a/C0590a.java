package com.p026c.p039c.p040a;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import com.mopub.volley.DefaultRetryPolicy;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* compiled from: AnimatorProxy */
public final class C0590a extends Animation {
    public static final boolean f1557a = (Integer.valueOf(VERSION.SDK).intValue() < 11);
    private static final WeakHashMap<View, C0590a> f1558n = new WeakHashMap();
    public final WeakReference<View> f1559b;
    public boolean f1560c;
    public float f1561d = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
    public float f1562e;
    public float f1563f;
    public float f1564g;
    public float f1565h;
    public float f1566i;
    public float f1567j = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
    public float f1568k = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
    public float f1569l;
    public float f1570m;
    private final Camera f1571o = new Camera();
    private final RectF f1572p = new RectF();
    private final RectF f1573q = new RectF();
    private final Matrix f1574r = new Matrix();

    public static C0590a m1344a(View view) {
        Animation animation = (C0590a) f1558n.get(view);
        if (animation != null && animation == view.getAnimation()) {
            return animation;
        }
        C0590a c0590a = new C0590a(view);
        f1558n.put(view, c0590a);
        return c0590a;
    }

    private C0590a(View view) {
        setDuration(0);
        setFillAfter(true);
        view.setAnimation(this);
        this.f1559b = new WeakReference(view);
    }

    public final void m1348a(float f) {
        if (this.f1569l != f) {
            m1347a();
            this.f1569l = f;
            m1349b();
        }
    }

    public final void m1350b(float f) {
        if (this.f1570m != f) {
            m1347a();
            this.f1570m = f;
            m1349b();
        }
    }

    public final void m1347a() {
        View view = (View) this.f1559b.get();
        if (view != null) {
            m1346a(this.f1572p, view);
        }
    }

    public final void m1349b() {
        View view = (View) this.f1559b.get();
        if (view != null && view.getParent() != null) {
            RectF rectF = this.f1573q;
            m1346a(rectF, view);
            rectF.union(this.f1572p);
            ((View) view.getParent()).invalidate((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
        }
    }

    private void m1346a(RectF rectF, View view) {
        rectF.set(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
        Matrix matrix = this.f1574r;
        matrix.reset();
        m1345a(matrix, view);
        this.f1574r.mapRect(rectF);
        rectF.offset((float) view.getLeft(), (float) view.getTop());
        if (rectF.right < rectF.left) {
            float f = rectF.right;
            rectF.right = rectF.left;
            rectF.left = f;
        }
        if (rectF.bottom < rectF.top) {
            f = rectF.top;
            rectF.top = rectF.bottom;
            rectF.bottom = f;
        }
    }

    private void m1345a(Matrix matrix, View view) {
        float width = (float) view.getWidth();
        float height = (float) view.getHeight();
        boolean z = this.f1560c;
        float f = z ? this.f1562e : width / 2.0f;
        float f2 = z ? this.f1563f : height / 2.0f;
        float f3 = this.f1564g;
        float f4 = this.f1565h;
        float f5 = this.f1566i;
        if (!(f3 == 0.0f && f4 == 0.0f && f5 == 0.0f)) {
            Camera camera = this.f1571o;
            camera.save();
            camera.rotateX(f3);
            camera.rotateY(f4);
            camera.rotateZ(-f5);
            camera.getMatrix(matrix);
            camera.restore();
            matrix.preTranslate(-f, -f2);
            matrix.postTranslate(f, f2);
        }
        f3 = this.f1567j;
        f4 = this.f1568k;
        if (!(f3 == DefaultRetryPolicy.DEFAULT_BACKOFF_MULT && f4 == DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)) {
            matrix.postScale(f3, f4);
            matrix.postTranslate((-(f / width)) * ((f3 * width) - width), (-(f2 / height)) * ((f4 * height) - height));
        }
        matrix.postTranslate(this.f1569l, this.f1570m);
    }

    protected final void applyTransformation(float f, Transformation transformation) {
        View view = (View) this.f1559b.get();
        if (view != null) {
            transformation.setAlpha(this.f1561d);
            m1345a(transformation.getMatrix(), view);
        }
    }
}
