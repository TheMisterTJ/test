package com.google.android.exoplayer.hls;

import android.os.Handler;
import android.os.SystemClock;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.LoadControl;
import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.MediaFormatHolder;
import com.google.android.exoplayer.SampleHolder;
import com.google.android.exoplayer.SampleSource;
import com.google.android.exoplayer.SampleSource.SampleSourceReader;
import com.google.android.exoplayer.chunk.BaseChunkSampleSourceEventListener;
import com.google.android.exoplayer.chunk.Chunk;
import com.google.android.exoplayer.chunk.ChunkOperationHolder;
import com.google.android.exoplayer.chunk.Format;
import com.google.android.exoplayer.upstream.Loader;
import com.google.android.exoplayer.upstream.Loader.Callback;
import com.google.android.exoplayer.upstream.Loader.Loadable;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.MimeTypes;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;

public final class HlsSampleSource implements SampleSource, SampleSourceReader, Callback {
    public static final int DEFAULT_MIN_LOADABLE_RETRY_COUNT = 3;
    private static final long NO_RESET_PENDING = Long.MIN_VALUE;
    private static final int PRIMARY_TYPE_AUDIO = 2;
    private static final int PRIMARY_TYPE_NONE = 0;
    private static final int PRIMARY_TYPE_TEXT = 1;
    private static final int PRIMARY_TYPE_VIDEO = 3;
    private final int bufferSizeContribution;
    private final ChunkOperationHolder chunkOperationHolder;
    private final HlsChunkSource chunkSource;
    private int[] chunkSourceTrackIndices;
    private long currentLoadStartTimeMs;
    private Chunk currentLoadable;
    private IOException currentLoadableException;
    private int currentLoadableExceptionCount;
    private long currentLoadableExceptionTimestamp;
    private TsChunk currentTsLoadable;
    private Format downstreamFormat;
    private MediaFormat[] downstreamMediaFormats;
    private long downstreamPositionUs;
    private int enabledTrackCount;
    private final Handler eventHandler;
    private final EventListener eventListener;
    private final int eventSourceId;
    private boolean[] extractorTrackEnabledStates;
    private int[] extractorTrackIndices;
    private final LinkedList<HlsExtractorWrapper> extractors;
    private long lastSeekPositionUs;
    private final LoadControl loadControl;
    private boolean loadControlRegistered;
    private Loader loader;
    private boolean loadingFinished;
    private final int minLoadableRetryCount;
    private boolean[] pendingDiscontinuities;
    private long pendingResetPositionUs;
    private boolean prepared;
    private TsChunk previousTsLoadable;
    private int remainingReleaseCount;
    private int trackCount;
    private boolean[] trackEnabledStates;
    private MediaFormat[] trackFormats;

    public interface EventListener extends BaseChunkSampleSourceEventListener {
    }

    public HlsSampleSource(HlsChunkSource hlsChunkSource, LoadControl loadControl, int i) {
        this(hlsChunkSource, loadControl, i, null, null, 0);
    }

    public HlsSampleSource(HlsChunkSource hlsChunkSource, LoadControl loadControl, int i, Handler handler, EventListener eventListener, int i2) {
        this(hlsChunkSource, loadControl, i, handler, eventListener, i2, 3);
    }

    public HlsSampleSource(HlsChunkSource hlsChunkSource, LoadControl loadControl, int i, Handler handler, EventListener eventListener, int i2, int i3) {
        this.chunkSource = hlsChunkSource;
        this.loadControl = loadControl;
        this.bufferSizeContribution = i;
        this.minLoadableRetryCount = i3;
        this.eventHandler = handler;
        this.eventListener = eventListener;
        this.eventSourceId = i2;
        this.pendingResetPositionUs = Long.MIN_VALUE;
        this.extractors = new LinkedList();
        this.chunkOperationHolder = new ChunkOperationHolder();
    }

    public final SampleSourceReader register() {
        this.remainingReleaseCount++;
        return this;
    }

    public final boolean prepare(long j) {
        if (this.prepared) {
            return true;
        }
        if (!this.chunkSource.prepare()) {
            return false;
        }
        if (!this.extractors.isEmpty()) {
            while (true) {
                HlsExtractorWrapper hlsExtractorWrapper = (HlsExtractorWrapper) this.extractors.getFirst();
                if (!hlsExtractorWrapper.isPrepared()) {
                    if (this.extractors.size() <= 1) {
                        break;
                    }
                    ((HlsExtractorWrapper) this.extractors.removeFirst()).clear();
                } else {
                    buildTracks(hlsExtractorWrapper);
                    this.prepared = true;
                    maybeStartLoading();
                    return true;
                }
            }
        }
        if (this.loader == null) {
            this.loader = new Loader("Loader:HLS");
            this.loadControl.register(this, this.bufferSizeContribution);
            this.loadControlRegistered = true;
        }
        if (!this.loader.isLoading()) {
            this.pendingResetPositionUs = j;
            this.downstreamPositionUs = j;
        }
        maybeStartLoading();
        return false;
    }

    public final int getTrackCount() {
        Assertions.checkState(this.prepared);
        return this.trackCount;
    }

    public final MediaFormat getFormat(int i) {
        Assertions.checkState(this.prepared);
        return this.trackFormats[i];
    }

    public final void enable(int i, long j) {
        Assertions.checkState(this.prepared);
        setTrackEnabledState(i, true);
        this.downstreamMediaFormats[i] = null;
        this.pendingDiscontinuities[i] = false;
        this.downstreamFormat = null;
        boolean z = this.loadControlRegistered;
        if (!this.loadControlRegistered) {
            this.loadControl.register(this, this.bufferSizeContribution);
            this.loadControlRegistered = true;
        }
        if (this.chunkSource.isLive()) {
            j = 0;
        }
        int i2 = this.chunkSourceTrackIndices[i];
        if (i2 != -1 && i2 != this.chunkSource.getSelectedTrackIndex()) {
            this.chunkSource.selectTrack(i2);
            seekToInternal(j);
        } else if (this.enabledTrackCount == 1) {
            this.lastSeekPositionUs = j;
            if (z && this.downstreamPositionUs == j) {
                maybeStartLoading();
                return;
            }
            this.downstreamPositionUs = j;
            restartFrom(j);
        }
    }

    public final void disable(int i) {
        Assertions.checkState(this.prepared);
        setTrackEnabledState(i, false);
        if (this.enabledTrackCount == 0) {
            this.chunkSource.reset();
            this.downstreamPositionUs = Long.MIN_VALUE;
            if (this.loadControlRegistered) {
                this.loadControl.unregister(this);
                this.loadControlRegistered = false;
            }
            if (this.loader.isLoading()) {
                this.loader.cancelLoading();
                return;
            }
            clearState();
            this.loadControl.trimAllocator();
        }
    }

    public final boolean continueBuffering(int i, long j) {
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.trackEnabledStates[i]);
        this.downstreamPositionUs = j;
        if (!this.extractors.isEmpty()) {
            discardSamplesForDisabledTracks(getCurrentExtractor(), this.downstreamPositionUs);
        }
        maybeStartLoading();
        if (this.loadingFinished) {
            return true;
        }
        if (isPendingReset() || this.extractors.isEmpty()) {
            return false;
        }
        for (int i2 = 0; i2 < this.extractors.size(); i2++) {
            HlsExtractorWrapper hlsExtractorWrapper = (HlsExtractorWrapper) this.extractors.get(i2);
            if (!hlsExtractorWrapper.isPrepared()) {
                return false;
            }
            if (hlsExtractorWrapper.hasSamples(this.extractorTrackIndices[i])) {
                return true;
            }
        }
        return false;
    }

    public final long readDiscontinuity(int i) {
        if (!this.pendingDiscontinuities[i]) {
            return Long.MIN_VALUE;
        }
        this.pendingDiscontinuities[i] = false;
        return this.lastSeekPositionUs;
    }

    public final int readData(int i, long j, MediaFormatHolder mediaFormatHolder, SampleHolder sampleHolder) {
        int i2 = 0;
        Assertions.checkState(this.prepared);
        this.downstreamPositionUs = j;
        if (this.pendingDiscontinuities[i] || isPendingReset()) {
            return -2;
        }
        HlsExtractorWrapper currentExtractor = getCurrentExtractor();
        if (!currentExtractor.isPrepared()) {
            return -2;
        }
        if (this.downstreamFormat == null || !this.downstreamFormat.equals(currentExtractor.format)) {
            notifyDownstreamFormatChanged(currentExtractor.format, currentExtractor.trigger, currentExtractor.startTimeUs);
            this.downstreamFormat = currentExtractor.format;
        }
        if (this.extractors.size() > 1) {
            currentExtractor.configureSpliceTo((HlsExtractorWrapper) this.extractors.get(1));
        }
        int i3 = this.extractorTrackIndices[i];
        int i4 = 0;
        while (this.extractors.size() > i4 + 1 && !currentExtractor.hasSamples(i3)) {
            int i5 = i4 + 1;
            HlsExtractorWrapper hlsExtractorWrapper = (HlsExtractorWrapper) this.extractors.get(i5);
            if (!hlsExtractorWrapper.isPrepared()) {
                return -2;
            }
            int i6 = i5;
            currentExtractor = hlsExtractorWrapper;
            i4 = i6;
        }
        MediaFormat mediaFormat = currentExtractor.getMediaFormat(i3);
        if (mediaFormat != null && !mediaFormat.equals(this.downstreamMediaFormats[i])) {
            mediaFormatHolder.format = mediaFormat;
            this.downstreamMediaFormats[i] = mediaFormat;
            return -4;
        } else if (!currentExtractor.getSample(i3, sampleHolder)) {
            return this.loadingFinished ? -1 : -2;
        } else {
            if (sampleHolder.timeUs < this.lastSeekPositionUs) {
                i4 = 1;
            } else {
                i4 = 0;
            }
            i5 = sampleHolder.flags;
            if (i4 != 0) {
                i2 = C1893C.SAMPLE_FLAG_DECODE_ONLY;
            }
            sampleHolder.flags = i5 | i2;
            return -3;
        }
    }

    public final void maybeThrowError() throws IOException {
        if (this.currentLoadableException != null && this.currentLoadableExceptionCount > this.minLoadableRetryCount) {
            throw this.currentLoadableException;
        } else if (this.currentLoadable == null) {
            this.chunkSource.maybeThrowError();
        }
    }

    public final void seekToUs(long j) {
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.enabledTrackCount > 0);
        if (this.chunkSource.isLive()) {
            j = 0;
        }
        long j2 = isPendingReset() ? this.pendingResetPositionUs : this.downstreamPositionUs;
        this.downstreamPositionUs = j;
        this.lastSeekPositionUs = j;
        if (j2 != j) {
            seekToInternal(j);
        }
    }

    public final long getBufferedPositionUs() {
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.enabledTrackCount > 0);
        if (isPendingReset()) {
            return this.pendingResetPositionUs;
        }
        if (this.loadingFinished) {
            return -3;
        }
        long max;
        long largestParsedTimestampUs = ((HlsExtractorWrapper) this.extractors.getLast()).getLargestParsedTimestampUs();
        if (this.extractors.size() > 1) {
            max = Math.max(largestParsedTimestampUs, ((HlsExtractorWrapper) this.extractors.get(this.extractors.size() - 2)).getLargestParsedTimestampUs());
        } else {
            max = largestParsedTimestampUs;
        }
        return max == Long.MIN_VALUE ? this.downstreamPositionUs : max;
    }

    public final void release() {
        Assertions.checkState(this.remainingReleaseCount > 0);
        int i = this.remainingReleaseCount - 1;
        this.remainingReleaseCount = i;
        if (i == 0 && this.loader != null) {
            if (this.loadControlRegistered) {
                this.loadControl.unregister(this);
                this.loadControlRegistered = false;
            }
            this.loader.release();
            this.loader = null;
        }
    }

    public final void onLoadCompleted(Loadable loadable) {
        boolean z = true;
        Assertions.checkState(loadable == this.currentLoadable);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j = elapsedRealtime - this.currentLoadStartTimeMs;
        this.chunkSource.onChunkLoadCompleted(this.currentLoadable);
        if (isTsChunk(this.currentLoadable)) {
            if (this.currentLoadable != this.currentTsLoadable) {
                z = false;
            }
            Assertions.checkState(z);
            this.previousTsLoadable = this.currentTsLoadable;
            notifyLoadCompleted(this.currentLoadable.bytesLoaded(), this.currentTsLoadable.type, this.currentTsLoadable.trigger, this.currentTsLoadable.format, this.currentTsLoadable.startTimeUs, this.currentTsLoadable.endTimeUs, elapsedRealtime, j);
        } else {
            notifyLoadCompleted(this.currentLoadable.bytesLoaded(), this.currentLoadable.type, this.currentLoadable.trigger, this.currentLoadable.format, -1, -1, elapsedRealtime, j);
        }
        clearCurrentLoadable();
        maybeStartLoading();
    }

    public final void onLoadCanceled(Loadable loadable) {
        notifyLoadCanceled(this.currentLoadable.bytesLoaded());
        if (this.enabledTrackCount > 0) {
            restartFrom(this.pendingResetPositionUs);
            return;
        }
        clearState();
        this.loadControl.trimAllocator();
    }

    public final void onLoadError(Loadable loadable, IOException iOException) {
        if (this.chunkSource.onChunkLoadError(this.currentLoadable, iOException)) {
            if (this.previousTsLoadable == null && !isPendingReset()) {
                this.pendingResetPositionUs = this.lastSeekPositionUs;
            }
            clearCurrentLoadable();
        } else {
            this.currentLoadableException = iOException;
            this.currentLoadableExceptionCount++;
            this.currentLoadableExceptionTimestamp = SystemClock.elapsedRealtime();
        }
        notifyLoadError(iOException);
        maybeStartLoading();
    }

    private void buildTracks(HlsExtractorWrapper hlsExtractorWrapper) {
        int i;
        int trackCount = hlsExtractorWrapper.getTrackCount();
        int i2 = 0;
        int i3 = -1;
        Object obj = null;
        while (i2 < trackCount) {
            Object obj2;
            String str = hlsExtractorWrapper.getMediaFormat(i2).mimeType;
            if (MimeTypes.isVideo(str)) {
                obj2 = 3;
            } else if (MimeTypes.isAudio(str)) {
                obj2 = 2;
            } else if (MimeTypes.isText(str)) {
                i = 1;
            } else {
                obj2 = null;
            }
            if (obj2 > obj) {
                i3 = i2;
            } else if (obj2 != obj || i3 == -1) {
                obj2 = obj;
            } else {
                i3 = -1;
                obj2 = obj;
            }
            i2++;
            obj = obj2;
        }
        int trackCount2 = this.chunkSource.getTrackCount();
        Object obj3 = i3 != -1 ? 1 : null;
        this.trackCount = trackCount;
        if (obj3 != null) {
            this.trackCount += trackCount2 - 1;
        }
        this.trackFormats = new MediaFormat[this.trackCount];
        this.trackEnabledStates = new boolean[this.trackCount];
        this.pendingDiscontinuities = new boolean[this.trackCount];
        this.downstreamMediaFormats = new MediaFormat[this.trackCount];
        this.chunkSourceTrackIndices = new int[this.trackCount];
        this.extractorTrackIndices = new int[this.trackCount];
        this.extractorTrackEnabledStates = new boolean[trackCount];
        long durationUs = this.chunkSource.getDurationUs();
        int i4 = 0;
        i = 0;
        while (i4 < trackCount) {
            MediaFormat copyWithDurationUs = hlsExtractorWrapper.getMediaFormat(i4).copyWithDurationUs(durationUs);
            if (i4 == i3) {
                int i5 = 0;
                while (i5 < trackCount2) {
                    MediaFormat copyAsAdaptive;
                    this.extractorTrackIndices[i] = i4;
                    this.chunkSourceTrackIndices[i] = i5;
                    Variant fixedTrackVariant = this.chunkSource.getFixedTrackVariant(i5);
                    MediaFormat[] mediaFormatArr = this.trackFormats;
                    int i6 = i + 1;
                    if (fixedTrackVariant == null) {
                        copyAsAdaptive = copyWithDurationUs.copyAsAdaptive(null);
                    } else {
                        copyAsAdaptive = copyWithFixedTrackInfo(copyWithDurationUs, fixedTrackVariant.format);
                    }
                    mediaFormatArr[i] = copyAsAdaptive;
                    i5++;
                    i = i6;
                }
                i2 = i;
            } else {
                this.extractorTrackIndices[i] = i4;
                this.chunkSourceTrackIndices[i] = -1;
                i2 = i + 1;
                this.trackFormats[i] = copyWithDurationUs;
            }
            i4++;
            i = i2;
        }
    }

    private void setTrackEnabledState(int i, boolean z) {
        boolean z2 = false;
        int i2 = 1;
        Assertions.checkState(this.trackEnabledStates[i] != z);
        int i3 = this.extractorTrackIndices[i];
        if (this.extractorTrackEnabledStates[i3] != z) {
            z2 = true;
        }
        Assertions.checkState(z2);
        this.trackEnabledStates[i] = z;
        this.extractorTrackEnabledStates[i3] = z;
        i3 = this.enabledTrackCount;
        if (!z) {
            i2 = -1;
        }
        this.enabledTrackCount = i3 + i2;
    }

    private static MediaFormat copyWithFixedTrackInfo(MediaFormat mediaFormat, Format format) {
        return mediaFormat.copyWithFixedTrackInfo(format.id, format.bitrate, format.width == -1 ? -1 : format.width, format.height == -1 ? -1 : format.height, format.language);
    }

    private void seekToInternal(long j) {
        this.lastSeekPositionUs = j;
        this.downstreamPositionUs = j;
        Arrays.fill(this.pendingDiscontinuities, true);
        this.chunkSource.seek();
        restartFrom(j);
    }

    private HlsExtractorWrapper getCurrentExtractor() {
        HlsExtractorWrapper hlsExtractorWrapper = (HlsExtractorWrapper) this.extractors.getFirst();
        while (this.extractors.size() > 1 && !haveSamplesForEnabledTracks(hlsExtractorWrapper)) {
            ((HlsExtractorWrapper) this.extractors.removeFirst()).clear();
            hlsExtractorWrapper = (HlsExtractorWrapper) this.extractors.getFirst();
        }
        return hlsExtractorWrapper;
    }

    private void discardSamplesForDisabledTracks(HlsExtractorWrapper hlsExtractorWrapper, long j) {
        if (hlsExtractorWrapper.isPrepared()) {
            for (int i = 0; i < this.extractorTrackEnabledStates.length; i++) {
                if (!this.extractorTrackEnabledStates[i]) {
                    hlsExtractorWrapper.discardUntil(i, j);
                }
            }
        }
    }

    private boolean haveSamplesForEnabledTracks(HlsExtractorWrapper hlsExtractorWrapper) {
        if (!hlsExtractorWrapper.isPrepared()) {
            return false;
        }
        int i = 0;
        while (i < this.extractorTrackEnabledStates.length) {
            if (this.extractorTrackEnabledStates[i] && hlsExtractorWrapper.hasSamples(i)) {
                return true;
            }
            i++;
        }
        return false;
    }

    private void restartFrom(long j) {
        this.pendingResetPositionUs = j;
        this.loadingFinished = false;
        if (this.loader.isLoading()) {
            this.loader.cancelLoading();
            return;
        }
        clearState();
        maybeStartLoading();
    }

    private void clearState() {
        for (int i = 0; i < this.extractors.size(); i++) {
            ((HlsExtractorWrapper) this.extractors.get(i)).clear();
        }
        this.extractors.clear();
        clearCurrentLoadable();
        this.previousTsLoadable = null;
    }

    private void clearCurrentLoadable() {
        this.currentTsLoadable = null;
        this.currentLoadable = null;
        this.currentLoadableException = null;
        this.currentLoadableExceptionCount = 0;
    }

    private void maybeStartLoading() {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long nextLoadPositionUs = getNextLoadPositionUs();
        Object obj = this.currentLoadableException != null ? 1 : null;
        boolean z = this.loader.isLoading() || obj != null;
        boolean update = this.loadControl.update(this, this.downstreamPositionUs, nextLoadPositionUs, z);
        if (obj != null) {
            if (elapsedRealtime - this.currentLoadableExceptionTimestamp >= getRetryDelayMillis((long) this.currentLoadableExceptionCount)) {
                this.currentLoadableException = null;
                this.loader.startLoading(this.currentLoadable, this);
            }
        } else if (!this.loader.isLoading() && update) {
            if (!this.prepared || this.enabledTrackCount != 0) {
                this.chunkSource.getChunkOperation(this.previousTsLoadable, this.pendingResetPositionUs != Long.MIN_VALUE ? this.pendingResetPositionUs : this.downstreamPositionUs, this.chunkOperationHolder);
                update = this.chunkOperationHolder.endOfStream;
                Chunk chunk = this.chunkOperationHolder.chunk;
                this.chunkOperationHolder.clear();
                if (update) {
                    this.loadingFinished = true;
                    this.loadControl.update(this, this.downstreamPositionUs, -1, false);
                } else if (chunk != null) {
                    this.currentLoadStartTimeMs = elapsedRealtime;
                    this.currentLoadable = chunk;
                    if (isTsChunk(this.currentLoadable)) {
                        TsChunk tsChunk = (TsChunk) this.currentLoadable;
                        if (isPendingReset()) {
                            this.pendingResetPositionUs = Long.MIN_VALUE;
                        }
                        HlsExtractorWrapper hlsExtractorWrapper = tsChunk.extractorWrapper;
                        if (this.extractors.isEmpty() || this.extractors.getLast() != hlsExtractorWrapper) {
                            hlsExtractorWrapper.init(this.loadControl.getAllocator());
                            this.extractors.addLast(hlsExtractorWrapper);
                        }
                        notifyLoadStarted(tsChunk.dataSpec.length, tsChunk.type, tsChunk.trigger, tsChunk.format, tsChunk.startTimeUs, tsChunk.endTimeUs);
                        this.currentTsLoadable = tsChunk;
                    } else {
                        notifyLoadStarted(this.currentLoadable.dataSpec.length, this.currentLoadable.type, this.currentLoadable.trigger, this.currentLoadable.format, -1, -1);
                    }
                    this.loader.startLoading(this.currentLoadable, this);
                }
            }
        }
    }

    private long getNextLoadPositionUs() {
        if (isPendingReset()) {
            return this.pendingResetPositionUs;
        }
        if (this.loadingFinished || (this.prepared && this.enabledTrackCount == 0)) {
            return -1;
        }
        return this.currentTsLoadable != null ? this.currentTsLoadable.endTimeUs : this.previousTsLoadable.endTimeUs;
    }

    private boolean isTsChunk(Chunk chunk) {
        return chunk instanceof TsChunk;
    }

    private boolean isPendingReset() {
        return this.pendingResetPositionUs != Long.MIN_VALUE;
    }

    private long getRetryDelayMillis(long j) {
        return Math.min((j - 1) * 1000, HlsChunkSource.DEFAULT_MIN_BUFFER_TO_SWITCH_UP_MS);
    }

    final long usToMs(long j) {
        return j / 1000;
    }

    private void notifyLoadStarted(long j, int i, int i2, Format format, long j2, long j3) {
        if (this.eventHandler != null && this.eventListener != null) {
            final long j4 = j;
            final int i3 = i;
            final int i4 = i2;
            final Format format2 = format;
            final long j5 = j2;
            final long j6 = j3;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    HlsSampleSource.this.eventListener.onLoadStarted(HlsSampleSource.this.eventSourceId, j4, i3, i4, format2, HlsSampleSource.this.usToMs(j5), HlsSampleSource.this.usToMs(j6));
                }
            });
        }
    }

    private void notifyLoadCompleted(long j, int i, int i2, Format format, long j2, long j3, long j4, long j5) {
        if (this.eventHandler != null && this.eventListener != null) {
            final long j6 = j;
            final int i3 = i;
            final int i4 = i2;
            final Format format2 = format;
            final long j7 = j2;
            final long j8 = j3;
            final long j9 = j4;
            final long j10 = j5;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    HlsSampleSource.this.eventListener.onLoadCompleted(HlsSampleSource.this.eventSourceId, j6, i3, i4, format2, HlsSampleSource.this.usToMs(j7), HlsSampleSource.this.usToMs(j8), j9, j10);
                }
            });
        }
    }

    private void notifyLoadCanceled(final long j) {
        if (this.eventHandler != null && this.eventListener != null) {
            this.eventHandler.post(new Runnable() {
                public void run() {
                    HlsSampleSource.this.eventListener.onLoadCanceled(HlsSampleSource.this.eventSourceId, j);
                }
            });
        }
    }

    private void notifyLoadError(final IOException iOException) {
        if (this.eventHandler != null && this.eventListener != null) {
            this.eventHandler.post(new Runnable() {
                public void run() {
                    HlsSampleSource.this.eventListener.onLoadError(HlsSampleSource.this.eventSourceId, iOException);
                }
            });
        }
    }

    private void notifyDownstreamFormatChanged(Format format, int i, long j) {
        if (this.eventHandler != null && this.eventListener != null) {
            final Format format2 = format;
            final int i2 = i;
            final long j2 = j;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    HlsSampleSource.this.eventListener.onDownstreamFormatChanged(HlsSampleSource.this.eventSourceId, format2, i2, HlsSampleSource.this.usToMs(j2));
                }
            });
        }
    }
}
