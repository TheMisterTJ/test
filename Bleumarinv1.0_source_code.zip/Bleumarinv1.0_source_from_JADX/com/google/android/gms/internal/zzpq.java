package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.measurement.zze;
import java.util.HashMap;
import java.util.Map;

public final class zzpq extends zze<zzpq> {
    private String zzSE;
    private String zzSF;
    private String zzaUE;
    private String zzaUa;

    public final void setAppId(String str) {
        this.zzaUa = str;
    }

    public final void setAppInstallerId(String str) {
        this.zzaUE = str;
    }

    public final void setAppName(String str) {
        this.zzSE = str;
    }

    public final void setAppVersion(String str) {
        this.zzSF = str;
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("appName", this.zzSE);
        hashMap.put("appVersion", this.zzSF);
        hashMap.put("appId", this.zzaUa);
        hashMap.put("appInstallerId", this.zzaUE);
        return zze.zzF(hashMap);
    }

    public final String zzAJ() {
        return this.zzaUE;
    }

    public final void zza(zzpq com_google_android_gms_internal_zzpq) {
        if (!TextUtils.isEmpty(this.zzSE)) {
            com_google_android_gms_internal_zzpq.setAppName(this.zzSE);
        }
        if (!TextUtils.isEmpty(this.zzSF)) {
            com_google_android_gms_internal_zzpq.setAppVersion(this.zzSF);
        }
        if (!TextUtils.isEmpty(this.zzaUa)) {
            com_google_android_gms_internal_zzpq.setAppId(this.zzaUa);
        }
        if (!TextUtils.isEmpty(this.zzaUE)) {
            com_google_android_gms_internal_zzpq.setAppInstallerId(this.zzaUE);
        }
    }

    public final String zzlg() {
        return this.zzSE;
    }

    public final String zzli() {
        return this.zzSF;
    }

    public final String zzwK() {
        return this.zzaUa;
    }
}
