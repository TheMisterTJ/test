package com.google.android.exoplayer.extractor.mp4;

import com.google.android.exoplayer.extractor.ExtractorInput;
import com.google.android.exoplayer.util.ParsableByteArray;
import com.google.android.exoplayer.util.Util;
import java.io.IOException;

final class Sniffer {
    private static final int[] COMPATIBLE_BRANDS = new int[]{Util.getIntegerCodeForString("isom"), Util.getIntegerCodeForString("iso2"), Util.getIntegerCodeForString("avc1"), Util.getIntegerCodeForString("hvc1"), Util.getIntegerCodeForString("hev1"), Util.getIntegerCodeForString("mp41"), Util.getIntegerCodeForString("mp42"), Util.getIntegerCodeForString("3g2a"), Util.getIntegerCodeForString("3g2b"), Util.getIntegerCodeForString("3gr6"), Util.getIntegerCodeForString("3gs6"), Util.getIntegerCodeForString("3ge6"), Util.getIntegerCodeForString("3gg6"), Util.getIntegerCodeForString("M4V "), Util.getIntegerCodeForString("M4A "), Util.getIntegerCodeForString("f4v "), Util.getIntegerCodeForString("kddi"), Util.getIntegerCodeForString("M4VP"), Util.getIntegerCodeForString("qt  "), Util.getIntegerCodeForString("MSNV")};

    public static boolean sniffFragmented(ExtractorInput extractorInput) throws IOException, InterruptedException {
        return sniffInternal(extractorInput, 4096, true);
    }

    public static boolean sniffUnfragmented(ExtractorInput extractorInput) throws IOException, InterruptedException {
        return sniffInternal(extractorInput, 128, false);
    }

    private static boolean sniffInternal(ExtractorInput extractorInput, int i, boolean z) throws IOException, InterruptedException {
        long length = extractorInput.getLength();
        if (length == -1 || length > ((long) i)) {
            length = (long) i;
        }
        int i2 = (int) length;
        ParsableByteArray parsableByteArray = new ParsableByteArray(64);
        Object obj = null;
        boolean z2 = false;
        long readLong;
        for (int i3 = 0; i3 < i2; i3 = (int) (((long) i3) + readLong)) {
            int i4;
            extractorInput.peekFully(parsableByteArray.data, 0, 8);
            parsableByteArray.setPosition(0);
            long readUnsignedInt = parsableByteArray.readUnsignedInt();
            int readInt = parsableByteArray.readInt();
            if (readUnsignedInt == 1) {
                extractorInput.peekFully(parsableByteArray.data, 8, 8);
                i4 = 16;
                readLong = parsableByteArray.readLong();
            } else {
                long j = readUnsignedInt;
                i4 = 8;
                readLong = j;
            }
            if (readLong < ((long) i4)) {
                return false;
            }
            i4 = ((int) readLong) - i4;
            if (readInt != Atom.TYPE_ftyp) {
                if (readInt != Atom.TYPE_moof) {
                    if (i4 != 0) {
                        if (((long) i3) + readLong >= ((long) i2)) {
                            break;
                        }
                        extractorInput.advancePeekPosition(i4);
                    } else {
                        continue;
                    }
                } else {
                    z2 = true;
                    break;
                }
            } else if (i4 < 8) {
                return false;
            } else {
                int i5 = (i4 - 8) / 4;
                extractorInput.peekFully(parsableByteArray.data, 0, (i5 + 2) * 4);
                for (i4 = 0; i4 < i5 + 2; i4++) {
                    if (i4 != 1 && isCompatibleBrand(parsableByteArray.readInt())) {
                        obj = 1;
                        break;
                    }
                }
                if (obj == null) {
                    return false;
                }
            }
        }
        if (obj == null || z != r3) {
            return false;
        }
        return true;
    }

    private static boolean isCompatibleBrand(int i) {
        if ((i >>> 8) == Util.getIntegerCodeForString("3gp")) {
            return true;
        }
        for (int i2 : COMPATIBLE_BRANDS) {
            if (i2 == i) {
                return true;
            }
        }
        return false;
    }

    private Sniffer() {
    }
}
