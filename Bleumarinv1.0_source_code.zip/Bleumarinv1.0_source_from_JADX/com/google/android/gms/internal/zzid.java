package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;

@zzhb
public final class zzid implements zzie {
    public final String zzf(AdRequestInfoParcel adRequestInfoParcel) {
        return adRequestInfoParcel.zzHv;
    }
}
