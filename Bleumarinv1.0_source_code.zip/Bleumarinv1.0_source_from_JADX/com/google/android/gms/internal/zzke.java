package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.common.internal.zzx;
import com.google.android.gms.measurement.zze;
import java.util.HashMap;
import java.util.Map;

public final class zzke extends zze<zzke> {
    private String zzPN;
    private String zzPO;
    private String zzPP;
    private boolean zzPQ;
    private String zzPR;
    private boolean zzPS;
    private double zzPT;
    private String zzrG;

    public final String getClientId() {
        return this.zzPO;
    }

    public final String getUserId() {
        return this.zzrG;
    }

    public final void setClientId(String str) {
        this.zzPO = str;
    }

    public final void setSampleRate(double d) {
        boolean z = d >= 0.0d && d <= 100.0d;
        zzx.zzb(z, (Object) "Sample rate must be between 0% and 100%");
        this.zzPT = d;
    }

    public final void setUserId(String str) {
        this.zzrG = str;
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("hitType", this.zzPN);
        hashMap.put("clientId", this.zzPO);
        hashMap.put("userId", this.zzrG);
        hashMap.put("androidAdId", this.zzPP);
        hashMap.put("AdTargetingEnabled", Boolean.valueOf(this.zzPQ));
        hashMap.put("sessionControl", this.zzPR);
        hashMap.put("nonInteraction", Boolean.valueOf(this.zzPS));
        hashMap.put("sampleRate", Double.valueOf(this.zzPT));
        return zze.zzF(hashMap);
    }

    public final void zzH(boolean z) {
        this.zzPQ = z;
    }

    public final void zzI(boolean z) {
        this.zzPS = z;
    }

    public final void zza(zzke com_google_android_gms_internal_zzke) {
        if (!TextUtils.isEmpty(this.zzPN)) {
            com_google_android_gms_internal_zzke.zzaX(this.zzPN);
        }
        if (!TextUtils.isEmpty(this.zzPO)) {
            com_google_android_gms_internal_zzke.setClientId(this.zzPO);
        }
        if (!TextUtils.isEmpty(this.zzrG)) {
            com_google_android_gms_internal_zzke.setUserId(this.zzrG);
        }
        if (!TextUtils.isEmpty(this.zzPP)) {
            com_google_android_gms_internal_zzke.zzaY(this.zzPP);
        }
        if (this.zzPQ) {
            com_google_android_gms_internal_zzke.zzH(true);
        }
        if (!TextUtils.isEmpty(this.zzPR)) {
            com_google_android_gms_internal_zzke.zzaZ(this.zzPR);
        }
        if (this.zzPS) {
            com_google_android_gms_internal_zzke.zzI(this.zzPS);
        }
        if (this.zzPT != 0.0d) {
            com_google_android_gms_internal_zzke.setSampleRate(this.zzPT);
        }
    }

    public final void zzaX(String str) {
        this.zzPN = str;
    }

    public final void zzaY(String str) {
        this.zzPP = str;
    }

    public final void zzaZ(String str) {
        this.zzPR = str;
    }

    public final String zziS() {
        return this.zzPN;
    }

    public final String zziT() {
        return this.zzPP;
    }

    public final boolean zziU() {
        return this.zzPQ;
    }

    public final String zziV() {
        return this.zzPR;
    }

    public final boolean zziW() {
        return this.zzPS;
    }

    public final double zziX() {
        return this.zzPT;
    }
}
