package com.google.android.gms.internal;

import android.annotation.TargetApi;

@TargetApi(17)
@zzhb
public class zzju {
    private final zzjp zzpD;

    public zzju(zzjp com_google_android_gms_internal_zzjp) {
        this.zzpD = com_google_android_gms_internal_zzjp;
    }
}
