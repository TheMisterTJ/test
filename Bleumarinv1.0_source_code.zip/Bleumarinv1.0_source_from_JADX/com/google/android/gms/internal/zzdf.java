package com.google.android.gms.internal;

import java.util.Map;

public interface zzdf {
    void zza(zzjp com_google_android_gms_internal_zzjp, Map<String, String> map);
}
