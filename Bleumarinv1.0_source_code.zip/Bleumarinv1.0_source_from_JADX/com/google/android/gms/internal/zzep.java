package com.google.android.gms.internal;

public interface zzep {
    void zzaY();

    void zzaZ();

    void zzba();

    void zzbb();

    void zzbc();
}
