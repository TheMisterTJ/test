package com.google.android.gms.internal;

public interface zzdt {
    zzdr zza(zzjp com_google_android_gms_internal_zzjp, int i, String str);
}
