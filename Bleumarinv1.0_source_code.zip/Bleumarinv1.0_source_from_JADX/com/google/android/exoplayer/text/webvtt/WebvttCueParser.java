package com.google.android.exoplayer.text.webvtt;

import android.text.Layout.Alignment;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import com.flurry.android.AdCreative;
import com.google.android.exoplayer.text.webvtt.WebvttCue.Builder;
import com.google.android.exoplayer.util.ParsableByteArray;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WebvttCueParser {
    private static final char CHAR_AMPERSAND = '&';
    private static final char CHAR_GREATER_THAN = '>';
    private static final char CHAR_LESS_THAN = '<';
    private static final char CHAR_SEMI_COLON = ';';
    private static final char CHAR_SLASH = '/';
    private static final char CHAR_SPACE = ' ';
    private static final Pattern COMMENT = Pattern.compile("^NOTE(( |\t).*)?$");
    public static final Pattern CUE_HEADER_PATTERN = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");
    private static final Pattern CUE_SETTING_PATTERN = Pattern.compile("(\\S+?):(\\S+)");
    private static final String ENTITY_AMPERSAND = "amp";
    private static final String ENTITY_GREATER_THAN = "gt";
    private static final String ENTITY_LESS_THAN = "lt";
    private static final String ENTITY_NON_BREAK_SPACE = "nbsp";
    private static final String SPACE = " ";
    private static final int STYLE_BOLD = 1;
    private static final int STYLE_ITALIC = 2;
    private static final String TAG = "WebvttCueParser";
    private static final String TAG_BOLD = "b";
    private static final String TAG_CLASS = "c";
    private static final String TAG_ITALIC = "i";
    private static final String TAG_LANG = "lang";
    private static final String TAG_UNDERLINE = "u";
    private static final String TAG_VOICE = "v";
    private final StringBuilder textBuilder = new StringBuilder();

    private static final class StartTag {
        public final String name;
        public final int position;

        public StartTag(String str, int i) {
            this.position = i;
            this.name = str;
        }
    }

    final boolean parseNextValidCue(ParsableByteArray parsableByteArray, Builder builder) {
        Matcher findNextCueHeader;
        do {
            findNextCueHeader = findNextCueHeader(parsableByteArray);
            if (findNextCueHeader == null) {
                return false;
            }
        } while (!parseCue(findNextCueHeader, parsableByteArray, builder, this.textBuilder));
        return true;
    }

    static void parseCueSettingsList(String str, Builder builder) {
        Matcher matcher = CUE_SETTING_PATTERN.matcher(str);
        while (matcher.find()) {
            String group = matcher.group(1);
            String group2 = matcher.group(2);
            try {
                if ("line".equals(group)) {
                    parseLineAttribute(group2, builder);
                } else if ("align".equals(group)) {
                    builder.setTextAlignment(parseTextAlignment(group2));
                } else if ("position".equals(group)) {
                    parsePositionAttribute(group2, builder);
                } else if ("size".equals(group)) {
                    builder.setWidth(WebvttParserUtil.parsePercentage(group2));
                } else {
                    Log.w(TAG, "Unknown cue setting " + group + ":" + group2);
                }
            } catch (NumberFormatException e) {
                Log.w(TAG, "Skipping bad cue setting: " + matcher.group());
            }
        }
    }

    public static Matcher findNextCueHeader(ParsableByteArray parsableByteArray) {
        while (true) {
            CharSequence readLine = parsableByteArray.readLine();
            if (readLine == null) {
                return null;
            }
            if (COMMENT.matcher(readLine).matches()) {
                while (true) {
                    String readLine2 = parsableByteArray.readLine();
                    if (readLine2 == null || readLine2.isEmpty()) {
                        break;
                    }
                }
            } else {
                Matcher matcher = CUE_HEADER_PATTERN.matcher(readLine);
                if (matcher.matches()) {
                    return matcher;
                }
            }
        }
    }

    static void parseCueText(String str, Builder builder) {
        CharSequence spannableStringBuilder = new SpannableStringBuilder();
        Stack stack = new Stack();
        int i = 0;
        while (i < str.length()) {
            char charAt = str.charAt(i);
            int indexOf;
            int indexOf2;
            switch (charAt) {
                case '&':
                    indexOf = str.indexOf(59, i + 1);
                    indexOf2 = str.indexOf(32, i + 1);
                    if (indexOf == -1) {
                        indexOf = indexOf2;
                    } else if (indexOf2 != -1) {
                        indexOf = Math.min(indexOf, indexOf2);
                    }
                    if (indexOf == -1) {
                        spannableStringBuilder.append(charAt);
                        i++;
                        break;
                    }
                    applyEntity(str.substring(i + 1, indexOf), spannableStringBuilder);
                    if (indexOf == indexOf2) {
                        spannableStringBuilder.append(SPACE);
                    }
                    i = indexOf + 1;
                    break;
                case '<':
                    if (i + 1 < str.length()) {
                        int i2;
                        int i3;
                        indexOf2 = str.charAt(i + 1) == CHAR_SLASH ? 1 : 0;
                        indexOf = findEndOfTag(str, i + 1);
                        if (str.charAt(indexOf - 2) == CHAR_SLASH) {
                            i2 = 1;
                        } else {
                            i2 = 0;
                        }
                        if (indexOf2 != 0) {
                            i3 = 2;
                        } else {
                            i3 = 1;
                        }
                        i3 += i;
                        if (i2 != 0) {
                            i = indexOf - 2;
                        } else {
                            i = indexOf - 1;
                        }
                        String[] tokenizeTag = tokenizeTag(str.substring(i3, i));
                        if (tokenizeTag != null && isSupportedTag(tokenizeTag[0])) {
                            if (indexOf2 == 0) {
                                if (i2 == 0) {
                                    stack.push(new StartTag(tokenizeTag[0], spannableStringBuilder.length()));
                                    i = indexOf;
                                    break;
                                }
                            }
                            while (!stack.isEmpty()) {
                                StartTag startTag = (StartTag) stack.pop();
                                applySpansForTag(startTag, spannableStringBuilder);
                                if (startTag.name.equals(tokenizeTag[0])) {
                                    i = indexOf;
                                    break;
                                }
                            }
                            i = indexOf;
                        }
                        i = indexOf;
                        break;
                    }
                    i++;
                    break;
                default:
                    spannableStringBuilder.append(charAt);
                    i++;
                    break;
            }
        }
        while (!stack.isEmpty()) {
            applySpansForTag((StartTag) stack.pop(), spannableStringBuilder);
        }
        builder.setText(spannableStringBuilder);
    }

    private static boolean parseCue(Matcher matcher, ParsableByteArray parsableByteArray, Builder builder, StringBuilder stringBuilder) {
        try {
            builder.setStartTime(WebvttParserUtil.parseTimestampUs(matcher.group(1))).setEndTime(WebvttParserUtil.parseTimestampUs(matcher.group(2)));
            parseCueSettingsList(matcher.group(3), builder);
            stringBuilder.setLength(0);
            while (true) {
                String readLine = parsableByteArray.readLine();
                if (readLine == null || readLine.isEmpty()) {
                    parseCueText(stringBuilder.toString(), builder);
                } else {
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append("\n");
                    }
                    stringBuilder.append(readLine.trim());
                }
            }
            parseCueText(stringBuilder.toString(), builder);
            return true;
        } catch (NumberFormatException e) {
            Log.w(TAG, "Skipping cue with bad header: " + matcher.group());
            return false;
        }
    }

    private static void parseLineAttribute(String str, Builder builder) throws NumberFormatException {
        int indexOf = str.indexOf(44);
        if (indexOf != -1) {
            builder.setLineAnchor(parsePositionAnchor(str.substring(indexOf + 1)));
            str = str.substring(0, indexOf);
        } else {
            builder.setLineAnchor(Integer.MIN_VALUE);
        }
        if (str.endsWith("%")) {
            builder.setLine(WebvttParserUtil.parsePercentage(str)).setLineType(0);
        } else {
            builder.setLine((float) Integer.parseInt(str)).setLineType(1);
        }
    }

    private static void parsePositionAttribute(String str, Builder builder) throws NumberFormatException {
        int indexOf = str.indexOf(44);
        if (indexOf != -1) {
            builder.setPositionAnchor(parsePositionAnchor(str.substring(indexOf + 1)));
            str = str.substring(0, indexOf);
        } else {
            builder.setPositionAnchor(Integer.MIN_VALUE);
        }
        builder.setPosition(WebvttParserUtil.parsePercentage(str));
    }

    private static int parsePositionAnchor(String str) {
        int i = -1;
        switch (str.hashCode()) {
            case -1364013995:
                if (str.equals("center")) {
                    i = 1;
                    break;
                }
                break;
            case -1074341483:
                if (str.equals(AdCreative.kAlignmentMiddle)) {
                    i = 2;
                    break;
                }
                break;
            case 100571:
                if (str.equals(TtmlNode.END)) {
                    i = 3;
                    break;
                }
                break;
            case 109757538:
                if (str.equals(TtmlNode.START)) {
                    i = 0;
                    break;
                }
                break;
        }
        switch (i) {
            case 0:
                return 0;
            case 1:
            case 2:
                return 1;
            case 3:
                return 2;
            default:
                Log.w(TAG, "Invalid anchor value: " + str);
                return Integer.MIN_VALUE;
        }
    }

    private static Alignment parseTextAlignment(String str) {
        Object obj = -1;
        switch (str.hashCode()) {
            case -1364013995:
                if (str.equals("center")) {
                    obj = 2;
                    break;
                }
                break;
            case -1074341483:
                if (str.equals(AdCreative.kAlignmentMiddle)) {
                    obj = 3;
                    break;
                }
                break;
            case 100571:
                if (str.equals(TtmlNode.END)) {
                    obj = 4;
                    break;
                }
                break;
            case 3317767:
                if (str.equals("left")) {
                    obj = 1;
                    break;
                }
                break;
            case 108511772:
                if (str.equals("right")) {
                    obj = 5;
                    break;
                }
                break;
            case 109757538:
                if (str.equals(TtmlNode.START)) {
                    obj = null;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
            case 1:
                return Alignment.ALIGN_NORMAL;
            case 2:
            case 3:
                return Alignment.ALIGN_CENTER;
            case 4:
            case 5:
                return Alignment.ALIGN_OPPOSITE;
            default:
                Log.w(TAG, "Invalid alignment value: " + str);
                return null;
        }
    }

    private static int findEndOfTag(String str, int i) {
        int indexOf = str.indexOf(62, i);
        return indexOf == -1 ? str.length() : indexOf + 1;
    }

    private static void applyEntity(String str, SpannableStringBuilder spannableStringBuilder) {
        Object obj = -1;
        switch (str.hashCode()) {
            case 3309:
                if (str.equals(ENTITY_GREATER_THAN)) {
                    obj = 1;
                    break;
                }
                break;
            case 3464:
                if (str.equals(ENTITY_LESS_THAN)) {
                    obj = null;
                    break;
                }
                break;
            case 96708:
                if (str.equals(ENTITY_AMPERSAND)) {
                    obj = 3;
                    break;
                }
                break;
            case 3374865:
                if (str.equals(ENTITY_NON_BREAK_SPACE)) {
                    obj = 2;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
                spannableStringBuilder.append(CHAR_LESS_THAN);
                return;
            case 1:
                spannableStringBuilder.append(CHAR_GREATER_THAN);
                return;
            case 2:
                spannableStringBuilder.append(CHAR_SPACE);
                return;
            case 3:
                spannableStringBuilder.append(CHAR_AMPERSAND);
                return;
            default:
                Log.w(TAG, "ignoring unsupported entity: '&" + str + ";'");
                return;
        }
    }

    private static boolean isSupportedTag(String str) {
        boolean z = true;
        switch (str.hashCode()) {
            case 98:
                if (str.equals(TAG_BOLD)) {
                    z = false;
                    break;
                }
                break;
            case 99:
                if (str.equals(TAG_CLASS)) {
                    z = true;
                    break;
                }
                break;
            case 105:
                if (str.equals(TAG_ITALIC)) {
                    z = true;
                    break;
                }
                break;
            case 117:
                if (str.equals(TAG_UNDERLINE)) {
                    z = true;
                    break;
                }
                break;
            case 118:
                if (str.equals(TAG_VOICE)) {
                    z = true;
                    break;
                }
                break;
            case 3314158:
                if (str.equals(TAG_LANG)) {
                    z = true;
                    break;
                }
                break;
        }
        switch (z) {
            case false:
            case true:
            case true:
            case true:
            case true:
            case true:
                return true;
            default:
                return false;
        }
    }

    private static void applySpansForTag(StartTag startTag, SpannableStringBuilder spannableStringBuilder) {
        String str = startTag.name;
        int i = -1;
        switch (str.hashCode()) {
            case 98:
                if (str.equals(TAG_BOLD)) {
                    i = 0;
                    break;
                }
                break;
            case 105:
                if (str.equals(TAG_ITALIC)) {
                    i = 1;
                    break;
                }
                break;
            case 117:
                if (str.equals(TAG_UNDERLINE)) {
                    i = 2;
                    break;
                }
                break;
        }
        switch (i) {
            case 0:
                spannableStringBuilder.setSpan(new StyleSpan(1), startTag.position, spannableStringBuilder.length(), 33);
                return;
            case 1:
                spannableStringBuilder.setSpan(new StyleSpan(2), startTag.position, spannableStringBuilder.length(), 33);
                return;
            case 2:
                spannableStringBuilder.setSpan(new UnderlineSpan(), startTag.position, spannableStringBuilder.length(), 33);
                return;
            default:
                return;
        }
    }

    private static String[] tokenizeTag(String str) {
        String trim = str.replace("\\s+", SPACE).trim();
        if (trim.length() == 0) {
            return null;
        }
        if (trim.contains(SPACE)) {
            trim = trim.substring(0, trim.indexOf(SPACE));
        }
        return trim.split("\\.");
    }
}
