package com.google.android.exoplayer.hls;

import com.google.android.exoplayer.chunk.Format;
import com.google.android.exoplayer.hls.HlsMediaPlaylist.Segment;
import com.google.android.exoplayer.upstream.UriLoadable.Parser;
import com.google.android.exoplayer.util.MimeTypes;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Queue;
import java.util.regex.Pattern;

public final class HlsPlaylistParser implements Parser<HlsPlaylist> {
    private static final String AUDIO_TYPE = "AUDIO";
    private static final String BANDWIDTH_ATTR = "BANDWIDTH";
    private static final Pattern BANDWIDTH_ATTR_REGEX = Pattern.compile("BANDWIDTH=(\\d+)\\b");
    private static final Pattern BYTERANGE_REGEX = Pattern.compile("#EXT-X-BYTERANGE:(\\d+(?:@\\d+)?)\\b");
    private static final String BYTERANGE_TAG = "#EXT-X-BYTERANGE";
    private static final String CLOSED_CAPTIONS_TYPE = "CLOSED-CAPTIONS";
    private static final String CODECS_ATTR = "CODECS";
    private static final Pattern CODECS_ATTR_REGEX = Pattern.compile("CODECS=\"(.+?)\"");
    private static final String DISCONTINUITY_SEQUENCE_TAG = "#EXT-X-DISCONTINUITY-SEQUENCE";
    private static final String DISCONTINUITY_TAG = "#EXT-X-DISCONTINUITY";
    private static final String ENDLIST_TAG = "#EXT-X-ENDLIST";
    private static final String IV_ATTR = "IV";
    private static final Pattern IV_ATTR_REGEX = Pattern.compile("IV=([^,.*]+)");
    private static final String KEY_TAG = "#EXT-X-KEY";
    private static final String LANGUAGE_ATTR = "LANGUAGE";
    private static final Pattern LANGUAGE_ATTR_REGEX = Pattern.compile("LANGUAGE=\"(.+?)\"");
    private static final Pattern MEDIA_DURATION_REGEX = Pattern.compile("#EXTINF:([\\d.]+)\\b");
    private static final String MEDIA_DURATION_TAG = "#EXTINF";
    private static final Pattern MEDIA_SEQUENCE_REGEX = Pattern.compile("#EXT-X-MEDIA-SEQUENCE:(\\d+)\\b");
    private static final String MEDIA_SEQUENCE_TAG = "#EXT-X-MEDIA-SEQUENCE";
    private static final String MEDIA_TAG = "#EXT-X-MEDIA";
    private static final String METHOD_AES128 = "AES-128";
    private static final String METHOD_ATTR = "METHOD";
    private static final Pattern METHOD_ATTR_REGEX = Pattern.compile("METHOD=(NONE|AES-128)");
    private static final String METHOD_NONE = "NONE";
    private static final String NAME_ATTR = "NAME";
    private static final Pattern NAME_ATTR_REGEX = Pattern.compile("NAME=\"(.+?)\"");
    private static final String RESOLUTION_ATTR = "RESOLUTION";
    private static final Pattern RESOLUTION_ATTR_REGEX = Pattern.compile("RESOLUTION=(\\d+x\\d+)");
    private static final String STREAM_INF_TAG = "#EXT-X-STREAM-INF";
    private static final String SUBTITLES_TYPE = "SUBTITLES";
    private static final Pattern TARGET_DURATION_REGEX = Pattern.compile("#EXT-X-TARGETDURATION:(\\d+)\\b");
    private static final String TARGET_DURATION_TAG = "#EXT-X-TARGETDURATION";
    private static final String TYPE_ATTR = "TYPE";
    private static final Pattern TYPE_ATTR_REGEX = Pattern.compile("TYPE=(AUDIO|VIDEO|SUBTITLES|CLOSED-CAPTIONS)");
    private static final String URI_ATTR = "URI";
    private static final Pattern URI_ATTR_REGEX = Pattern.compile("URI=\"(.+?)\"");
    private static final Pattern VERSION_REGEX = Pattern.compile("#EXT-X-VERSION:(\\d+)\\b");
    private static final String VERSION_TAG = "#EXT-X-VERSION";
    private static final String VIDEO_TYPE = "VIDEO";

    private static class LineIterator {
        private final Queue<String> extraLines;
        private String next;
        private final BufferedReader reader;

        public LineIterator(Queue<String> queue, BufferedReader bufferedReader) {
            this.extraLines = queue;
            this.reader = bufferedReader;
        }

        public boolean hasNext() throws IOException {
            if (this.next != null) {
                return true;
            }
            if (this.extraLines.isEmpty()) {
                do {
                    String readLine = this.reader.readLine();
                    this.next = readLine;
                    if (readLine == null) {
                        return false;
                    }
                    this.next = this.next.trim();
                } while (this.next.isEmpty());
                return true;
            }
            this.next = (String) this.extraLines.poll();
            return true;
        }

        public String next() throws IOException {
            if (!hasNext()) {
                return null;
            }
            String str = this.next;
            this.next = null;
            return str;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.google.android.exoplayer.hls.HlsPlaylist parse(java.lang.String r5, java.io.InputStream r6) throws java.io.IOException, com.google.android.exoplayer.ParserException {
        /*
        r4 = this;
        r1 = new java.io.BufferedReader;
        r0 = new java.io.InputStreamReader;
        r0.<init>(r6);
        r1.<init>(r0);
        r0 = new java.util.LinkedList;
        r0.<init>();
    L_0x000f:
        r2 = r1.readLine();	 Catch:{ all -> 0x008b }
        if (r2 == 0) goto L_0x0090;
    L_0x0015:
        r2 = r2.trim();	 Catch:{ all -> 0x008b }
        r3 = r2.isEmpty();	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x000f;
    L_0x001f:
        r3 = "#EXT-X-STREAM-INF";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 == 0) goto L_0x0037;
    L_0x0027:
        r0.add(r2);	 Catch:{ all -> 0x008b }
        r2 = new com.google.android.exoplayer.hls.HlsPlaylistParser$LineIterator;	 Catch:{ all -> 0x008b }
        r2.<init>(r0, r1);	 Catch:{ all -> 0x008b }
        r0 = parseMasterPlaylist(r2, r5);	 Catch:{ all -> 0x008b }
        r1.close();
    L_0x0036:
        return r0;
    L_0x0037:
        r3 = "#EXT-X-TARGETDURATION";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x003f:
        r3 = "#EXT-X-MEDIA-SEQUENCE";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x0047:
        r3 = "#EXTINF";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x004f:
        r3 = "#EXT-X-KEY";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x0057:
        r3 = "#EXT-X-BYTERANGE";
        r3 = r2.startsWith(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x005f:
        r3 = "#EXT-X-DISCONTINUITY";
        r3 = r2.equals(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x0067:
        r3 = "#EXT-X-DISCONTINUITY-SEQUENCE";
        r3 = r2.equals(r3);	 Catch:{ all -> 0x008b }
        if (r3 != 0) goto L_0x0077;
    L_0x006f:
        r3 = "#EXT-X-ENDLIST";
        r3 = r2.equals(r3);	 Catch:{ all -> 0x008b }
        if (r3 == 0) goto L_0x0087;
    L_0x0077:
        r0.add(r2);	 Catch:{ all -> 0x008b }
        r2 = new com.google.android.exoplayer.hls.HlsPlaylistParser$LineIterator;	 Catch:{ all -> 0x008b }
        r2.<init>(r0, r1);	 Catch:{ all -> 0x008b }
        r0 = parseMediaPlaylist(r2, r5);	 Catch:{ all -> 0x008b }
        r1.close();
        goto L_0x0036;
    L_0x0087:
        r0.add(r2);	 Catch:{ all -> 0x008b }
        goto L_0x000f;
    L_0x008b:
        r0 = move-exception;
        r1.close();
        throw r0;
    L_0x0090:
        r1.close();
        r0 = new com.google.android.exoplayer.ParserException;
        r1 = "Failed to parse the playlist, could not identify any tags.";
        r0.<init>(r1);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer.hls.HlsPlaylistParser.parse(java.lang.String, java.io.InputStream):com.google.android.exoplayer.hls.HlsPlaylist");
    }

    private static HlsMasterPlaylist parseMasterPlaylist(LineIterator lineIterator, String str) throws IOException {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        String str2 = null;
        Object obj = null;
        String str3 = null;
        int i = -1;
        int i2 = -1;
        int i3 = 0;
        while (lineIterator.hasNext()) {
            String next = lineIterator.next();
            String parseStringAttr;
            if (next.startsWith(MEDIA_TAG)) {
                if (SUBTITLES_TYPE.equals(HlsParserUtil.parseStringAttr(next, TYPE_ATTR_REGEX, TYPE_ATTR))) {
                    parseStringAttr = HlsParserUtil.parseStringAttr(next, NAME_ATTR_REGEX, NAME_ATTR);
                    String parseStringAttr2 = HlsParserUtil.parseStringAttr(next, URI_ATTR_REGEX, URI_ATTR);
                    String parseOptionalStringAttr = HlsParserUtil.parseOptionalStringAttr(next, LANGUAGE_ATTR_REGEX);
                    arrayList2.add(new Variant(parseStringAttr2, new Format(parseStringAttr, MimeTypes.APPLICATION_M3U8, -1, -1, -1.0f, -1, -1, -1, parseOptionalStringAttr, str2)));
                }
            } else {
                if (next.startsWith(STREAM_INF_TAG)) {
                    int parseInt;
                    int parseInt2;
                    int parseIntAttr = HlsParserUtil.parseIntAttr(next, BANDWIDTH_ATTR_REGEX, BANDWIDTH_ATTR);
                    str2 = HlsParserUtil.parseOptionalStringAttr(next, CODECS_ATTR_REGEX);
                    String parseOptionalStringAttr2 = HlsParserUtil.parseOptionalStringAttr(next, NAME_ATTR_REGEX);
                    String parseOptionalStringAttr3 = HlsParserUtil.parseOptionalStringAttr(next, RESOLUTION_ATTR_REGEX);
                    if (parseOptionalStringAttr3 != null) {
                        String[] split = parseOptionalStringAttr3.split("x");
                        parseInt = Integer.parseInt(split[0]);
                        if (parseInt <= 0) {
                            parseInt = -1;
                        }
                        parseInt2 = Integer.parseInt(split[1]);
                        if (parseInt2 <= 0) {
                            parseInt2 = -1;
                        }
                    } else {
                        parseInt = -1;
                        parseInt2 = -1;
                    }
                    obj = 1;
                    str3 = parseOptionalStringAttr2;
                    i = parseInt2;
                    i2 = parseInt;
                    i3 = parseIntAttr;
                } else {
                    if (!(next.startsWith("#") || r14 == null)) {
                        if (str3 == null) {
                            parseStringAttr = Integer.toString(arrayList.size());
                        } else {
                            parseStringAttr = str3;
                        }
                        arrayList.add(new Variant(next, new Format(parseStringAttr, MimeTypes.APPLICATION_M3U8, i2, i, -1.0f, -1, -1, i3, null, str2)));
                        str2 = null;
                        obj = null;
                        str3 = null;
                        i = -1;
                        i2 = -1;
                        i3 = 0;
                    }
                }
            }
        }
        return new HlsMasterPlaylist(str, arrayList, arrayList2);
    }

    private static HlsMediaPlaylist parseMediaPlaylist(LineIterator lineIterator, String str) throws IOException {
        boolean z;
        List arrayList = new ArrayList();
        int i = 0;
        long j = 0;
        int i2 = -1;
        boolean z2 = false;
        String str2 = null;
        int i3 = 0;
        int i4 = 1;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        double d = 0.0d;
        String str3 = null;
        while (lineIterator.hasNext()) {
            String next = lineIterator.next();
            if (next.startsWith(TARGET_DURATION_TAG)) {
                i5 = HlsParserUtil.parseIntAttr(next, TARGET_DURATION_REGEX, TARGET_DURATION_TAG);
            } else if (next.startsWith(MEDIA_SEQUENCE_TAG)) {
                r2 = HlsParserUtil.parseIntAttr(next, MEDIA_SEQUENCE_REGEX, MEDIA_SEQUENCE_TAG);
                i7 = r2;
                i6 = r2;
            } else if (next.startsWith(VERSION_TAG)) {
                i4 = HlsParserUtil.parseIntAttr(next, VERSION_REGEX, VERSION_TAG);
            } else if (next.startsWith(MEDIA_DURATION_TAG)) {
                d = HlsParserUtil.parseDoubleAttr(next, MEDIA_DURATION_REGEX, MEDIA_DURATION_TAG);
            } else if (next.startsWith(KEY_TAG)) {
                z2 = "AES-128".equals(HlsParserUtil.parseStringAttr(next, METHOD_ATTR_REGEX, METHOD_ATTR));
                if (z2) {
                    str2 = HlsParserUtil.parseStringAttr(next, URI_ATTR_REGEX, URI_ATTR);
                    str3 = HlsParserUtil.parseOptionalStringAttr(next, IV_ATTR_REGEX);
                } else {
                    str2 = null;
                    str3 = null;
                }
            } else if (next.startsWith(BYTERANGE_TAG)) {
                String[] split = HlsParserUtil.parseStringAttr(next, BYTERANGE_REGEX, BYTERANGE_TAG).split("@");
                i2 = Integer.parseInt(split[0]);
                if (split.length > 1) {
                    r2 = Integer.parseInt(split[1]);
                } else {
                    r2 = i3;
                }
                i3 = r2;
            } else if (next.startsWith(DISCONTINUITY_SEQUENCE_TAG)) {
                i = Integer.parseInt(next.substring(next.indexOf(58) + 1));
            } else if (next.equals(DISCONTINUITY_TAG)) {
                i++;
            } else if (!next.startsWith("#")) {
                String str4;
                if (!z2) {
                    str4 = null;
                } else if (str3 != null) {
                    str4 = str3;
                } else {
                    str4 = Integer.toHexString(i7);
                }
                int i8 = i7 + 1;
                if (i2 == -1) {
                    i7 = 0;
                } else {
                    i7 = i3;
                }
                arrayList.add(new Segment(next, d, i, j, z2, str2, str4, i7, i2));
                j += (long) (1000000.0d * d);
                d = 0.0d;
                if (i2 != -1) {
                    r2 = i7 + i2;
                } else {
                    r2 = i7;
                }
                i2 = -1;
                i7 = i8;
                i3 = r2;
            } else if (next.equals(ENDLIST_TAG)) {
                z = false;
                break;
            }
        }
        z = true;
        return new HlsMediaPlaylist(str, i6, i5, i4, z, Collections.unmodifiableList(arrayList));
    }
}
