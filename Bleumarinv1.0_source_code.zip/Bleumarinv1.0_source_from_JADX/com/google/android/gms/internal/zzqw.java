package com.google.android.gms.internal;

import com.google.android.gms.plus.zza;

public final class zzqw implements zza {
}
