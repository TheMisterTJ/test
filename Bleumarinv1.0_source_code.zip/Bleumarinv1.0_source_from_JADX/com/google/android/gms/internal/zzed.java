package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.zze;

public interface zzed extends zzeh {

    public interface zza {
        void zzeo();
    }

    void destroy();

    void zzZ(String str);

    void zza(com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza, zzg com_google_android_gms_ads_internal_overlay_zzg, zzdb com_google_android_gms_internal_zzdb, zzp com_google_android_gms_ads_internal_overlay_zzp, boolean z, zzdh com_google_android_gms_internal_zzdh, zzdj com_google_android_gms_internal_zzdj, zze com_google_android_gms_ads_internal_zze, zzft com_google_android_gms_internal_zzft);

    void zza(zza com_google_android_gms_internal_zzed_zza);

    void zzaa(String str);

    void zzab(String str);

    zzei zzen();
}
