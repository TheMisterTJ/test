package com.google.android.exoplayer.metadata.id3;

import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.metadata.MetadataParser;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.ParsableByteArray;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class Id3Parser implements MetadataParser<List<Id3Frame>> {
    private static final int ID3_TEXT_ENCODING_ISO_8859_1 = 0;
    private static final int ID3_TEXT_ENCODING_UTF_16 = 1;
    private static final int ID3_TEXT_ENCODING_UTF_16BE = 2;
    private static final int ID3_TEXT_ENCODING_UTF_8 = 3;

    public final boolean canParse(String str) {
        return str.equals(MimeTypes.APPLICATION_ID3);
    }

    public final List<Id3Frame> parse(byte[] bArr, int i) throws UnsupportedEncodingException, ParserException {
        List arrayList = new ArrayList();
        ParsableByteArray parsableByteArray = new ParsableByteArray(bArr, i);
        int parseId3Header = parseId3Header(parsableByteArray);
        while (parseId3Header > 0) {
            int readUnsignedByte = parsableByteArray.readUnsignedByte();
            int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
            int readUnsignedByte3 = parsableByteArray.readUnsignedByte();
            int readUnsignedByte4 = parsableByteArray.readUnsignedByte();
            int readSynchSafeInt = parsableByteArray.readSynchSafeInt();
            if (readSynchSafeInt <= 1) {
                break;
            }
            parsableByteArray.skipBytes(2);
            String charsetName;
            String str;
            if (readUnsignedByte == 84 && readUnsignedByte2 == 88 && readUnsignedByte3 == 88 && readUnsignedByte4 == 88) {
                readUnsignedByte = parsableByteArray.readUnsignedByte();
                charsetName = getCharsetName(readUnsignedByte);
                byte[] bArr2 = new byte[(readSynchSafeInt - 1)];
                parsableByteArray.readBytes(bArr2, 0, readSynchSafeInt - 1);
                readUnsignedByte4 = indexOfEOS(bArr2, 0, readUnsignedByte);
                str = new String(bArr2, 0, readUnsignedByte4, charsetName);
                readUnsignedByte4 += delimiterLength(readUnsignedByte);
                arrayList.add(new TxxxFrame(str, new String(bArr2, readUnsignedByte4, indexOfEOS(bArr2, readUnsignedByte4, readUnsignedByte) - readUnsignedByte4, charsetName)));
            } else if (readUnsignedByte == 80 && readUnsignedByte2 == 82 && readUnsignedByte3 == 73 && readUnsignedByte4 == 86) {
                Object obj = new byte[readSynchSafeInt];
                parsableByteArray.readBytes(obj, 0, readSynchSafeInt);
                readUnsignedByte2 = indexOf(obj, 0, (byte) 0);
                String str2 = new String(obj, 0, readUnsignedByte2, "ISO-8859-1");
                r6 = new byte[((readSynchSafeInt - readUnsignedByte2) - 1)];
                System.arraycopy(obj, readUnsignedByte2 + 1, r6, 0, (readSynchSafeInt - readUnsignedByte2) - 1);
                arrayList.add(new PrivFrame(str2, r6));
            } else if (readUnsignedByte == 71 && readUnsignedByte2 == 69 && readUnsignedByte3 == 79 && readUnsignedByte4 == 66) {
                readUnsignedByte = parsableByteArray.readUnsignedByte();
                charsetName = getCharsetName(readUnsignedByte);
                Object obj2 = new byte[(readSynchSafeInt - 1)];
                parsableByteArray.readBytes(obj2, 0, readSynchSafeInt - 1);
                readUnsignedByte4 = indexOf(obj2, 0, (byte) 0);
                str = new String(obj2, 0, readUnsignedByte4, "ISO-8859-1");
                readUnsignedByte4++;
                int indexOfEOS = indexOfEOS(obj2, readUnsignedByte4, readUnsignedByte);
                String str3 = new String(obj2, readUnsignedByte4, indexOfEOS - readUnsignedByte4, charsetName);
                readUnsignedByte4 = delimiterLength(readUnsignedByte) + indexOfEOS;
                indexOfEOS = indexOfEOS(obj2, readUnsignedByte4, readUnsignedByte);
                String str4 = new String(obj2, readUnsignedByte4, indexOfEOS - readUnsignedByte4, charsetName);
                readUnsignedByte2 = ((readSynchSafeInt - 1) - indexOfEOS) - delimiterLength(readUnsignedByte);
                r6 = new byte[readUnsignedByte2];
                System.arraycopy(obj2, delimiterLength(readUnsignedByte) + indexOfEOS, r6, 0, readUnsignedByte2);
                arrayList.add(new GeobFrame(str, str3, str4, r6));
            } else {
                String format = String.format(Locale.US, "%c%c%c%c", new Object[]{Integer.valueOf(readUnsignedByte), Integer.valueOf(readUnsignedByte2), Integer.valueOf(readUnsignedByte3), Integer.valueOf(readUnsignedByte4)});
                byte[] bArr3 = new byte[readSynchSafeInt];
                parsableByteArray.readBytes(bArr3, 0, readSynchSafeInt);
                arrayList.add(new BinaryFrame(format, bArr3));
            }
            parseId3Header -= readSynchSafeInt + 10;
        }
        return Collections.unmodifiableList(arrayList);
    }

    private static int indexOf(byte[] bArr, int i, byte b) {
        while (i < bArr.length) {
            if (bArr[i] == b) {
                return i;
            }
            i++;
        }
        return bArr.length;
    }

    private static int indexOfEOS(byte[] bArr, int i, int i2) {
        int indexOf = indexOf(bArr, i, (byte) 0);
        if (i2 == 0 || i2 == 3) {
            return indexOf;
        }
        while (indexOf < bArr.length - 1) {
            if (bArr[indexOf + 1] == (byte) 0) {
                return indexOf;
            }
            indexOf = indexOf(bArr, indexOf + 1, (byte) 0);
        }
        return bArr.length;
    }

    private static int delimiterLength(int i) {
        return (i == 0 || i == 3) ? 1 : 2;
    }

    private static int parseId3Header(ParsableByteArray parsableByteArray) throws ParserException {
        int readUnsignedByte = parsableByteArray.readUnsignedByte();
        int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
        int readUnsignedByte3 = parsableByteArray.readUnsignedByte();
        if (readUnsignedByte == 73 && readUnsignedByte2 == 68 && readUnsignedByte3 == 51) {
            parsableByteArray.skipBytes(2);
            readUnsignedByte2 = parsableByteArray.readUnsignedByte();
            readUnsignedByte = parsableByteArray.readSynchSafeInt();
            if ((readUnsignedByte2 & 2) != 0) {
                readUnsignedByte3 = parsableByteArray.readSynchSafeInt();
                if (readUnsignedByte3 > 4) {
                    parsableByteArray.skipBytes(readUnsignedByte3 - 4);
                }
                readUnsignedByte -= readUnsignedByte3;
            }
            if ((readUnsignedByte2 & 8) != 0) {
                return readUnsignedByte - 10;
            }
            return readUnsignedByte;
        }
        throw new ParserException(String.format(Locale.US, "Unexpected ID3 file identifier, expected \"ID3\", actual \"%c%c%c\".", new Object[]{Integer.valueOf(readUnsignedByte), Integer.valueOf(readUnsignedByte2), Integer.valueOf(readUnsignedByte3)}));
    }

    private static String getCharsetName(int i) {
        switch (i) {
            case 0:
                return "ISO-8859-1";
            case 1:
                return "UTF-16";
            case 2:
                return "UTF-16BE";
            case 3:
                return C1893C.UTF8_NAME;
            default:
                return "ISO-8859-1";
        }
    }
}
