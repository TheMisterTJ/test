package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import java.util.Collections;
import java.util.List;

@zzhb
public class zzbn implements zzbo {
    public List<String> zza(AdRequestInfoParcel adRequestInfoParcel) {
        return adRequestInfoParcel.zzHJ == null ? Collections.emptyList() : adRequestInfoParcel.zzHJ;
    }
}
