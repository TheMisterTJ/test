package com.google.android.exoplayer.drm;

public final class KeysExpiredException extends Exception {
}
