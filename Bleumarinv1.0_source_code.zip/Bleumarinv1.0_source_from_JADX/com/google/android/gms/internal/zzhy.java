package com.google.android.gms.internal;

public interface zzhy {
    void zza(String str, int i);

    void zzax(String str);
}
