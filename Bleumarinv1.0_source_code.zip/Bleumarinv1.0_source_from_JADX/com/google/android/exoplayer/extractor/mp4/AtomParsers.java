package com.google.android.exoplayer.extractor.mp4;

import android.support.v4.internal.view.SupportMenu;
import android.support.v4.media.TransportMediator;
import android.util.Pair;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.extractor.GaplessInfo;
import com.google.android.exoplayer.util.Ac3Util;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.CodecSpecificDataUtil;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.NalUnitUtil;
import com.google.android.exoplayer.util.ParsableBitArray;
import com.google.android.exoplayer.util.ParsableByteArray;
import com.google.android.exoplayer.util.Util;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class AtomParsers {

    private static final class AvcCData {
        public final List<byte[]> initializationData;
        public final int nalUnitLengthFieldLength;
        public final float pixelWidthAspectRatio;

        public AvcCData(List<byte[]> list, int i, float f) {
            this.initializationData = list;
            this.nalUnitLengthFieldLength = i;
            this.pixelWidthAspectRatio = f;
        }
    }

    private static final class StsdData {
        public MediaFormat mediaFormat;
        public int nalUnitLengthFieldLength = -1;
        public final TrackEncryptionBox[] trackEncryptionBoxes;

        public StsdData(int i) {
            this.trackEncryptionBoxes = new TrackEncryptionBox[i];
        }
    }

    private static final class TkhdData {
        private final long duration;
        private final int id;
        private final int rotationDegrees;

        public TkhdData(int i, long j, int i2) {
            this.id = i;
            this.duration = j;
            this.rotationDegrees = i2;
        }
    }

    public static Track parseTrak(ContainerAtom containerAtom, LeafAtom leafAtom, boolean z) {
        ContainerAtom containerAtomOfType = containerAtom.getContainerAtomOfType(Atom.TYPE_mdia);
        int parseHdlr = parseHdlr(containerAtomOfType.getLeafAtomOfType(Atom.TYPE_hdlr).data);
        if (parseHdlr != Track.TYPE_soun && parseHdlr != Track.TYPE_vide && parseHdlr != Track.TYPE_text && parseHdlr != Track.TYPE_sbtl && parseHdlr != Track.TYPE_subt) {
            return null;
        }
        long j;
        TkhdData parseTkhd = parseTkhd(containerAtom.getLeafAtomOfType(Atom.TYPE_tkhd).data);
        long access$000 = parseTkhd.duration;
        long parseMvhd = parseMvhd(leafAtom.data);
        if (access$000 == -1) {
            j = -1;
        } else {
            j = Util.scaleLargeTimestamp(access$000, C1893C.MICROS_PER_SECOND, parseMvhd);
        }
        ContainerAtom containerAtomOfType2 = containerAtomOfType.getContainerAtomOfType(Atom.TYPE_minf).getContainerAtomOfType(Atom.TYPE_stbl);
        Pair parseMdhd = parseMdhd(containerAtomOfType.getLeafAtomOfType(Atom.TYPE_mdhd).data);
        StsdData parseStsd = parseStsd(containerAtomOfType2.getLeafAtomOfType(Atom.TYPE_stsd).data, parseTkhd.id, j, parseTkhd.rotationDegrees, (String) parseMdhd.second, z);
        Pair parseEdts = parseEdts(containerAtom.getContainerAtomOfType(Atom.TYPE_edts));
        if (parseStsd.mediaFormat == null) {
            return null;
        }
        return new Track(parseTkhd.id, parseHdlr, ((Long) parseMdhd.first).longValue(), parseMvhd, j, parseStsd.mediaFormat, parseStsd.trackEncryptionBoxes, parseStsd.nalUnitLengthFieldLength, (long[]) parseEdts.first, (long[]) parseEdts.second);
    }

    public static TrackSampleTable parseStbl(Track track, ContainerAtom containerAtom) {
        ParsableByteArray parsableByteArray;
        ParsableByteArray parsableByteArray2 = containerAtom.getLeafAtomOfType(Atom.TYPE_stsz).data;
        LeafAtom leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_stco);
        if (leafAtomOfType == null) {
            leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_co64);
        }
        ParsableByteArray parsableByteArray3 = leafAtomOfType.data;
        ParsableByteArray parsableByteArray4 = containerAtom.getLeafAtomOfType(Atom.TYPE_stsc).data;
        ParsableByteArray parsableByteArray5 = containerAtom.getLeafAtomOfType(Atom.TYPE_stts).data;
        LeafAtom leafAtomOfType2 = containerAtom.getLeafAtomOfType(Atom.TYPE_stss);
        ParsableByteArray parsableByteArray6 = leafAtomOfType2 != null ? leafAtomOfType2.data : null;
        leafAtomOfType2 = containerAtom.getLeafAtomOfType(Atom.TYPE_ctts);
        if (leafAtomOfType2 != null) {
            parsableByteArray = leafAtomOfType2.data;
        } else {
            parsableByteArray = null;
        }
        parsableByteArray2.setPosition(12);
        int readUnsignedIntToInt = parsableByteArray2.readUnsignedIntToInt();
        int readUnsignedIntToInt2 = parsableByteArray2.readUnsignedIntToInt();
        Object obj = new long[readUnsignedIntToInt2];
        Object obj2 = new int[readUnsignedIntToInt2];
        long[] jArr = new long[readUnsignedIntToInt2];
        Object obj3 = new int[readUnsignedIntToInt2];
        if (readUnsignedIntToInt2 == 0) {
            return new TrackSampleTable(obj, obj2, 0, jArr, obj3);
        }
        long readUnsignedInt;
        parsableByteArray3.setPosition(12);
        int readUnsignedIntToInt3 = parsableByteArray3.readUnsignedIntToInt();
        parsableByteArray4.setPosition(12);
        int readUnsignedIntToInt4 = parsableByteArray4.readUnsignedIntToInt() - 1;
        Assertions.checkState(parsableByteArray4.readInt() == 1, "stsc first chunk must be 1");
        int readUnsignedIntToInt5 = parsableByteArray4.readUnsignedIntToInt();
        parsableByteArray4.skipBytes(4);
        int i = -1;
        if (readUnsignedIntToInt4 > 0) {
            i = parsableByteArray4.readUnsignedIntToInt() - 1;
        }
        parsableByteArray5.setPosition(12);
        int readUnsignedIntToInt6 = parsableByteArray5.readUnsignedIntToInt() - 1;
        int readUnsignedIntToInt7 = parsableByteArray5.readUnsignedIntToInt();
        int readUnsignedIntToInt8 = parsableByteArray5.readUnsignedIntToInt();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        if (parsableByteArray != null) {
            parsableByteArray.setPosition(12);
            i3 = parsableByteArray.readUnsignedIntToInt() - 1;
            i2 = parsableByteArray.readUnsignedIntToInt();
            i4 = parsableByteArray.readInt();
        }
        int i5 = -1;
        int i6 = 0;
        if (parsableByteArray6 != null) {
            parsableByteArray6.setPosition(12);
            i6 = parsableByteArray6.readUnsignedIntToInt();
            i5 = parsableByteArray6.readUnsignedIntToInt() - 1;
        }
        if (leafAtomOfType.type == Atom.TYPE_stco) {
            readUnsignedInt = parsableByteArray3.readUnsignedInt();
        } else {
            readUnsignedInt = parsableByteArray3.readUnsignedLongToLong();
        }
        long j = 0;
        int i7 = 0;
        int i8 = readUnsignedIntToInt5;
        int i9 = i2;
        int i10 = i;
        int i11 = readUnsignedIntToInt5;
        i2 = i6;
        readUnsignedIntToInt5 = readUnsignedIntToInt4;
        i = 0;
        long j2 = readUnsignedInt;
        int i12 = 0;
        int i13 = i3;
        long j3 = j2;
        i3 = readUnsignedIntToInt6;
        int i14 = i4;
        i4 = readUnsignedIntToInt8;
        readUnsignedIntToInt8 = i5;
        i5 = i14;
        while (i7 < readUnsignedIntToInt2) {
            int i15;
            int readUnsignedIntToInt9;
            long j4;
            int i16;
            obj[i7] = j3;
            if (readUnsignedIntToInt == 0) {
                i6 = parsableByteArray2.readUnsignedIntToInt();
            } else {
                i6 = readUnsignedIntToInt;
            }
            obj2[i7] = i6;
            if (obj2[i7] > i) {
                i = obj2[i7];
            }
            jArr[i7] = ((long) i5) + j;
            obj3[i7] = parsableByteArray6 == null ? 1 : null;
            if (i7 == readUnsignedIntToInt8) {
                obj3[i7] = 1;
                i6 = i2 - 1;
                if (i6 > 0) {
                    i15 = i6;
                    readUnsignedIntToInt9 = parsableByteArray6.readUnsignedIntToInt() - 1;
                } else {
                    i15 = i6;
                    readUnsignedIntToInt9 = readUnsignedIntToInt8;
                }
            } else {
                i15 = i2;
                readUnsignedIntToInt9 = readUnsignedIntToInt8;
            }
            j += (long) i4;
            i6 = readUnsignedIntToInt7 - 1;
            if (i6 != 0 || i3 <= 0) {
                readUnsignedIntToInt8 = i4;
                readUnsignedIntToInt7 = i6;
                readUnsignedIntToInt6 = i3;
            } else {
                i4 = parsableByteArray5.readUnsignedIntToInt();
                readUnsignedIntToInt8 = parsableByteArray5.readUnsignedIntToInt();
                readUnsignedIntToInt7 = i4;
                readUnsignedIntToInt6 = i3 - 1;
            }
            if (parsableByteArray != null) {
                i6 = i9 - 1;
                if (i6 != 0 || i13 <= 0) {
                    i4 = i5;
                    i3 = i13;
                    i2 = i6;
                } else {
                    i9 = parsableByteArray.readUnsignedIntToInt();
                    i4 = parsableByteArray.readInt();
                    i3 = i13 - 1;
                    i2 = i9;
                }
            } else {
                i4 = i5;
                i3 = i13;
                i2 = i9;
            }
            i13 = i8 - 1;
            if (i13 == 0) {
                i9 = i12 + 1;
                if (i9 >= readUnsignedIntToInt3) {
                    j4 = j3;
                } else if (leafAtomOfType.type == Atom.TYPE_stco) {
                    j4 = parsableByteArray3.readUnsignedInt();
                } else {
                    j4 = parsableByteArray3.readUnsignedLongToLong();
                }
                if (i9 == i10) {
                    i12 = parsableByteArray4.readUnsignedIntToInt();
                    parsableByteArray4.skipBytes(4);
                    i11 = readUnsignedIntToInt5 - 1;
                    if (i11 > 0) {
                        i10 = parsableByteArray4.readUnsignedIntToInt() - 1;
                    }
                } else {
                    i12 = i11;
                    i11 = readUnsignedIntToInt5;
                }
                if (i9 < readUnsignedIntToInt3) {
                    i13 = i9;
                    i9 = i10;
                    i10 = i12;
                } else {
                    i16 = i13;
                    i13 = i9;
                    i9 = i10;
                    i10 = i12;
                    i12 = i16;
                }
            } else {
                j4 = ((long) obj2[i7]) + j3;
                i9 = i10;
                i10 = i11;
                i11 = readUnsignedIntToInt5;
                i16 = i12;
                i12 = i13;
                i13 = i16;
            }
            j3 = j4;
            i7++;
            i8 = i12;
            i5 = i4;
            i12 = i13;
            readUnsignedIntToInt5 = i11;
            i4 = readUnsignedIntToInt8;
            i11 = i10;
            i13 = i3;
            readUnsignedIntToInt8 = readUnsignedIntToInt9;
            i10 = i9;
            i3 = readUnsignedIntToInt6;
            i9 = i2;
            i2 = i15;
        }
        Assertions.checkArgument(i2 == 0);
        Assertions.checkArgument(readUnsignedIntToInt7 == 0);
        Assertions.checkArgument(i8 == 0);
        Assertions.checkArgument(i3 == 0);
        Assertions.checkArgument(i13 == 0);
        if (track.editListDurations == null) {
            Util.scaleLargeTimestampsInPlace(jArr, C1893C.MICROS_PER_SECOND, track.timescale);
            return new TrackSampleTable(obj, obj2, i, jArr, obj3);
        } else if (track.editListDurations.length == 1 && track.editListDurations[0] == 0) {
            for (r2 = 0; r2 < jArr.length; r2++) {
                jArr[r2] = Util.scaleLargeTimestamp(jArr[r2] - track.editListMediaTimes[0], C1893C.MICROS_PER_SECOND, track.timescale);
            }
            return new TrackSampleTable(obj, obj2, i, jArr, obj3);
        } else {
            long scaleLargeTimestamp;
            Object obj4;
            Object obj5;
            Object obj6;
            r2 = 0;
            readUnsignedIntToInt = 0;
            i9 = 0;
            i10 = 0;
            while (readUnsignedIntToInt < track.editListDurations.length) {
                int i17;
                long j5 = track.editListMediaTimes[readUnsignedIntToInt];
                if (j5 != -1) {
                    scaleLargeTimestamp = Util.scaleLargeTimestamp(track.editListDurations[readUnsignedIntToInt], track.timescale, track.movieTimescale);
                    i5 = Util.binarySearchCeil(jArr, j5, true, true);
                    i6 = Util.binarySearchCeil(jArr, scaleLargeTimestamp + j5, true, false);
                    int i18 = (i6 - i5) + r2;
                    if (i10 != i5) {
                        r2 = 1;
                    } else {
                        r2 = 0;
                    }
                    i17 = i9 | r2;
                    r2 = i18;
                } else {
                    i17 = i9;
                    i6 = i10;
                }
                readUnsignedIntToInt++;
                i9 = i17;
                i10 = i6;
            }
            readUnsignedIntToInt4 = i9 | (r2 != readUnsignedIntToInt2 ? 1 : 0);
            if (readUnsignedIntToInt4 != 0) {
                obj4 = new long[r2];
            } else {
                obj4 = obj;
            }
            if (readUnsignedIntToInt4 != 0) {
                obj5 = new int[r2];
            } else {
                obj5 = obj2;
            }
            if (readUnsignedIntToInt4 != 0) {
                i6 = 0;
            } else {
                i6 = i;
            }
            if (readUnsignedIntToInt4 != 0) {
                obj6 = new int[r2];
            } else {
                obj6 = obj3;
            }
            long[] jArr2 = new long[r2];
            scaleLargeTimestamp = 0;
            i11 = 0;
            r2 = 0;
            i = i6;
            while (i11 < track.editListDurations.length) {
                long j6 = track.editListMediaTimes[i11];
                long j7 = track.editListDurations[i11];
                if (j6 != -1) {
                    readUnsignedInt = j6 + Util.scaleLargeTimestamp(j7, track.timescale, track.movieTimescale);
                    i6 = Util.binarySearchCeil(jArr, j6, true, true);
                    i2 = Util.binarySearchCeil(jArr, readUnsignedInt, true, false);
                    if (readUnsignedIntToInt4 != 0) {
                        i5 = i2 - i6;
                        System.arraycopy(obj, i6, obj4, r2, i5);
                        System.arraycopy(obj2, i6, obj5, r2, i5);
                        System.arraycopy(obj3, i6, obj6, r2, i5);
                    }
                    readUnsignedIntToInt5 = i6;
                    i16 = i;
                    i = r2;
                    r2 = i16;
                    while (readUnsignedIntToInt5 < i2) {
                        jArr2[i] = Util.scaleLargeTimestamp(jArr[readUnsignedIntToInt5] - j6, C1893C.MICROS_PER_SECOND, track.timescale) + Util.scaleLargeTimestamp(scaleLargeTimestamp, C1893C.MICROS_PER_SECOND, track.movieTimescale);
                        if (readUnsignedIntToInt4 != 0 && obj5[i] > r2) {
                            r2 = obj2[readUnsignedIntToInt5];
                        }
                        readUnsignedIntToInt5++;
                        i++;
                    }
                } else {
                    i16 = i;
                    i = r2;
                    r2 = i16;
                }
                scaleLargeTimestamp += j7;
                i11++;
                i16 = r2;
                r2 = i;
                i = i16;
            }
            return new TrackSampleTable(obj4, obj5, i, jArr2, obj6);
        }
    }

    public static GaplessInfo parseUdta(ContainerAtom containerAtom) {
        LeafAtom leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_meta);
        if (leafAtomOfType == null) {
            return null;
        }
        ParsableByteArray parsableByteArray = leafAtomOfType.data;
        parsableByteArray.setPosition(12);
        ParsableByteArray parsableByteArray2 = new ParsableByteArray();
        while (parsableByteArray.bytesLeft() > 0) {
            int readInt = parsableByteArray.readInt() - 8;
            if (parsableByteArray.readInt() == Atom.TYPE_ilst) {
                parsableByteArray2.reset(parsableByteArray.data, parsableByteArray.getPosition() + readInt);
                parsableByteArray2.setPosition(parsableByteArray.getPosition());
                GaplessInfo parseIlst = parseIlst(parsableByteArray2);
                if (parseIlst != null) {
                    return parseIlst;
                }
            }
            parsableByteArray.skipBytes(readInt);
        }
        return null;
    }

    private static GaplessInfo parseIlst(ParsableByteArray parsableByteArray) {
        while (parsableByteArray.bytesLeft() > 0) {
            int position = parsableByteArray.getPosition() + parsableByteArray.readInt();
            if (parsableByteArray.readInt() == Atom.TYPE_DASHES) {
                String str = null;
                String str2 = null;
                Object obj = null;
                while (parsableByteArray.getPosition() < position) {
                    int readInt = parsableByteArray.readInt() - 12;
                    int readInt2 = parsableByteArray.readInt();
                    parsableByteArray.skipBytes(4);
                    if (readInt2 == Atom.TYPE_mean) {
                        obj = parsableByteArray.readString(readInt);
                    } else if (readInt2 == Atom.TYPE_name) {
                        str2 = parsableByteArray.readString(readInt);
                    } else if (readInt2 == Atom.TYPE_data) {
                        parsableByteArray.skipBytes(4);
                        str = parsableByteArray.readString(readInt - 4);
                    } else {
                        parsableByteArray.skipBytes(readInt);
                    }
                }
                if (!(str2 == null || str == null || !"com.apple.iTunes".equals(r3))) {
                    return GaplessInfo.createFromComment(str2, str);
                }
            }
            parsableByteArray.setPosition(position);
        }
        return null;
    }

    private static long parseMvhd(ParsableByteArray parsableByteArray) {
        int i = 8;
        parsableByteArray.setPosition(8);
        if (Atom.parseFullAtomVersion(parsableByteArray.readInt()) != 0) {
            i = 16;
        }
        parsableByteArray.skipBytes(i);
        return parsableByteArray.readUnsignedInt();
    }

    private static TkhdData parseTkhd(ParsableByteArray parsableByteArray) {
        int i;
        long j;
        int i2 = 8;
        parsableByteArray.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray.skipBytes(parseFullAtomVersion == 0 ? 8 : 16);
        int readInt = parsableByteArray.readInt();
        parsableByteArray.skipBytes(4);
        Object obj = 1;
        int position = parsableByteArray.getPosition();
        if (parseFullAtomVersion == 0) {
            i2 = 4;
        }
        for (i = 0; i < i2; i++) {
            if (parsableByteArray.data[position + i] != (byte) -1) {
                obj = null;
                break;
            }
        }
        if (obj != null) {
            parsableByteArray.skipBytes(i2);
            j = -1;
        } else {
            j = parseFullAtomVersion == 0 ? parsableByteArray.readUnsignedInt() : parsableByteArray.readUnsignedLongToLong();
        }
        parsableByteArray.skipBytes(16);
        int readInt2 = parsableByteArray.readInt();
        i = parsableByteArray.readInt();
        parsableByteArray.skipBytes(4);
        int readInt3 = parsableByteArray.readInt();
        parseFullAtomVersion = parsableByteArray.readInt();
        readInt2 = (readInt2 == 0 && i == 65536 && readInt3 == SupportMenu.CATEGORY_MASK && parseFullAtomVersion == 0) ? 90 : (readInt2 == 0 && i == SupportMenu.CATEGORY_MASK && readInt3 == 65536 && parseFullAtomVersion == 0) ? 270 : (readInt2 == SupportMenu.CATEGORY_MASK && i == 0 && readInt3 == 0 && parseFullAtomVersion == SupportMenu.CATEGORY_MASK) ? 180 : 0;
        return new TkhdData(readInt, j, readInt2);
    }

    private static int parseHdlr(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(16);
        return parsableByteArray.readInt();
    }

    private static Pair<Long, String> parseMdhd(ParsableByteArray parsableByteArray) {
        int i = 8;
        parsableByteArray.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray.skipBytes(parseFullAtomVersion == 0 ? 8 : 16);
        long readUnsignedInt = parsableByteArray.readUnsignedInt();
        if (parseFullAtomVersion == 0) {
            i = 4;
        }
        parsableByteArray.skipBytes(i);
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        return Pair.create(Long.valueOf(readUnsignedInt), ((char) (((readUnsignedShort >> 10) & 31) + 96)) + ((char) (((readUnsignedShort >> 5) & 31) + 96)) + ((char) ((readUnsignedShort & 31) + 96)));
    }

    private static StsdData parseStsd(ParsableByteArray parsableByteArray, int i, long j, int i2, String str, boolean z) {
        parsableByteArray.setPosition(12);
        int readInt = parsableByteArray.readInt();
        StsdData stsdData = new StsdData(readInt);
        for (int i3 = 0; i3 < readInt; i3++) {
            int position = parsableByteArray.getPosition();
            int readInt2 = parsableByteArray.readInt();
            Assertions.checkArgument(readInt2 > 0, "childAtomSize should be positive");
            int readInt3 = parsableByteArray.readInt();
            if (readInt3 == Atom.TYPE_avc1 || readInt3 == Atom.TYPE_avc3 || readInt3 == Atom.TYPE_encv || readInt3 == Atom.TYPE_mp4v || readInt3 == Atom.TYPE_hvc1 || readInt3 == Atom.TYPE_hev1 || readInt3 == Atom.TYPE_s263) {
                parseVideoSampleEntry(parsableByteArray, position, readInt2, i, j, i2, stsdData, i3);
            } else if (readInt3 == Atom.TYPE_mp4a || readInt3 == Atom.TYPE_enca || readInt3 == Atom.TYPE_ac_3 || readInt3 == Atom.TYPE_ec_3 || readInt3 == Atom.TYPE_dtsc || readInt3 == Atom.TYPE_dtse || readInt3 == Atom.TYPE_dtsh || readInt3 == Atom.TYPE_dtsl || readInt3 == Atom.TYPE_samr || readInt3 == Atom.TYPE_sawb) {
                parseAudioSampleEntry(parsableByteArray, readInt3, position, readInt2, i, j, str, z, stsdData, i3);
            } else if (readInt3 == Atom.TYPE_TTML) {
                stsdData.mediaFormat = MediaFormat.createTextFormat(Integer.toString(i), MimeTypes.APPLICATION_TTML, -1, j, str);
            } else if (readInt3 == Atom.TYPE_tx3g) {
                stsdData.mediaFormat = MediaFormat.createTextFormat(Integer.toString(i), MimeTypes.APPLICATION_TX3G, -1, j, str);
            } else if (readInt3 == Atom.TYPE_wvtt) {
                stsdData.mediaFormat = MediaFormat.createTextFormat(Integer.toString(i), MimeTypes.APPLICATION_MP4VTT, -1, j, str);
            } else if (readInt3 == Atom.TYPE_stpp) {
                stsdData.mediaFormat = MediaFormat.createTextFormat(Integer.toString(i), MimeTypes.APPLICATION_TTML, -1, j, str, 0);
            }
            parsableByteArray.setPosition(position + readInt2);
        }
        return stsdData;
    }

    private static void parseVideoSampleEntry(ParsableByteArray parsableByteArray, int i, int i2, int i3, long j, int i4, StsdData stsdData, int i5) {
        parsableByteArray.setPosition(i + 8);
        parsableByteArray.skipBytes(24);
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
        Object obj = null;
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        parsableByteArray.skipBytes(50);
        List list = null;
        String str = null;
        int position = parsableByteArray.getPosition();
        while (position - i < i2) {
            parsableByteArray.setPosition(position);
            int position2 = parsableByteArray.getPosition();
            int readInt = parsableByteArray.readInt();
            if (readInt == 0 && parsableByteArray.getPosition() - i == i2) {
                break;
            }
            Object obj2;
            Assertions.checkArgument(readInt > 0, "childAtomSize should be positive");
            int readInt2 = parsableByteArray.readInt();
            if (readInt2 == Atom.TYPE_avcC) {
                Assertions.checkState(str == null);
                str = MimeTypes.VIDEO_H264;
                AvcCData parseAvcCFromParent = parseAvcCFromParent(parsableByteArray, position2);
                list = parseAvcCFromParent.initializationData;
                stsdData.nalUnitLengthFieldLength = parseAvcCFromParent.nalUnitLengthFieldLength;
                if (obj == null) {
                    f = parseAvcCFromParent.pixelWidthAspectRatio;
                }
                obj2 = obj;
            } else if (readInt2 == Atom.TYPE_hvcC) {
                Assertions.checkState(str == null);
                String str2 = MimeTypes.VIDEO_H265;
                Pair parseHvcCFromParent = parseHvcCFromParent(parsableByteArray, position2);
                List list2 = (List) parseHvcCFromParent.first;
                stsdData.nalUnitLengthFieldLength = ((Integer) parseHvcCFromParent.second).intValue();
                list = list2;
                obj2 = obj;
                str = str2;
            } else if (readInt2 == Atom.TYPE_d263) {
                Assertions.checkState(str == null);
                str = MimeTypes.VIDEO_H263;
                obj2 = obj;
            } else if (readInt2 == Atom.TYPE_esds) {
                Assertions.checkState(str == null);
                Pair parseEsdsFromParent = parseEsdsFromParent(parsableByteArray, position2);
                String str3 = (String) parseEsdsFromParent.first;
                list = Collections.singletonList(parseEsdsFromParent.second);
                str = str3;
                obj2 = obj;
            } else if (readInt2 == Atom.TYPE_sinf) {
                stsdData.trackEncryptionBoxes[i5] = parseSinfFromParent(parsableByteArray, position2, readInt);
                obj2 = obj;
            } else if (readInt2 == Atom.TYPE_pasp) {
                f = parsePaspFromParent(parsableByteArray, position2);
                obj2 = 1;
            } else {
                obj2 = obj;
            }
            position += readInt;
            obj = obj2;
        }
        if (str != null) {
            stsdData.mediaFormat = MediaFormat.createVideoFormat(Integer.toString(i3), str, -1, -1, j, readUnsignedShort, readUnsignedShort2, list, i4, f);
        }
    }

    private static AvcCData parseAvcCFromParent(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.setPosition((i + 8) + 4);
        int readUnsignedByte = (parsableByteArray.readUnsignedByte() & 3) + 1;
        if (readUnsignedByte == 3) {
            throw new IllegalStateException();
        }
        int i2;
        List arrayList = new ArrayList();
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        int readUnsignedByte2 = parsableByteArray.readUnsignedByte() & 31;
        for (i2 = 0; i2 < readUnsignedByte2; i2++) {
            arrayList.add(NalUnitUtil.parseChildNalUnit(parsableByteArray));
        }
        int readUnsignedByte3 = parsableByteArray.readUnsignedByte();
        for (i2 = 0; i2 < readUnsignedByte3; i2++) {
            arrayList.add(NalUnitUtil.parseChildNalUnit(parsableByteArray));
        }
        if (readUnsignedByte2 > 0) {
            ParsableBitArray parsableBitArray = new ParsableBitArray((byte[]) arrayList.get(0));
            parsableBitArray.setPosition((readUnsignedByte + 1) * 8);
            f = CodecSpecificDataUtil.parseSpsNalUnit(parsableBitArray).pixelWidthAspectRatio;
        }
        return new AvcCData(arrayList, readUnsignedByte, f);
    }

    private static Pair<List<byte[]>, Integer> parseHvcCFromParent(ParsableByteArray parsableByteArray, int i) {
        int i2;
        parsableByteArray.setPosition((i + 8) + 21);
        int readUnsignedByte = parsableByteArray.readUnsignedByte() & 3;
        int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
        int position = parsableByteArray.getPosition();
        int i3 = 0;
        int i4 = 0;
        while (i3 < readUnsignedByte2) {
            parsableByteArray.skipBytes(1);
            int readUnsignedShort = parsableByteArray.readUnsignedShort();
            int i5 = i4;
            for (i2 = 0; i2 < readUnsignedShort; i2++) {
                i4 = parsableByteArray.readUnsignedShort();
                i5 += i4 + 4;
                parsableByteArray.skipBytes(i4);
            }
            i3++;
            i4 = i5;
        }
        parsableByteArray.setPosition(position);
        Object obj = new byte[i4];
        i2 = 0;
        for (i3 = 0; i3 < readUnsignedByte2; i3++) {
            parsableByteArray.skipBytes(1);
            readUnsignedShort = parsableByteArray.readUnsignedShort();
            for (i5 = 0; i5 < readUnsignedShort; i5++) {
                int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
                System.arraycopy(NalUnitUtil.NAL_START_CODE, 0, obj, i2, NalUnitUtil.NAL_START_CODE.length);
                i2 += NalUnitUtil.NAL_START_CODE.length;
                System.arraycopy(parsableByteArray.data, parsableByteArray.getPosition(), obj, i2, readUnsignedShort2);
                i2 += readUnsignedShort2;
                parsableByteArray.skipBytes(readUnsignedShort2);
            }
        }
        return Pair.create(i4 == 0 ? null : Collections.singletonList(obj), Integer.valueOf(readUnsignedByte + 1));
    }

    private static Pair<long[], long[]> parseEdts(ContainerAtom containerAtom) {
        if (containerAtom != null) {
            LeafAtom leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_elst);
            if (leafAtomOfType != null) {
                ParsableByteArray parsableByteArray = leafAtomOfType.data;
                parsableByteArray.setPosition(8);
                int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
                int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
                Object obj = new long[readUnsignedIntToInt];
                Object obj2 = new long[readUnsignedIntToInt];
                for (int i = 0; i < readUnsignedIntToInt; i++) {
                    obj[i] = parseFullAtomVersion == 1 ? parsableByteArray.readUnsignedLongToLong() : parsableByteArray.readUnsignedInt();
                    obj2[i] = parseFullAtomVersion == 1 ? parsableByteArray.readLong() : (long) parsableByteArray.readInt();
                    if (parsableByteArray.readShort() != (short) 1) {
                        throw new IllegalArgumentException("Unsupported media rate.");
                    }
                    parsableByteArray.skipBytes(2);
                }
                return Pair.create(obj, obj2);
            }
        }
        return Pair.create(null, null);
    }

    private static TrackEncryptionBox parseSinfFromParent(ParsableByteArray parsableByteArray, int i, int i2) {
        int i3 = i + 8;
        TrackEncryptionBox trackEncryptionBox = null;
        while (i3 - i < i2) {
            parsableByteArray.setPosition(i3);
            int readInt = parsableByteArray.readInt();
            int readInt2 = parsableByteArray.readInt();
            if (readInt2 == Atom.TYPE_frma) {
                parsableByteArray.readInt();
            } else if (readInt2 == Atom.TYPE_schm) {
                parsableByteArray.skipBytes(4);
                parsableByteArray.readInt();
                parsableByteArray.readInt();
            } else if (readInt2 == Atom.TYPE_schi) {
                trackEncryptionBox = parseSchiFromParent(parsableByteArray, i3, readInt);
            }
            i3 += readInt;
        }
        return trackEncryptionBox;
    }

    private static float parsePaspFromParent(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.setPosition(i + 8);
        return ((float) parsableByteArray.readUnsignedIntToInt()) / ((float) parsableByteArray.readUnsignedIntToInt());
    }

    private static TrackEncryptionBox parseSchiFromParent(ParsableByteArray parsableByteArray, int i, int i2) {
        boolean z = true;
        int i3 = i + 8;
        while (i3 - i < i2) {
            parsableByteArray.setPosition(i3);
            int readInt = parsableByteArray.readInt();
            if (parsableByteArray.readInt() == Atom.TYPE_tenc) {
                parsableByteArray.skipBytes(4);
                i3 = parsableByteArray.readInt();
                if ((i3 >> 8) != 1) {
                    z = false;
                }
                i3 &= 255;
                byte[] bArr = new byte[16];
                parsableByteArray.readBytes(bArr, 0, 16);
                return new TrackEncryptionBox(z, i3, bArr);
            }
            i3 += readInt;
        }
        return null;
    }

    private static void parseAudioSampleEntry(ParsableByteArray parsableByteArray, int i, int i2, int i3, int i4, long j, String str, boolean z, StsdData stsdData, int i5) {
        parsableByteArray.setPosition(i2 + 8);
        int i6 = 0;
        if (z) {
            parsableByteArray.skipBytes(8);
            i6 = parsableByteArray.readUnsignedShort();
            parsableByteArray.skipBytes(6);
        } else {
            parsableByteArray.skipBytes(16);
        }
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
        parsableByteArray.skipBytes(4);
        int readUnsignedFixedPoint1616 = parsableByteArray.readUnsignedFixedPoint1616();
        if (i6 > 0) {
            parsableByteArray.skipBytes(16);
            if (i6 == 2) {
                parsableByteArray.skipBytes(20);
            }
        }
        String str2 = null;
        if (i == Atom.TYPE_ac_3) {
            str2 = MimeTypes.AUDIO_AC3;
        } else if (i == Atom.TYPE_ec_3) {
            str2 = MimeTypes.AUDIO_E_AC3;
        } else if (i == Atom.TYPE_dtsc) {
            str2 = MimeTypes.AUDIO_DTS;
        } else if (i == Atom.TYPE_dtsh || i == Atom.TYPE_dtsl) {
            str2 = MimeTypes.AUDIO_DTS_HD;
        } else if (i == Atom.TYPE_dtse) {
            str2 = MimeTypes.AUDIO_DTS_EXPRESS;
        } else if (i == Atom.TYPE_samr) {
            str2 = MimeTypes.AUDIO_AMR_NB;
        } else if (i == Atom.TYPE_sawb) {
            str2 = MimeTypes.AUDIO_AMR_WB;
        }
        Object obj = null;
        int position = parsableByteArray.getPosition();
        String str3 = str2;
        while (position - i2 < i3) {
            Object obj2;
            parsableByteArray.setPosition(position);
            int readInt = parsableByteArray.readInt();
            Assertions.checkArgument(readInt > 0, "childAtomSize should be positive");
            int readInt2 = parsableByteArray.readInt();
            if (i == Atom.TYPE_mp4a || i == Atom.TYPE_enca) {
                i6 = -1;
                if (readInt2 == Atom.TYPE_esds) {
                    i6 = position;
                } else if (z && readInt2 == Atom.TYPE_wave) {
                    i6 = findEsdsPosition(parsableByteArray, position, readInt);
                }
                if (i6 != -1) {
                    Pair parseEsdsFromParent = parseEsdsFromParent(parsableByteArray, i6);
                    str2 = (String) parseEsdsFromParent.first;
                    obj2 = (byte[]) parseEsdsFromParent.second;
                    if (MimeTypes.AUDIO_AAC.equals(str2)) {
                        Pair parseAacAudioSpecificConfig = CodecSpecificDataUtil.parseAacAudioSpecificConfig(obj2);
                        readUnsignedFixedPoint1616 = ((Integer) parseAacAudioSpecificConfig.first).intValue();
                        readUnsignedShort = ((Integer) parseAacAudioSpecificConfig.second).intValue();
                    }
                } else {
                    if (readInt2 == Atom.TYPE_sinf) {
                        stsdData.trackEncryptionBoxes[i5] = parseSinfFromParent(parsableByteArray, position, readInt);
                    }
                    str2 = str3;
                    obj2 = obj;
                }
            } else if (i == Atom.TYPE_ac_3 && readInt2 == Atom.TYPE_dac3) {
                parsableByteArray.setPosition(position + 8);
                stsdData.mediaFormat = Ac3Util.parseAc3AnnexFFormat(parsableByteArray, Integer.toString(i4), j, str);
                return;
            } else if (i == Atom.TYPE_ec_3 && readInt2 == Atom.TYPE_dec3) {
                parsableByteArray.setPosition(position + 8);
                stsdData.mediaFormat = Ac3Util.parseEAc3AnnexFFormat(parsableByteArray, Integer.toString(i4), j, str);
                return;
            } else if ((i == Atom.TYPE_dtsc || i == Atom.TYPE_dtse || i == Atom.TYPE_dtsh || i == Atom.TYPE_dtsl) && readInt2 == Atom.TYPE_ddts) {
                stsdData.mediaFormat = MediaFormat.createAudioFormat(Integer.toString(i4), str3, -1, -1, j, readUnsignedShort, readUnsignedFixedPoint1616, null, str);
                return;
            } else {
                str2 = str3;
                obj2 = obj;
            }
            position += readInt;
            obj = obj2;
            str3 = str2;
        }
        if (str3 != null) {
            stsdData.mediaFormat = MediaFormat.createAudioFormat(Integer.toString(i4), str3, -1, readUnsignedShort2, j, readUnsignedShort, readUnsignedFixedPoint1616, obj == null ? null : Collections.singletonList(obj), str);
        }
    }

    private static int findEsdsPosition(ParsableByteArray parsableByteArray, int i, int i2) {
        int position = parsableByteArray.getPosition();
        while (position - i < i2) {
            parsableByteArray.setPosition(position);
            int readInt = parsableByteArray.readInt();
            Assertions.checkArgument(readInt > 0, "childAtomSize should be positive");
            if (parsableByteArray.readInt() == Atom.TYPE_esds) {
                return position;
            }
            position += readInt;
        }
        return -1;
    }

    private static Pair<String, byte[]> parseEsdsFromParent(ParsableByteArray parsableByteArray, int i) {
        Object obj = null;
        parsableByteArray.setPosition((i + 8) + 4);
        parsableByteArray.skipBytes(1);
        int readUnsignedByte = parsableByteArray.readUnsignedByte();
        while (readUnsignedByte > TransportMediator.KEYCODE_MEDIA_PAUSE) {
            readUnsignedByte = parsableByteArray.readUnsignedByte();
        }
        parsableByteArray.skipBytes(2);
        readUnsignedByte = parsableByteArray.readUnsignedByte();
        if ((readUnsignedByte & 128) != 0) {
            parsableByteArray.skipBytes(2);
        }
        if ((readUnsignedByte & 64) != 0) {
            parsableByteArray.skipBytes(parsableByteArray.readUnsignedShort());
        }
        if ((readUnsignedByte & 32) != 0) {
            parsableByteArray.skipBytes(2);
        }
        parsableByteArray.skipBytes(1);
        readUnsignedByte = parsableByteArray.readUnsignedByte();
        while (readUnsignedByte > TransportMediator.KEYCODE_MEDIA_PAUSE) {
            readUnsignedByte = parsableByteArray.readUnsignedByte();
        }
        switch (parsableByteArray.readUnsignedByte()) {
            case 32:
                obj = MimeTypes.VIDEO_MP4V;
                break;
            case 33:
                obj = MimeTypes.VIDEO_H264;
                break;
            case 35:
                obj = MimeTypes.VIDEO_H265;
                break;
            case 64:
            case 102:
            case 103:
            case 104:
                obj = MimeTypes.AUDIO_AAC;
                break;
            case 107:
                return Pair.create(MimeTypes.AUDIO_MPEG, null);
            case 165:
                obj = MimeTypes.AUDIO_AC3;
                break;
            case 166:
                obj = MimeTypes.AUDIO_E_AC3;
                break;
            case 169:
            case 172:
                return Pair.create(MimeTypes.AUDIO_DTS, null);
            case 170:
            case 171:
                return Pair.create(MimeTypes.AUDIO_DTS_HD, null);
        }
        parsableByteArray.skipBytes(12);
        parsableByteArray.skipBytes(1);
        int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
        readUnsignedByte = readUnsignedByte2 & TransportMediator.KEYCODE_MEDIA_PAUSE;
        while (readUnsignedByte2 > TransportMediator.KEYCODE_MEDIA_PAUSE) {
            readUnsignedByte2 = parsableByteArray.readUnsignedByte();
            readUnsignedByte = (readUnsignedByte << 8) | (readUnsignedByte2 & TransportMediator.KEYCODE_MEDIA_PAUSE);
        }
        Object obj2 = new byte[readUnsignedByte];
        parsableByteArray.readBytes(obj2, 0, readUnsignedByte);
        return Pair.create(obj, obj2);
    }

    private AtomParsers() {
    }
}
