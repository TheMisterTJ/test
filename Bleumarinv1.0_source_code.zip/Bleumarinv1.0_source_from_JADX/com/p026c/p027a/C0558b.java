package com.p026c.p027a;

import com.p026c.p027a.C0557a.C0556a;

/* compiled from: AnimatorListenerAdapter */
public abstract class C0558b implements C0556a {
    public void mo1653b(C0557a c0557a) {
    }

    public void mo1652a(C0557a c0557a) {
    }
}
