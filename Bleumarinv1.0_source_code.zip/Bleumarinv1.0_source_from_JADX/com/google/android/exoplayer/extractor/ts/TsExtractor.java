package com.google.android.exoplayer.extractor.ts;

import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.google.android.exoplayer.extractor.DummyTrackOutput;
import com.google.android.exoplayer.extractor.Extractor;
import com.google.android.exoplayer.extractor.ExtractorInput;
import com.google.android.exoplayer.extractor.ExtractorOutput;
import com.google.android.exoplayer.extractor.PositionHolder;
import com.google.android.exoplayer.extractor.SeekMap;
import com.google.android.exoplayer.util.ParsableBitArray;
import com.google.android.exoplayer.util.ParsableByteArray;
import com.google.android.exoplayer.util.Util;
import java.io.IOException;

public final class TsExtractor implements Extractor {
    private static final long AC3_FORMAT_IDENTIFIER = ((long) Util.getIntegerCodeForString("AC-3"));
    private static final long E_AC3_FORMAT_IDENTIFIER = ((long) Util.getIntegerCodeForString("EAC3"));
    private static final long HEVC_FORMAT_IDENTIFIER = ((long) Util.getIntegerCodeForString("HEVC"));
    private static final String TAG = "TsExtractor";
    private static final int TS_PACKET_SIZE = 188;
    private static final int TS_PAT_PID = 0;
    private static final int TS_STREAM_TYPE_AAC = 15;
    private static final int TS_STREAM_TYPE_AC3 = 129;
    private static final int TS_STREAM_TYPE_DTS = 138;
    private static final int TS_STREAM_TYPE_EIA608 = 256;
    private static final int TS_STREAM_TYPE_E_AC3 = 135;
    private static final int TS_STREAM_TYPE_H262 = 2;
    private static final int TS_STREAM_TYPE_H264 = 27;
    private static final int TS_STREAM_TYPE_H265 = 36;
    private static final int TS_STREAM_TYPE_HDMV_DTS = 130;
    private static final int TS_STREAM_TYPE_ID3 = 21;
    private static final int TS_STREAM_TYPE_MPA = 3;
    private static final int TS_STREAM_TYPE_MPA_LSF = 4;
    private static final int TS_SYNC_BYTE = 71;
    public static final int WORKAROUND_ALLOW_NON_IDR_KEYFRAMES = 1;
    public static final int WORKAROUND_IGNORE_AAC_STREAM = 2;
    public static final int WORKAROUND_IGNORE_H264_STREAM = 4;
    Id3Reader id3Reader;
    private ExtractorOutput output;
    private final PtsTimestampAdjuster ptsTimestampAdjuster;
    final SparseBooleanArray streamTypes;
    private final ParsableByteArray tsPacketBuffer;
    final SparseArray<TsPayloadReader> tsPayloadReaders;
    private final ParsableBitArray tsScratch;
    private final int workaroundFlags;

    private static abstract class TsPayloadReader {
        public abstract void consume(ParsableByteArray parsableByteArray, boolean z, ExtractorOutput extractorOutput);

        public abstract void seek();

        private TsPayloadReader() {
        }
    }

    private class PatReader extends TsPayloadReader {
        private final ParsableBitArray patScratch = new ParsableBitArray(new byte[4]);

        public PatReader() {
            super();
        }

        public void seek() {
        }

        public void consume(ParsableByteArray parsableByteArray, boolean z, ExtractorOutput extractorOutput) {
            if (z) {
                parsableByteArray.skipBytes(parsableByteArray.readUnsignedByte());
            }
            parsableByteArray.readBytes(this.patScratch, 3);
            this.patScratch.skipBits(12);
            int readBits = this.patScratch.readBits(12);
            parsableByteArray.skipBytes(5);
            int i = (readBits - 9) / 4;
            for (readBits = 0; readBits < i; readBits++) {
                parsableByteArray.readBytes(this.patScratch, 4);
                int readBits2 = this.patScratch.readBits(16);
                this.patScratch.skipBits(3);
                if (readBits2 == 0) {
                    this.patScratch.skipBits(13);
                } else {
                    TsExtractor.this.tsPayloadReaders.put(this.patScratch.readBits(13), new PmtReader());
                }
            }
        }
    }

    private static final class PesReader extends TsPayloadReader {
        private static final int HEADER_SIZE = 9;
        private static final int MAX_HEADER_EXTENSION_SIZE = 10;
        private static final int PES_SCRATCH_SIZE = 10;
        private static final int STATE_FINDING_HEADER = 0;
        private static final int STATE_READING_BODY = 3;
        private static final int STATE_READING_HEADER = 1;
        private static final int STATE_READING_HEADER_EXTENSION = 2;
        private int bytesRead;
        private boolean dataAlignmentIndicator;
        private boolean dtsFlag;
        private int extendedHeaderLength;
        private int payloadSize;
        private final ElementaryStreamReader pesPayloadReader;
        private final ParsableBitArray pesScratch = new ParsableBitArray(new byte[10]);
        private boolean ptsFlag;
        private final PtsTimestampAdjuster ptsTimestampAdjuster;
        private boolean seenFirstDts;
        private int state = 0;
        private long timeUs;

        public PesReader(ElementaryStreamReader elementaryStreamReader, PtsTimestampAdjuster ptsTimestampAdjuster) {
            super();
            this.pesPayloadReader = elementaryStreamReader;
            this.ptsTimestampAdjuster = ptsTimestampAdjuster;
        }

        public final void seek() {
            this.state = 0;
            this.bytesRead = 0;
            this.seenFirstDts = false;
            this.pesPayloadReader.seek();
        }

        public final void consume(ParsableByteArray parsableByteArray, boolean z, ExtractorOutput extractorOutput) {
            if (z) {
                switch (this.state) {
                    case 2:
                        Log.w(TsExtractor.TAG, "Unexpected start indicator reading extended header");
                        break;
                    case 3:
                        if (this.payloadSize != -1) {
                            Log.w(TsExtractor.TAG, "Unexpected start indicator: expected " + this.payloadSize + " more bytes");
                        }
                        this.pesPayloadReader.packetFinished();
                        break;
                }
                setState(1);
            }
            while (parsableByteArray.bytesLeft() > 0) {
                switch (this.state) {
                    case 0:
                        parsableByteArray.skipBytes(parsableByteArray.bytesLeft());
                        break;
                    case 1:
                        if (!continueRead(parsableByteArray, this.pesScratch.data, 9)) {
                            break;
                        }
                        setState(parseHeader() ? 2 : 0);
                        break;
                    case 2:
                        if (continueRead(parsableByteArray, this.pesScratch.data, Math.min(10, this.extendedHeaderLength)) && continueRead(parsableByteArray, null, this.extendedHeaderLength)) {
                            parseHeaderExtension();
                            this.pesPayloadReader.packetStarted(this.timeUs, this.dataAlignmentIndicator);
                            setState(3);
                            break;
                        }
                    case 3:
                        int i;
                        int bytesLeft = parsableByteArray.bytesLeft();
                        if (this.payloadSize == -1) {
                            i = 0;
                        } else {
                            i = bytesLeft - this.payloadSize;
                        }
                        if (i > 0) {
                            bytesLeft -= i;
                            parsableByteArray.setLimit(parsableByteArray.getPosition() + bytesLeft);
                        }
                        this.pesPayloadReader.consume(parsableByteArray);
                        if (this.payloadSize == -1) {
                            break;
                        }
                        this.payloadSize -= bytesLeft;
                        if (this.payloadSize != 0) {
                            break;
                        }
                        this.pesPayloadReader.packetFinished();
                        setState(1);
                        break;
                    default:
                        break;
                }
            }
        }

        private void setState(int i) {
            this.state = i;
            this.bytesRead = 0;
        }

        private boolean continueRead(ParsableByteArray parsableByteArray, byte[] bArr, int i) {
            int min = Math.min(parsableByteArray.bytesLeft(), i - this.bytesRead);
            if (min <= 0) {
                return true;
            }
            if (bArr == null) {
                parsableByteArray.skipBytes(min);
            } else {
                parsableByteArray.readBytes(bArr, this.bytesRead, min);
            }
            this.bytesRead = min + this.bytesRead;
            if (this.bytesRead != i) {
                return false;
            }
            return true;
        }

        private boolean parseHeader() {
            this.pesScratch.setPosition(0);
            int readBits = this.pesScratch.readBits(24);
            if (readBits != 1) {
                Log.w(TsExtractor.TAG, "Unexpected start code prefix: " + readBits);
                this.payloadSize = -1;
                return false;
            }
            this.pesScratch.skipBits(8);
            int readBits2 = this.pesScratch.readBits(16);
            this.pesScratch.skipBits(5);
            this.dataAlignmentIndicator = this.pesScratch.readBit();
            this.pesScratch.skipBits(2);
            this.ptsFlag = this.pesScratch.readBit();
            this.dtsFlag = this.pesScratch.readBit();
            this.pesScratch.skipBits(6);
            this.extendedHeaderLength = this.pesScratch.readBits(8);
            if (readBits2 == 0) {
                this.payloadSize = -1;
            } else {
                this.payloadSize = ((readBits2 + 6) - 9) - this.extendedHeaderLength;
            }
            return true;
        }

        private void parseHeaderExtension() {
            this.pesScratch.setPosition(0);
            this.timeUs = 0;
            if (this.ptsFlag) {
                this.pesScratch.skipBits(4);
                long readBits = ((long) this.pesScratch.readBits(3)) << 30;
                this.pesScratch.skipBits(1);
                readBits |= (long) (this.pesScratch.readBits(15) << 15);
                this.pesScratch.skipBits(1);
                readBits |= (long) this.pesScratch.readBits(15);
                this.pesScratch.skipBits(1);
                if (!this.seenFirstDts && this.dtsFlag) {
                    this.pesScratch.skipBits(4);
                    long readBits2 = ((long) this.pesScratch.readBits(3)) << 30;
                    this.pesScratch.skipBits(1);
                    readBits2 |= (long) (this.pesScratch.readBits(15) << 15);
                    this.pesScratch.skipBits(1);
                    readBits2 |= (long) this.pesScratch.readBits(15);
                    this.pesScratch.skipBits(1);
                    this.ptsTimestampAdjuster.adjustTimestamp(readBits2);
                    this.seenFirstDts = true;
                }
                this.timeUs = this.ptsTimestampAdjuster.adjustTimestamp(readBits);
            }
        }
    }

    private class PmtReader extends TsPayloadReader {
        private final ParsableBitArray pmtScratch = new ParsableBitArray(new byte[5]);
        private int sectionBytesRead;
        private final ParsableByteArray sectionData = new ParsableByteArray();
        private int sectionLength;

        public PmtReader() {
            super();
        }

        public void seek() {
        }

        public void consume(ParsableByteArray parsableByteArray, boolean z, ExtractorOutput extractorOutput) {
            if (z) {
                parsableByteArray.skipBytes(parsableByteArray.readUnsignedByte());
                parsableByteArray.readBytes(this.pmtScratch, 3);
                this.pmtScratch.skipBits(12);
                this.sectionLength = this.pmtScratch.readBits(12);
                if (this.sectionData.capacity() < this.sectionLength) {
                    this.sectionData.reset(new byte[this.sectionLength], this.sectionLength);
                } else {
                    this.sectionData.reset();
                    this.sectionData.setLimit(this.sectionLength);
                }
            }
            int min = Math.min(parsableByteArray.bytesLeft(), this.sectionLength - this.sectionBytesRead);
            parsableByteArray.readBytes(this.sectionData.data, this.sectionBytesRead, min);
            this.sectionBytesRead = min + this.sectionBytesRead;
            if (this.sectionBytesRead >= this.sectionLength) {
                this.sectionData.skipBytes(7);
                this.sectionData.readBytes(this.pmtScratch, 2);
                this.pmtScratch.skipBits(4);
                min = this.pmtScratch.readBits(12);
                this.sectionData.skipBytes(min);
                if (TsExtractor.this.id3Reader == null) {
                    TsExtractor.this.id3Reader = new Id3Reader(extractorOutput.track(21));
                }
                int i = ((this.sectionLength - 9) - min) - 4;
                while (i > 0) {
                    this.sectionData.readBytes(this.pmtScratch, 5);
                    min = this.pmtScratch.readBits(8);
                    this.pmtScratch.skipBits(3);
                    int readBits = this.pmtScratch.readBits(13);
                    this.pmtScratch.skipBits(4);
                    int readBits2 = this.pmtScratch.readBits(12);
                    if (min == 6) {
                        min = readPrivateDataStreamType(this.sectionData, readBits2);
                    } else {
                        this.sectionData.skipBytes(readBits2);
                    }
                    int i2 = i - (readBits2 + 5);
                    if (TsExtractor.this.streamTypes.get(min)) {
                        i = i2;
                    } else {
                        ElementaryStreamReader h262Reader;
                        switch (min) {
                            case 2:
                                h262Reader = new H262Reader(extractorOutput.track(2));
                                break;
                            case 3:
                                h262Reader = new MpegAudioReader(extractorOutput.track(3));
                                break;
                            case 4:
                                h262Reader = new MpegAudioReader(extractorOutput.track(4));
                                break;
                            case 15:
                                if ((TsExtractor.this.workaroundFlags & 2) == 0) {
                                    h262Reader = new AdtsReader(extractorOutput.track(15), new DummyTrackOutput());
                                    break;
                                } else {
                                    h262Reader = null;
                                    break;
                                }
                            case 21:
                                h262Reader = TsExtractor.this.id3Reader;
                                break;
                            case 27:
                                if ((TsExtractor.this.workaroundFlags & 4) == 0) {
                                    h262Reader = new H264Reader(extractorOutput.track(27), new SeiReader(extractorOutput.track(256)), (TsExtractor.this.workaroundFlags & 1) != 0);
                                    break;
                                } else {
                                    h262Reader = null;
                                    break;
                                }
                            case 36:
                                h262Reader = new H265Reader(extractorOutput.track(36), new SeiReader(extractorOutput.track(256)));
                                break;
                            case TsExtractor.TS_STREAM_TYPE_AC3 /*129*/:
                                h262Reader = new Ac3Reader(extractorOutput.track(TsExtractor.TS_STREAM_TYPE_AC3), false);
                                break;
                            case 130:
                            case TsExtractor.TS_STREAM_TYPE_DTS /*138*/:
                                h262Reader = new DtsReader(extractorOutput.track(TsExtractor.TS_STREAM_TYPE_DTS));
                                break;
                            case TsExtractor.TS_STREAM_TYPE_E_AC3 /*135*/:
                                h262Reader = new Ac3Reader(extractorOutput.track(TsExtractor.TS_STREAM_TYPE_E_AC3), true);
                                break;
                            default:
                                h262Reader = null;
                                break;
                        }
                        if (h262Reader != null) {
                            TsExtractor.this.streamTypes.put(min, true);
                            TsExtractor.this.tsPayloadReaders.put(readBits, new PesReader(h262Reader, TsExtractor.this.ptsTimestampAdjuster));
                        }
                        i = i2;
                    }
                }
                extractorOutput.endTracks();
            }
        }

        private int readPrivateDataStreamType(ParsableByteArray parsableByteArray, int i) {
            int i2 = -1;
            int position = parsableByteArray.getPosition() + i;
            while (parsableByteArray.getPosition() < position) {
                int readUnsignedByte = parsableByteArray.readUnsignedByte();
                int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
                if (readUnsignedByte == 5) {
                    long readUnsignedInt = parsableByteArray.readUnsignedInt();
                    if (readUnsignedInt == TsExtractor.AC3_FORMAT_IDENTIFIER) {
                        i2 = TsExtractor.TS_STREAM_TYPE_AC3;
                    } else if (readUnsignedInt == TsExtractor.E_AC3_FORMAT_IDENTIFIER) {
                        i2 = TsExtractor.TS_STREAM_TYPE_E_AC3;
                    } else if (readUnsignedInt == TsExtractor.HEVC_FORMAT_IDENTIFIER) {
                        i2 = 36;
                    }
                    parsableByteArray.setPosition(position);
                    return i2;
                }
                if (readUnsignedByte == 106) {
                    i2 = TsExtractor.TS_STREAM_TYPE_AC3;
                } else if (readUnsignedByte == 122) {
                    i2 = TsExtractor.TS_STREAM_TYPE_E_AC3;
                } else if (readUnsignedByte == 123) {
                    i2 = TsExtractor.TS_STREAM_TYPE_DTS;
                }
                parsableByteArray.skipBytes(readUnsignedByte2);
            }
            parsableByteArray.setPosition(position);
            return i2;
        }
    }

    public TsExtractor() {
        this(new PtsTimestampAdjuster(0));
    }

    public TsExtractor(PtsTimestampAdjuster ptsTimestampAdjuster) {
        this(ptsTimestampAdjuster, 0);
    }

    public TsExtractor(PtsTimestampAdjuster ptsTimestampAdjuster, int i) {
        this.ptsTimestampAdjuster = ptsTimestampAdjuster;
        this.workaroundFlags = i;
        this.tsPacketBuffer = new ParsableByteArray((int) TS_PACKET_SIZE);
        this.tsScratch = new ParsableBitArray(new byte[3]);
        this.tsPayloadReaders = new SparseArray();
        this.tsPayloadReaders.put(0, new PatReader());
        this.streamTypes = new SparseBooleanArray();
    }

    public final boolean sniff(ExtractorInput extractorInput) throws IOException, InterruptedException {
        byte[] bArr = new byte[1];
        for (int i = 0; i < 5; i++) {
            extractorInput.peekFully(bArr, 0, 1);
            if ((bArr[0] & 255) != 71) {
                return false;
            }
            extractorInput.advancePeekPosition(187);
        }
        return true;
    }

    public final void init(ExtractorOutput extractorOutput) {
        this.output = extractorOutput;
        extractorOutput.seekMap(SeekMap.UNSEEKABLE);
    }

    public final void seek() {
        this.ptsTimestampAdjuster.reset();
        for (int i = 0; i < this.tsPayloadReaders.size(); i++) {
            ((TsPayloadReader) this.tsPayloadReaders.valueAt(i)).seek();
        }
    }

    public final int read(ExtractorInput extractorInput, PositionHolder positionHolder) throws IOException, InterruptedException {
        if (!extractorInput.readFully(this.tsPacketBuffer.data, 0, TS_PACKET_SIZE, true)) {
            return -1;
        }
        this.tsPacketBuffer.setPosition(0);
        this.tsPacketBuffer.setLimit(TS_PACKET_SIZE);
        if (this.tsPacketBuffer.readUnsignedByte() != 71) {
            return 0;
        }
        this.tsPacketBuffer.readBytes(this.tsScratch, 3);
        this.tsScratch.skipBits(1);
        boolean readBit = this.tsScratch.readBit();
        this.tsScratch.skipBits(1);
        int readBits = this.tsScratch.readBits(13);
        this.tsScratch.skipBits(2);
        boolean readBit2 = this.tsScratch.readBit();
        boolean readBit3 = this.tsScratch.readBit();
        if (readBit2) {
            this.tsPacketBuffer.skipBytes(this.tsPacketBuffer.readUnsignedByte());
        }
        if (readBit3) {
            TsPayloadReader tsPayloadReader = (TsPayloadReader) this.tsPayloadReaders.get(readBits);
            if (tsPayloadReader != null) {
                tsPayloadReader.consume(this.tsPacketBuffer, readBit, this.output);
            }
        }
        return 0;
    }
}
