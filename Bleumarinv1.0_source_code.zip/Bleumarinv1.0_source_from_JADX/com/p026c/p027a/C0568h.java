package com.p026c.p027a;

import android.view.View;
import com.p026c.p038b.C0569c;
import com.p026c.p039c.p040a.C0590a;
import java.util.HashMap;
import java.util.Map;

/* compiled from: ObjectAnimator */
public final class C0568h extends C0567l {
    private static final Map<String, C0569c> f1517m;
    public Object f1518b;
    private String f1519n;
    private C0569c f1520o;

    static {
        Map hashMap = new HashMap();
        f1517m = hashMap;
        hashMap.put("alpha", C0581i.f1523a);
        f1517m.put("pivotX", C0581i.f1524b);
        f1517m.put("pivotY", C0581i.f1525c);
        f1517m.put("translationX", C0581i.f1526d);
        f1517m.put("translationY", C0581i.f1527e);
        f1517m.put("rotation", C0581i.f1528f);
        f1517m.put("rotationX", C0581i.f1529g);
        f1517m.put("rotationY", C0581i.f1530h);
        f1517m.put("scaleX", C0581i.f1531i);
        f1517m.put("scaleY", C0581i.f1532j);
        f1517m.put("scrollX", C0581i.f1533k);
        f1517m.put("scrollY", C0581i.f1534l);
        f1517m.put("x", C0581i.f1535m);
        f1517m.put("y", C0581i.f1536n);
    }

    public static C0568h m1284a(Object obj, C0582j... c0582jArr) {
        C0568h c0568h = new C0568h();
        c0568h.f1518b = obj;
        c0568h.m1276a(c0582jArr);
        return c0568h;
    }

    public final void mo1667a(float... fArr) {
        if (this.k != null && this.k.length != 0) {
            super.mo1667a(fArr);
        } else if (this.f1520o != null) {
            m1276a(C0582j.m1324a(this.f1520o, fArr));
        } else {
            m1276a(C0582j.m1326a(this.f1519n, fArr));
        }
    }

    public final void mo1662a() {
        super.mo1662a();
    }

    final void mo1669c() {
        if (!this.i) {
            if (this.f1520o == null && C0590a.f1557a && (this.f1518b instanceof View) && f1517m.containsKey(this.f1519n)) {
                C0569c c0569c = (C0569c) f1517m.get(this.f1519n);
                if (this.k != null) {
                    C0582j c0582j = this.k[0];
                    String str = c0582j.f1544a;
                    c0582j.m1331a(c0569c);
                    this.l.remove(str);
                    this.l.put(this.f1519n, c0582j);
                }
                if (this.f1520o != null) {
                    this.f1519n = c0569c.f1521a;
                }
                this.f1520o = c0569c;
                this.i = false;
            }
            for (C0582j a : this.k) {
                a.m1333a(this.f1518b);
            }
            super.mo1669c();
        }
    }

    public final C0568h mo1665a(long j) {
        super.mo1668b(j);
        return this;
    }

    final void mo1666a(float f) {
        super.mo1666a(f);
        for (C0582j b : this.k) {
            b.mo1680b(this.f1518b);
        }
    }

    public final String toString() {
        String str = "ObjectAnimator@" + Integer.toHexString(hashCode()) + ", target " + this.f1518b;
        if (this.k != null) {
            for (C0582j c0582j : this.k) {
                str = str + "\n    " + c0582j.toString();
            }
        }
        return str;
    }

    public final /* bridge */ /* synthetic */ C0567l mo1670d() {
        return (C0568h) super.mo1670d();
    }

    public final /* bridge */ /* synthetic */ C0567l mo1668b(long j) {
        super.mo1668b(j);
        return this;
    }

    public final /* synthetic */ C0557a mo1663b() {
        return (C0568h) super.mo1670d();
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return (C0568h) super.mo1670d();
    }
}
