package com.google.android.gms.internal;

public interface zzmq {
    long currentTimeMillis();

    long elapsedRealtime();

    long nanoTime();
}
