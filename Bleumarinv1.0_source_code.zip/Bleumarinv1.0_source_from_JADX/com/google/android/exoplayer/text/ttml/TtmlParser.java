package com.google.android.exoplayer.text.ttml;

import android.util.Log;
import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.text.SubtitleParser;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.ParserUtil;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public final class TtmlParser implements SubtitleParser {
    private static final String ATTR_BEGIN = "begin";
    private static final String ATTR_DURATION = "dur";
    private static final String ATTR_END = "end";
    private static final String ATTR_STYLE = "style";
    private static final Pattern CLOCK_TIME = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
    private static final int DEFAULT_FRAMERATE = 30;
    private static final int DEFAULT_SUBFRAMERATE = 1;
    private static final int DEFAULT_TICKRATE = 1;
    private static final Pattern FONT_SIZE = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
    private static final Pattern OFFSET_TIME = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
    private static final String TAG = "TtmlParser";
    private final XmlPullParserFactory xmlParserFactory;

    public TtmlParser() {
        try {
            this.xmlParserFactory = XmlPullParserFactory.newInstance();
        } catch (Throwable e) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e);
        }
    }

    public final boolean canParse(String str) {
        return MimeTypes.APPLICATION_TTML.equals(str);
    }

    public final TtmlSubtitle parse(byte[] bArr, int i, int i2) throws ParserException {
        try {
            XmlPullParser newPullParser = this.xmlParserFactory.newPullParser();
            Map hashMap = new HashMap();
            newPullParser.setInput(new ByteArrayInputStream(bArr, i, i2), null);
            LinkedList linkedList = new LinkedList();
            int i3 = 0;
            TtmlSubtitle ttmlSubtitle = null;
            for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.getEventType()) {
                TtmlSubtitle ttmlSubtitle2;
                int i4;
                TtmlNode ttmlNode = (TtmlNode) linkedList.peekLast();
                if (i3 == 0) {
                    String name = newPullParser.getName();
                    if (eventType == 2) {
                        if (!isSupportedTag(name)) {
                            Log.i(TAG, "Ignoring unsupported tag: " + newPullParser.getName());
                            ttmlSubtitle2 = ttmlSubtitle;
                            i4 = i3 + 1;
                        } else if (TtmlNode.TAG_HEAD.equals(name)) {
                            parseHeader(newPullParser, hashMap);
                            ttmlSubtitle2 = ttmlSubtitle;
                            i4 = i3;
                        } else {
                            try {
                                TtmlNode parseNode = parseNode(newPullParser, ttmlNode);
                                linkedList.addLast(parseNode);
                                if (ttmlNode != null) {
                                    ttmlNode.addChild(parseNode);
                                }
                                ttmlSubtitle2 = ttmlSubtitle;
                                i4 = i3;
                            } catch (Throwable e) {
                                Log.w(TAG, "Suppressing parser error", e);
                                ttmlSubtitle2 = ttmlSubtitle;
                                i4 = i3 + 1;
                            }
                        }
                    } else if (eventType == 4) {
                        ttmlNode.addChild(TtmlNode.buildTextNode(newPullParser.getText()));
                        ttmlSubtitle2 = ttmlSubtitle;
                        i4 = i3;
                    } else {
                        TtmlSubtitle ttmlSubtitle3;
                        if (eventType == 3) {
                            if (newPullParser.getName().equals(TtmlNode.TAG_TT)) {
                                ttmlSubtitle3 = new TtmlSubtitle((TtmlNode) linkedList.getLast(), hashMap);
                            } else {
                                ttmlSubtitle3 = ttmlSubtitle;
                            }
                            linkedList.removeLast();
                        } else {
                            ttmlSubtitle3 = ttmlSubtitle;
                        }
                        i4 = i3;
                        ttmlSubtitle2 = ttmlSubtitle3;
                    }
                } else if (eventType == 2) {
                    ttmlSubtitle2 = ttmlSubtitle;
                    i4 = i3 + 1;
                } else if (eventType == 3) {
                    ttmlSubtitle2 = ttmlSubtitle;
                    i4 = i3 - 1;
                } else {
                    ttmlSubtitle2 = ttmlSubtitle;
                    i4 = i3;
                }
                newPullParser.next();
                i3 = i4;
                ttmlSubtitle = ttmlSubtitle2;
            }
            return ttmlSubtitle;
        } catch (Throwable e2) {
            throw new ParserException("Unable to parse source", e2);
        } catch (Throwable e22) {
            throw new IllegalStateException("Unexpected error when reading input.", e22);
        }
    }

    private Map<String, TtmlStyle> parseHeader(XmlPullParser xmlPullParser, Map<String, TtmlStyle> map) throws IOException, XmlPullParserException {
        do {
            xmlPullParser.next();
            if (ParserUtil.isStartTag(xmlPullParser, "style")) {
                String attributeValue = xmlPullParser.getAttributeValue(null, "style");
                TtmlStyle parseStyleAttributes = parseStyleAttributes(xmlPullParser, new TtmlStyle());
                if (attributeValue != null) {
                    String[] parseStyleIds = parseStyleIds(attributeValue);
                    for (Object obj : parseStyleIds) {
                        parseStyleAttributes.chain((TtmlStyle) map.get(obj));
                    }
                }
                if (parseStyleAttributes.getId() != null) {
                    map.put(parseStyleAttributes.getId(), parseStyleAttributes);
                }
            }
        } while (!ParserUtil.isEndTag(xmlPullParser, TtmlNode.TAG_HEAD));
        return map;
    }

    private String[] parseStyleIds(String str) {
        return str.split("\\s+");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.exoplayer.text.ttml.TtmlStyle parseStyleAttributes(org.xmlpull.v1.XmlPullParser r13, com.google.android.exoplayer.text.ttml.TtmlStyle r14) {
        /*
        r12 = this;
        r6 = 3;
        r5 = 2;
        r3 = -1;
        r4 = 1;
        r2 = 0;
        r8 = r13.getAttributeCount();
        r7 = r2;
        r0 = r14;
    L_0x000b:
        if (r7 >= r8) goto L_0x021b;
    L_0x000d:
        r1 = r13.getAttributeName(r7);
        r9 = r13.getAttributeValue(r7);
        r1 = com.google.android.exoplayer.util.ParserUtil.removeNamespacePrefix(r1);
        r10 = r1.hashCode();
        switch(r10) {
            case -1550943582: goto L_0x0064;
            case -1224696685: goto L_0x0046;
            case -1065511464: goto L_0x006e;
            case -879295043: goto L_0x0078;
            case -734428249: goto L_0x005a;
            case 3355: goto L_0x0028;
            case 94842723: goto L_0x003c;
            case 365601008: goto L_0x0050;
            case 1287124693: goto L_0x0032;
            default: goto L_0x0020;
        };
    L_0x0020:
        r1 = r3;
    L_0x0021:
        switch(r1) {
            case 0: goto L_0x0083;
            case 1: goto L_0x0098;
            case 2: goto L_0x00c1;
            case 3: goto L_0x00eb;
            case 4: goto L_0x00f5;
            case 5: goto L_0x011b;
            case 6: goto L_0x012b;
            case 7: goto L_0x013b;
            case 8: goto L_0x01ba;
            default: goto L_0x0024;
        };
    L_0x0024:
        r1 = r7 + 1;
        r7 = r1;
        goto L_0x000b;
    L_0x0028:
        r10 = "id";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0030:
        r1 = r2;
        goto L_0x0021;
    L_0x0032:
        r10 = "backgroundColor";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x003a:
        r1 = r4;
        goto L_0x0021;
    L_0x003c:
        r10 = "color";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0044:
        r1 = r5;
        goto L_0x0021;
    L_0x0046:
        r10 = "fontFamily";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x004e:
        r1 = r6;
        goto L_0x0021;
    L_0x0050:
        r10 = "fontSize";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0058:
        r1 = 4;
        goto L_0x0021;
    L_0x005a:
        r10 = "fontWeight";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0062:
        r1 = 5;
        goto L_0x0021;
    L_0x0064:
        r10 = "fontStyle";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x006c:
        r1 = 6;
        goto L_0x0021;
    L_0x006e:
        r10 = "textAlign";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0076:
        r1 = 7;
        goto L_0x0021;
    L_0x0078:
        r10 = "textDecoration";
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0020;
    L_0x0080:
        r1 = 8;
        goto L_0x0021;
    L_0x0083:
        r1 = "style";
        r10 = r13.getName();
        r1 = r1.equals(r10);
        if (r1 == 0) goto L_0x0024;
    L_0x008f:
        r0 = r12.createIfNull(r0);
        r0 = r0.setId(r9);
        goto L_0x0024;
    L_0x0098:
        r0 = r12.createIfNull(r0);
        r1 = com.google.android.exoplayer.text.ttml.TtmlColorParser.parseColor(r9);	 Catch:{ IllegalArgumentException -> 0x00a4 }
        r0.setBackgroundColor(r1);	 Catch:{ IllegalArgumentException -> 0x00a4 }
        goto L_0x0024;
    L_0x00a4:
        r1 = move-exception;
        r1 = "TtmlParser";
        r10 = new java.lang.StringBuilder;
        r11 = "failed parsing background value: '";
        r10.<init>(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0024;
    L_0x00c1:
        r0 = r12.createIfNull(r0);
        r1 = com.google.android.exoplayer.text.ttml.TtmlColorParser.parseColor(r9);	 Catch:{ IllegalArgumentException -> 0x00ce }
        r0.setColor(r1);	 Catch:{ IllegalArgumentException -> 0x00ce }
        goto L_0x0024;
    L_0x00ce:
        r1 = move-exception;
        r1 = "TtmlParser";
        r10 = new java.lang.StringBuilder;
        r11 = "failed parsing color value: '";
        r10.<init>(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0024;
    L_0x00eb:
        r0 = r12.createIfNull(r0);
        r0 = r0.setFontFamily(r9);
        goto L_0x0024;
    L_0x00f5:
        r0 = r12.createIfNull(r0);	 Catch:{ ParserException -> 0x00fe }
        parseFontSize(r9, r0);	 Catch:{ ParserException -> 0x00fe }
        goto L_0x0024;
    L_0x00fe:
        r1 = move-exception;
        r1 = "TtmlParser";
        r10 = new java.lang.StringBuilder;
        r11 = "failed parsing fontSize value: '";
        r10.<init>(r11);
        r9 = r10.append(r9);
        r10 = "'";
        r9 = r9.append(r10);
        r9 = r9.toString();
        android.util.Log.w(r1, r9);
        goto L_0x0024;
    L_0x011b:
        r0 = r12.createIfNull(r0);
        r1 = "bold";
        r1 = r1.equalsIgnoreCase(r9);
        r0 = r0.setBold(r1);
        goto L_0x0024;
    L_0x012b:
        r0 = r12.createIfNull(r0);
        r1 = "italic";
        r1 = r1.equalsIgnoreCase(r9);
        r0 = r0.setItalic(r1);
        goto L_0x0024;
    L_0x013b:
        r1 = com.google.android.exoplayer.util.Util.toLowerInvariant(r9);
        r9 = r1.hashCode();
        switch(r9) {
            case -1364013995: goto L_0x0180;
            case 100571: goto L_0x0176;
            case 3317767: goto L_0x0158;
            case 108511772: goto L_0x016c;
            case 109757538: goto L_0x0162;
            default: goto L_0x0146;
        };
    L_0x0146:
        r1 = r3;
    L_0x0147:
        switch(r1) {
            case 0: goto L_0x014c;
            case 1: goto L_0x018a;
            case 2: goto L_0x0196;
            case 3: goto L_0x01a2;
            case 4: goto L_0x01ae;
            default: goto L_0x014a;
        };
    L_0x014a:
        goto L_0x0024;
    L_0x014c:
        r0 = r12.createIfNull(r0);
        r1 = android.text.Layout.Alignment.ALIGN_NORMAL;
        r0 = r0.setTextAlign(r1);
        goto L_0x0024;
    L_0x0158:
        r9 = "left";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0146;
    L_0x0160:
        r1 = r2;
        goto L_0x0147;
    L_0x0162:
        r9 = "start";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0146;
    L_0x016a:
        r1 = r4;
        goto L_0x0147;
    L_0x016c:
        r9 = "right";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0146;
    L_0x0174:
        r1 = r5;
        goto L_0x0147;
    L_0x0176:
        r9 = "end";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0146;
    L_0x017e:
        r1 = r6;
        goto L_0x0147;
    L_0x0180:
        r9 = "center";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x0146;
    L_0x0188:
        r1 = 4;
        goto L_0x0147;
    L_0x018a:
        r0 = r12.createIfNull(r0);
        r1 = android.text.Layout.Alignment.ALIGN_NORMAL;
        r0 = r0.setTextAlign(r1);
        goto L_0x0024;
    L_0x0196:
        r0 = r12.createIfNull(r0);
        r1 = android.text.Layout.Alignment.ALIGN_OPPOSITE;
        r0 = r0.setTextAlign(r1);
        goto L_0x0024;
    L_0x01a2:
        r0 = r12.createIfNull(r0);
        r1 = android.text.Layout.Alignment.ALIGN_OPPOSITE;
        r0 = r0.setTextAlign(r1);
        goto L_0x0024;
    L_0x01ae:
        r0 = r12.createIfNull(r0);
        r1 = android.text.Layout.Alignment.ALIGN_CENTER;
        r0 = r0.setTextAlign(r1);
        goto L_0x0024;
    L_0x01ba:
        r1 = com.google.android.exoplayer.util.Util.toLowerInvariant(r9);
        r9 = r1.hashCode();
        switch(r9) {
            case -1461280213: goto L_0x01f3;
            case -1026963764: goto L_0x01e9;
            case 913457136: goto L_0x01df;
            case 1679736913: goto L_0x01d5;
            default: goto L_0x01c5;
        };
    L_0x01c5:
        r1 = r3;
    L_0x01c6:
        switch(r1) {
            case 0: goto L_0x01cb;
            case 1: goto L_0x01fd;
            case 2: goto L_0x0207;
            case 3: goto L_0x0211;
            default: goto L_0x01c9;
        };
    L_0x01c9:
        goto L_0x0024;
    L_0x01cb:
        r0 = r12.createIfNull(r0);
        r0 = r0.setLinethrough(r4);
        goto L_0x0024;
    L_0x01d5:
        r9 = "linethrough";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01c5;
    L_0x01dd:
        r1 = r2;
        goto L_0x01c6;
    L_0x01df:
        r9 = "nolinethrough";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01c5;
    L_0x01e7:
        r1 = r4;
        goto L_0x01c6;
    L_0x01e9:
        r9 = "underline";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01c5;
    L_0x01f1:
        r1 = r5;
        goto L_0x01c6;
    L_0x01f3:
        r9 = "nounderline";
        r1 = r1.equals(r9);
        if (r1 == 0) goto L_0x01c5;
    L_0x01fb:
        r1 = r6;
        goto L_0x01c6;
    L_0x01fd:
        r0 = r12.createIfNull(r0);
        r0 = r0.setLinethrough(r2);
        goto L_0x0024;
    L_0x0207:
        r0 = r12.createIfNull(r0);
        r0 = r0.setUnderline(r4);
        goto L_0x0024;
    L_0x0211:
        r0 = r12.createIfNull(r0);
        r0 = r0.setUnderline(r2);
        goto L_0x0024;
    L_0x021b:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer.text.ttml.TtmlParser.parseStyleAttributes(org.xmlpull.v1.XmlPullParser, com.google.android.exoplayer.text.ttml.TtmlStyle):com.google.android.exoplayer.text.ttml.TtmlStyle");
    }

    private TtmlStyle createIfNull(TtmlStyle ttmlStyle) {
        return ttmlStyle == null ? new TtmlStyle() : ttmlStyle;
    }

    private TtmlNode parseNode(XmlPullParser xmlPullParser, TtmlNode ttmlNode) throws ParserException {
        long j;
        long j2 = 0;
        long j3 = -1;
        long j4 = -1;
        String[] strArr = null;
        int attributeCount = xmlPullParser.getAttributeCount();
        TtmlStyle parseStyleAttributes = parseStyleAttributes(xmlPullParser, null);
        int i = 0;
        while (i < attributeCount) {
            long j5;
            String removeNamespacePrefix = ParserUtil.removeNamespacePrefix(xmlPullParser.getAttributeName(i));
            String attributeValue = xmlPullParser.getAttributeValue(i);
            if (removeNamespacePrefix.equals(ATTR_BEGIN)) {
                j3 = j2;
                j5 = j4;
                j4 = parseTimeExpression(attributeValue, 30, 1, 1);
            } else if (removeNamespacePrefix.equals("end")) {
                j5 = parseTimeExpression(attributeValue, 30, 1, 1);
                j4 = j3;
                j3 = j2;
            } else if (removeNamespacePrefix.equals(ATTR_DURATION)) {
                j = j4;
                j4 = j3;
                j3 = parseTimeExpression(attributeValue, 30, 1, 1);
                j5 = j;
            } else {
                if (removeNamespacePrefix.equals("style")) {
                    String[] parseStyleIds = parseStyleIds(attributeValue);
                    if (parseStyleIds.length > 0) {
                        strArr = parseStyleIds;
                        j5 = j4;
                        j4 = j3;
                        j3 = j2;
                    }
                }
                j5 = j4;
                j4 = j3;
                j3 = j2;
            }
            i++;
            j2 = j3;
            j3 = j4;
            j4 = j5;
        }
        if (!(ttmlNode == null || ttmlNode.startTimeUs == -1)) {
            if (j3 != -1) {
                j3 += ttmlNode.startTimeUs;
            }
            if (j4 != -1) {
                j = j4 + ttmlNode.startTimeUs;
                j4 = j3;
                j3 = j;
                if (j3 == -1) {
                    if (j2 <= 0) {
                        j3 = j4 + j2;
                    } else if (!(ttmlNode == null || ttmlNode.endTimeUs == -1)) {
                        j3 = ttmlNode.endTimeUs;
                    }
                }
                return TtmlNode.buildNode(xmlPullParser.getName(), j4, j3, parseStyleAttributes, strArr);
            }
        }
        j = j4;
        j4 = j3;
        j3 = j;
        if (j3 == -1) {
            if (j2 <= 0) {
                j3 = ttmlNode.endTimeUs;
            } else {
                j3 = j4 + j2;
            }
        }
        return TtmlNode.buildNode(xmlPullParser.getName(), j4, j3, parseStyleAttributes, strArr);
    }

    private static boolean isSupportedTag(String str) {
        if (str.equals(TtmlNode.TAG_TT) || str.equals(TtmlNode.TAG_HEAD) || str.equals(TtmlNode.TAG_BODY) || str.equals(TtmlNode.TAG_DIV) || str.equals(TtmlNode.TAG_P) || str.equals(TtmlNode.TAG_SPAN) || str.equals(TtmlNode.TAG_BR) || str.equals("style") || str.equals(TtmlNode.TAG_STYLING) || str.equals(TtmlNode.TAG_LAYOUT) || str.equals(TtmlNode.TAG_REGION) || str.equals(TtmlNode.TAG_METADATA) || str.equals(TtmlNode.TAG_SMPTE_IMAGE) || str.equals(TtmlNode.TAG_SMPTE_DATA) || str.equals(TtmlNode.TAG_SMPTE_INFORMATION)) {
            return true;
        }
        return false;
    }

    private static void parseFontSize(String str, TtmlStyle ttmlStyle) throws ParserException {
        Matcher matcher;
        String[] split = str.split("\\s+");
        if (split.length == 1) {
            matcher = FONT_SIZE.matcher(str);
        } else if (split.length == 2) {
            matcher = FONT_SIZE.matcher(split[1]);
            Log.w(TAG, "multiple values in fontSize attribute. Picking the second value for vertical font size and ignoring the first.");
        } else {
            throw new ParserException();
        }
        if (matcher.matches()) {
            String group = matcher.group(3);
            short s = (short) -1;
            switch (group.hashCode()) {
                case 37:
                    if (group.equals("%")) {
                        s = (short) 2;
                        break;
                    }
                    break;
                case 3240:
                    if (group.equals("em")) {
                        s = (short) 1;
                        break;
                    }
                    break;
                case 3592:
                    if (group.equals("px")) {
                        s = (short) 0;
                        break;
                    }
                    break;
            }
            switch (s) {
                case (short) 0:
                    ttmlStyle.setFontSizeUnit((short) 1);
                    break;
                case (short) 1:
                    ttmlStyle.setFontSizeUnit((short) 2);
                    break;
                case (short) 2:
                    ttmlStyle.setFontSizeUnit((short) 3);
                    break;
                default:
                    throw new ParserException();
            }
            ttmlStyle.setFontSize(Float.valueOf(matcher.group(1)).floatValue());
            return;
        }
        throw new ParserException();
    }

    private static long parseTimeExpression(String str, int i, int i2, int i3) throws ParserException {
        double d = 0.0d;
        Matcher matcher = CLOCK_TIME.matcher(str);
        double parseLong;
        if (matcher.matches()) {
            double parseLong2 = ((double) Long.parseLong(matcher.group(3))) + (((double) (Long.parseLong(matcher.group(1)) * 3600)) + ((double) (Long.parseLong(matcher.group(2)) * 60)));
            String group = matcher.group(4);
            parseLong2 += group != null ? Double.parseDouble(group) : 0.0d;
            group = matcher.group(5);
            if (group != null) {
                parseLong = ((double) Long.parseLong(group)) / ((double) i);
            } else {
                parseLong = 0.0d;
            }
            parseLong += parseLong2;
            String group2 = matcher.group(6);
            if (group2 != null) {
                d = (((double) Long.parseLong(group2)) / ((double) i2)) / ((double) i);
            }
            return (long) ((parseLong + d) * 1000000.0d);
        }
        Matcher matcher2 = OFFSET_TIME.matcher(str);
        if (matcher2.matches()) {
            parseLong = Double.parseDouble(matcher2.group(1));
            String group3 = matcher2.group(2);
            if (group3.equals("h")) {
                parseLong *= 3600.0d;
            } else if (group3.equals("m")) {
                parseLong *= 60.0d;
            } else if (!group3.equals("s")) {
                if (group3.equals("ms")) {
                    parseLong /= 1000.0d;
                } else if (group3.equals("f")) {
                    parseLong /= (double) i;
                } else if (group3.equals("t")) {
                    parseLong /= (double) i3;
                }
            }
            return (long) (parseLong * 1000000.0d);
        }
        throw new ParserException("Malformed time expression: " + str);
    }
}
