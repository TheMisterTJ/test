package com.google.android.exoplayer.extractor.webm;

import android.util.Pair;
import android.util.SparseArray;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.drm.DrmInitData.SchemeInitData;
import com.google.android.exoplayer.drm.DrmInitData.Universal;
import com.google.android.exoplayer.extractor.ChunkIndex;
import com.google.android.exoplayer.extractor.Extractor;
import com.google.android.exoplayer.extractor.ExtractorInput;
import com.google.android.exoplayer.extractor.ExtractorOutput;
import com.google.android.exoplayer.extractor.PositionHolder;
import com.google.android.exoplayer.extractor.SeekMap;
import com.google.android.exoplayer.extractor.TrackOutput;
import com.google.android.exoplayer.util.LongArray;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.NalUnitUtil;
import com.google.android.exoplayer.util.ParsableByteArray;
import com.google.android.exoplayer.util.Util;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class WebmExtractor implements Extractor {
    private static final int BLOCK_STATE_DATA = 2;
    private static final int BLOCK_STATE_HEADER = 1;
    private static final int BLOCK_STATE_START = 0;
    private static final String CODEC_ID_AAC = "A_AAC";
    private static final String CODEC_ID_AC3 = "A_AC3";
    private static final String CODEC_ID_DTS = "A_DTS";
    private static final String CODEC_ID_DTS_EXPRESS = "A_DTS/EXPRESS";
    private static final String CODEC_ID_DTS_LOSSLESS = "A_DTS/LOSSLESS";
    private static final String CODEC_ID_E_AC3 = "A_EAC3";
    private static final String CODEC_ID_H264 = "V_MPEG4/ISO/AVC";
    private static final String CODEC_ID_H265 = "V_MPEGH/ISO/HEVC";
    private static final String CODEC_ID_MP3 = "A_MPEG/L3";
    private static final String CODEC_ID_MPEG2 = "V_MPEG2";
    private static final String CODEC_ID_MPEG4_AP = "V_MPEG4/ISO/AP";
    private static final String CODEC_ID_MPEG4_ASP = "V_MPEG4/ISO/ASP";
    private static final String CODEC_ID_MPEG4_SP = "V_MPEG4/ISO/SP";
    private static final String CODEC_ID_OPUS = "A_OPUS";
    private static final String CODEC_ID_SUBRIP = "S_TEXT/UTF8";
    private static final String CODEC_ID_TRUEHD = "A_TRUEHD";
    private static final String CODEC_ID_VORBIS = "A_VORBIS";
    private static final String CODEC_ID_VP8 = "V_VP8";
    private static final String CODEC_ID_VP9 = "V_VP9";
    private static final String DOC_TYPE_MATROSKA = "matroska";
    private static final String DOC_TYPE_WEBM = "webm";
    private static final int ENCRYPTION_IV_SIZE = 8;
    private static final int ID_AUDIO = 225;
    private static final int ID_BLOCK = 161;
    private static final int ID_BLOCK_DURATION = 155;
    private static final int ID_BLOCK_GROUP = 160;
    private static final int ID_CHANNELS = 159;
    private static final int ID_CLUSTER = 524531317;
    private static final int ID_CODEC_DELAY = 22186;
    private static final int ID_CODEC_ID = 134;
    private static final int ID_CODEC_PRIVATE = 25506;
    private static final int ID_CONTENT_COMPRESSION = 20532;
    private static final int ID_CONTENT_COMPRESSION_ALGORITHM = 16980;
    private static final int ID_CONTENT_COMPRESSION_SETTINGS = 16981;
    private static final int ID_CONTENT_ENCODING = 25152;
    private static final int ID_CONTENT_ENCODINGS = 28032;
    private static final int ID_CONTENT_ENCODING_ORDER = 20529;
    private static final int ID_CONTENT_ENCODING_SCOPE = 20530;
    private static final int ID_CONTENT_ENCRYPTION = 20533;
    private static final int ID_CONTENT_ENCRYPTION_AES_SETTINGS = 18407;
    private static final int ID_CONTENT_ENCRYPTION_AES_SETTINGS_CIPHER_MODE = 18408;
    private static final int ID_CONTENT_ENCRYPTION_ALGORITHM = 18401;
    private static final int ID_CONTENT_ENCRYPTION_KEY_ID = 18402;
    private static final int ID_CUES = 475249515;
    private static final int ID_CUE_CLUSTER_POSITION = 241;
    private static final int ID_CUE_POINT = 187;
    private static final int ID_CUE_TIME = 179;
    private static final int ID_CUE_TRACK_POSITIONS = 183;
    private static final int ID_DEFAULT_DURATION = 2352003;
    private static final int ID_DOC_TYPE = 17026;
    private static final int ID_DOC_TYPE_READ_VERSION = 17029;
    private static final int ID_DURATION = 17545;
    private static final int ID_EBML = 440786851;
    private static final int ID_EBML_READ_VERSION = 17143;
    private static final int ID_INFO = 357149030;
    private static final int ID_LANGUAGE = 2274716;
    private static final int ID_PIXEL_HEIGHT = 186;
    private static final int ID_PIXEL_WIDTH = 176;
    private static final int ID_REFERENCE_BLOCK = 251;
    private static final int ID_SAMPLING_FREQUENCY = 181;
    private static final int ID_SEEK = 19899;
    private static final int ID_SEEK_HEAD = 290298740;
    private static final int ID_SEEK_ID = 21419;
    private static final int ID_SEEK_POSITION = 21420;
    private static final int ID_SEEK_PRE_ROLL = 22203;
    private static final int ID_SEGMENT = 408125543;
    private static final int ID_SEGMENT_INFO = 357149030;
    private static final int ID_SIMPLE_BLOCK = 163;
    private static final int ID_TIMECODE_SCALE = 2807729;
    private static final int ID_TIME_CODE = 231;
    private static final int ID_TRACKS = 374648427;
    private static final int ID_TRACK_ENTRY = 174;
    private static final int ID_TRACK_NUMBER = 215;
    private static final int ID_TRACK_TYPE = 131;
    private static final int ID_VIDEO = 224;
    private static final int LACING_EBML = 3;
    private static final int LACING_FIXED_SIZE = 2;
    private static final int LACING_NONE = 0;
    private static final int LACING_XIPH = 1;
    private static final int MP3_MAX_INPUT_SIZE = 4096;
    private static final int OPUS_MAX_INPUT_SIZE = 5760;
    private static final byte[] SUBRIP_PREFIX = new byte[]{(byte) 49, (byte) 10, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, ClosedCaptionCtrl.ERASE_DISPLAYED_MEMORY, (byte) 48, (byte) 48, (byte) 48, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.CARRIAGE_RETURN, ClosedCaptionCtrl.CARRIAGE_RETURN, (byte) 62, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, (byte) 58, (byte) 48, (byte) 48, ClosedCaptionCtrl.ERASE_DISPLAYED_MEMORY, (byte) 48, (byte) 48, (byte) 48, (byte) 10};
    private static final int SUBRIP_PREFIX_END_TIMECODE_OFFSET = 19;
    private static final byte[] SUBRIP_TIMECODE_EMPTY = new byte[]{ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING, ClosedCaptionCtrl.RESUME_CAPTION_LOADING};
    private static final int SUBRIP_TIMECODE_LENGTH = 12;
    private static final int TRACK_TYPE_AUDIO = 2;
    private static final int UNKNOWN = -1;
    private static final int VORBIS_MAX_INPUT_SIZE = 8192;
    private long blockDurationUs;
    private int blockFlags;
    private int blockLacingSampleCount;
    private int blockLacingSampleIndex;
    private int[] blockLacingSampleSizes;
    private int blockState;
    private long blockTimeUs;
    private int blockTrackNumber;
    private int blockTrackNumberLength;
    private long clusterTimecodeUs;
    private LongArray cueClusterPositions;
    private LongArray cueTimesUs;
    private long cuesContentPosition;
    private Track currentTrack;
    private long durationTimecode;
    private long durationUs;
    private ExtractorOutput extractorOutput;
    private final ParsableByteArray nalLength;
    private final ParsableByteArray nalStartCode;
    private final EbmlReader reader;
    private int sampleBytesRead;
    private int sampleBytesWritten;
    private int sampleCurrentNalBytesRemaining;
    private boolean sampleEncodingHandled;
    private boolean sampleRead;
    private boolean sampleSeenReferenceBlock;
    private final ParsableByteArray sampleStrippedBytes;
    private final ParsableByteArray scratch;
    private int seekEntryId;
    private final ParsableByteArray seekEntryIdBytes;
    private long seekEntryPosition;
    private boolean seekForCues;
    private long seekPositionAfterBuildingCues;
    private boolean seenClusterPositionForCurrentCuePoint;
    private long segmentContentPosition;
    private long segmentContentSize;
    private boolean sentDrmInitData;
    private boolean sentSeekMap;
    private final ParsableByteArray subripSample;
    private long timecodeScale;
    private final SparseArray<Track> tracks;
    private final VarintReader varintReader;
    private final ParsableByteArray vorbisNumPageSamples;

    private final class InnerEbmlReaderOutput implements EbmlReaderOutput {
        private InnerEbmlReaderOutput() {
        }

        public final int getElementType(int i) {
            return WebmExtractor.this.getElementType(i);
        }

        public final boolean isLevel1Element(int i) {
            return WebmExtractor.this.isLevel1Element(i);
        }

        public final void startMasterElement(int i, long j, long j2) throws ParserException {
            WebmExtractor.this.startMasterElement(i, j, j2);
        }

        public final void endMasterElement(int i) throws ParserException {
            WebmExtractor.this.endMasterElement(i);
        }

        public final void integerElement(int i, long j) throws ParserException {
            WebmExtractor.this.integerElement(i, j);
        }

        public final void floatElement(int i, double d) throws ParserException {
            WebmExtractor.this.floatElement(i, d);
        }

        public final void stringElement(int i, String str) throws ParserException {
            WebmExtractor.this.stringElement(i, str);
        }

        public final void binaryElement(int i, int i2, ExtractorInput extractorInput) throws IOException, InterruptedException {
            WebmExtractor.this.binaryElement(i, i2, extractorInput);
        }
    }

    private static final class Track {
        public int channelCount;
        public long codecDelayNs;
        public String codecId;
        public byte[] codecPrivate;
        public int defaultSampleDurationNs;
        public byte[] encryptionKeyId;
        public boolean hasContentEncryption;
        public int height;
        private String language;
        public int nalUnitLengthFieldLength;
        public int number;
        public TrackOutput output;
        public int sampleRate;
        public byte[] sampleStrippedBytes;
        public long seekPreRollNs;
        public int type;
        public int width;

        private Track() {
            this.width = -1;
            this.height = -1;
            this.channelCount = 1;
            this.sampleRate = 8000;
            this.codecDelayNs = 0;
            this.seekPreRollNs = 0;
            this.language = "eng";
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void initializeOutput(com.google.android.exoplayer.extractor.ExtractorOutput r12, int r13, long r14) throws com.google.android.exoplayer.ParserException {
            /*
            r11 = this;
            r0 = 0;
            r4 = 3;
            r5 = 8;
            r2 = -1;
            r1 = r11.codecId;
            r3 = r1.hashCode();
            switch(r3) {
                case -2095576542: goto L_0x004c;
                case -2095575984: goto L_0x0038;
                case -1784763192: goto L_0x00ae;
                case -1730367663: goto L_0x006a;
                case -1482641357: goto L_0x008a;
                case -538363189: goto L_0x0042;
                case -538363109: goto L_0x0056;
                case -356037306: goto L_0x00d2;
                case 62923557: goto L_0x007f;
                case 62923603: goto L_0x0096;
                case 62927045: goto L_0x00ba;
                case 82338133: goto L_0x001a;
                case 82338134: goto L_0x0024;
                case 542569478: goto L_0x00c6;
                case 855502857: goto L_0x0060;
                case 1422270023: goto L_0x00de;
                case 1809237540: goto L_0x002e;
                case 1950749482: goto L_0x00a2;
                case 1951062397: goto L_0x0074;
                default: goto L_0x000e;
            };
        L_0x000e:
            r1 = r2;
        L_0x000f:
            switch(r1) {
                case 0: goto L_0x00ea;
                case 1: goto L_0x0111;
                case 2: goto L_0x0116;
                case 3: goto L_0x011b;
                case 4: goto L_0x011b;
                case 5: goto L_0x011b;
                case 6: goto L_0x012b;
                case 7: goto L_0x014a;
                case 8: goto L_0x0169;
                case 9: goto L_0x0176;
                case 10: goto L_0x01b5;
                case 11: goto L_0x01c1;
                case 12: goto L_0x01c8;
                case 13: goto L_0x01ce;
                case 14: goto L_0x01d4;
                case 15: goto L_0x01da;
                case 16: goto L_0x01da;
                case 17: goto L_0x01e0;
                case 18: goto L_0x01e6;
                default: goto L_0x0012;
            };
        L_0x0012:
            r0 = new com.google.android.exoplayer.ParserException;
            r1 = "Unrecognized codec identifier.";
            r0.<init>(r1);
            throw r0;
        L_0x001a:
            r3 = "V_VP8";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0022:
            r1 = 0;
            goto L_0x000f;
        L_0x0024:
            r3 = "V_VP9";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x002c:
            r1 = 1;
            goto L_0x000f;
        L_0x002e:
            r3 = "V_MPEG2";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0036:
            r1 = 2;
            goto L_0x000f;
        L_0x0038:
            r3 = "V_MPEG4/ISO/SP";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0040:
            r1 = r4;
            goto L_0x000f;
        L_0x0042:
            r3 = "V_MPEG4/ISO/ASP";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x004a:
            r1 = 4;
            goto L_0x000f;
        L_0x004c:
            r3 = "V_MPEG4/ISO/AP";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0054:
            r1 = 5;
            goto L_0x000f;
        L_0x0056:
            r3 = "V_MPEG4/ISO/AVC";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x005e:
            r1 = 6;
            goto L_0x000f;
        L_0x0060:
            r3 = "V_MPEGH/ISO/HEVC";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0068:
            r1 = 7;
            goto L_0x000f;
        L_0x006a:
            r3 = "A_VORBIS";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0072:
            r1 = r5;
            goto L_0x000f;
        L_0x0074:
            r3 = "A_OPUS";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x007c:
            r1 = 9;
            goto L_0x000f;
        L_0x007f:
            r3 = "A_AAC";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0087:
            r1 = 10;
            goto L_0x000f;
        L_0x008a:
            r3 = "A_MPEG/L3";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x0092:
            r1 = 11;
            goto L_0x000f;
        L_0x0096:
            r3 = "A_AC3";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x009e:
            r1 = 12;
            goto L_0x000f;
        L_0x00a2:
            r3 = "A_EAC3";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00aa:
            r1 = 13;
            goto L_0x000f;
        L_0x00ae:
            r3 = "A_TRUEHD";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00b6:
            r1 = 14;
            goto L_0x000f;
        L_0x00ba:
            r3 = "A_DTS";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00c2:
            r1 = 15;
            goto L_0x000f;
        L_0x00c6:
            r3 = "A_DTS/EXPRESS";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00ce:
            r1 = 16;
            goto L_0x000f;
        L_0x00d2:
            r3 = "A_DTS/LOSSLESS";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00da:
            r1 = 17;
            goto L_0x000f;
        L_0x00de:
            r3 = "S_TEXT/UTF8";
            r1 = r1.equals(r3);
            if (r1 == 0) goto L_0x000e;
        L_0x00e6:
            r1 = 18;
            goto L_0x000f;
        L_0x00ea:
            r1 = "video/x-vnd.on2.vp8";
            r8 = r0;
            r3 = r2;
        L_0x00ee:
            r0 = com.google.android.exoplayer.util.MimeTypes.isAudio(r1);
            if (r0 == 0) goto L_0x01ec;
        L_0x00f4:
            r0 = java.lang.Integer.toString(r13);
            r6 = r11.channelCount;
            r7 = r11.sampleRate;
            r9 = r11.language;
            r4 = r14;
            r0 = com.google.android.exoplayer.MediaFormat.createAudioFormat(r0, r1, r2, r3, r4, r6, r7, r8, r9);
        L_0x0103:
            r1 = r11.number;
            r1 = r12.track(r1);
            r11.output = r1;
            r1 = r11.output;
            r1.format(r0);
            return;
        L_0x0111:
            r1 = "video/x-vnd.on2.vp9";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x0116:
            r1 = "video/mpeg2";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x011b:
            r1 = "video/mp4v-es";
            r3 = r11.codecPrivate;
            if (r3 != 0) goto L_0x0124;
        L_0x0121:
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x0124:
            r0 = r11.codecPrivate;
            r0 = java.util.Collections.singletonList(r0);
            goto L_0x0121;
        L_0x012b:
            r3 = "video/avc";
            r0 = new com.google.android.exoplayer.util.ParsableByteArray;
            r1 = r11.codecPrivate;
            r0.<init>(r1);
            r1 = parseAvcCodecPrivate(r0);
            r0 = r1.first;
            r0 = (java.util.List) r0;
            r1 = r1.second;
            r1 = (java.lang.Integer) r1;
            r1 = r1.intValue();
            r11.nalUnitLengthFieldLength = r1;
            r8 = r0;
            r1 = r3;
            r3 = r2;
            goto L_0x00ee;
        L_0x014a:
            r3 = "video/hevc";
            r0 = new com.google.android.exoplayer.util.ParsableByteArray;
            r1 = r11.codecPrivate;
            r0.<init>(r1);
            r1 = parseHevcCodecPrivate(r0);
            r0 = r1.first;
            r0 = (java.util.List) r0;
            r1 = r1.second;
            r1 = (java.lang.Integer) r1;
            r1 = r1.intValue();
            r11.nalUnitLengthFieldLength = r1;
            r8 = r0;
            r1 = r3;
            r3 = r2;
            goto L_0x00ee;
        L_0x0169:
            r1 = "audio/vorbis";
            r3 = 8192; // 0x2000 float:1.14794E-41 double:4.0474E-320;
            r0 = r11.codecPrivate;
            r0 = parseVorbisCodecPrivate(r0);
            r8 = r0;
            goto L_0x00ee;
        L_0x0176:
            r1 = "audio/opus";
            r3 = 5760; // 0x1680 float:8.071E-42 double:2.846E-320;
            r0 = new java.util.ArrayList;
            r0.<init>(r4);
            r4 = r11.codecPrivate;
            r0.add(r4);
            r4 = java.nio.ByteBuffer.allocate(r5);
            r6 = java.nio.ByteOrder.LITTLE_ENDIAN;
            r4 = r4.order(r6);
            r6 = r11.codecDelayNs;
            r4 = r4.putLong(r6);
            r4 = r4.array();
            r0.add(r4);
            r4 = java.nio.ByteBuffer.allocate(r5);
            r5 = java.nio.ByteOrder.LITTLE_ENDIAN;
            r4 = r4.order(r5);
            r6 = r11.seekPreRollNs;
            r4 = r4.putLong(r6);
            r4 = r4.array();
            r0.add(r4);
            r8 = r0;
            goto L_0x00ee;
        L_0x01b5:
            r1 = "audio/mp4a-latm";
            r0 = r11.codecPrivate;
            r0 = java.util.Collections.singletonList(r0);
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01c1:
            r1 = "audio/mpeg";
            r3 = 4096; // 0x1000 float:5.74E-42 double:2.0237E-320;
            r8 = r0;
            goto L_0x00ee;
        L_0x01c8:
            r1 = "audio/ac3";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01ce:
            r1 = "audio/eac3";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01d4:
            r1 = "audio/true-hd";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01da:
            r1 = "audio/vnd.dts";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01e0:
            r1 = "audio/vnd.dts.hd";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01e6:
            r1 = "application/x-subrip";
            r8 = r0;
            r3 = r2;
            goto L_0x00ee;
        L_0x01ec:
            r0 = com.google.android.exoplayer.util.MimeTypes.isVideo(r1);
            if (r0 == 0) goto L_0x0201;
        L_0x01f2:
            r0 = java.lang.Integer.toString(r13);
            r6 = r11.width;
            r7 = r11.height;
            r4 = r14;
            r0 = com.google.android.exoplayer.MediaFormat.createVideoFormat(r0, r1, r2, r3, r4, r6, r7, r8);
            goto L_0x0103;
        L_0x0201:
            r0 = "application/x-subrip";
            r0 = r0.equals(r1);
            if (r0 == 0) goto L_0x0216;
        L_0x0209:
            r0 = java.lang.Integer.toString(r13);
            r5 = r11.language;
            r3 = r14;
            r0 = com.google.android.exoplayer.MediaFormat.createTextFormat(r0, r1, r2, r3, r5);
            goto L_0x0103;
        L_0x0216:
            r0 = new com.google.android.exoplayer.ParserException;
            r1 = "Unexpected MIME type.";
            r0.<init>(r1);
            throw r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer.extractor.webm.WebmExtractor.Track.initializeOutput(com.google.android.exoplayer.extractor.ExtractorOutput, int, long):void");
        }

        private static Pair<List<byte[]>, Integer> parseAvcCodecPrivate(ParsableByteArray parsableByteArray) throws ParserException {
            int i = 0;
            try {
                parsableByteArray.setPosition(4);
                int readUnsignedByte = (parsableByteArray.readUnsignedByte() & 3) + 1;
                if (readUnsignedByte == 3) {
                    throw new ParserException();
                }
                int i2;
                List arrayList = new ArrayList();
                int readUnsignedByte2 = parsableByteArray.readUnsignedByte() & 31;
                for (i2 = 0; i2 < readUnsignedByte2; i2++) {
                    arrayList.add(NalUnitUtil.parseChildNalUnit(parsableByteArray));
                }
                i2 = parsableByteArray.readUnsignedByte();
                while (i < i2) {
                    arrayList.add(NalUnitUtil.parseChildNalUnit(parsableByteArray));
                    i++;
                }
                return Pair.create(arrayList, Integer.valueOf(readUnsignedByte));
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing AVC codec private");
            }
        }

        private static Pair<List<byte[]>, Integer> parseHevcCodecPrivate(ParsableByteArray parsableByteArray) throws ParserException {
            try {
                int readUnsignedShort;
                int i;
                int i2;
                parsableByteArray.setPosition(21);
                int readUnsignedByte = parsableByteArray.readUnsignedByte() & 3;
                int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
                int position = parsableByteArray.getPosition();
                int i3 = 0;
                int i4 = 0;
                while (i3 < readUnsignedByte2) {
                    parsableByteArray.skipBytes(1);
                    readUnsignedShort = parsableByteArray.readUnsignedShort();
                    i = i4;
                    for (i2 = 0; i2 < readUnsignedShort; i2++) {
                        i4 = parsableByteArray.readUnsignedShort();
                        i += i4 + 4;
                        parsableByteArray.skipBytes(i4);
                    }
                    i3++;
                    i4 = i;
                }
                parsableByteArray.setPosition(position);
                Object obj = new byte[i4];
                i2 = 0;
                for (i3 = 0; i3 < readUnsignedByte2; i3++) {
                    parsableByteArray.skipBytes(1);
                    readUnsignedShort = parsableByteArray.readUnsignedShort();
                    for (i = 0; i < readUnsignedShort; i++) {
                        int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
                        System.arraycopy(NalUnitUtil.NAL_START_CODE, 0, obj, i2, NalUnitUtil.NAL_START_CODE.length);
                        i2 += NalUnitUtil.NAL_START_CODE.length;
                        System.arraycopy(parsableByteArray.data, parsableByteArray.getPosition(), obj, i2, readUnsignedShort2);
                        i2 += readUnsignedShort2;
                        parsableByteArray.skipBytes(readUnsignedShort2);
                    }
                }
                return Pair.create(i4 == 0 ? null : Collections.singletonList(obj), Integer.valueOf(readUnsignedByte + 1));
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing HEVC codec private");
            }
        }

        private static List<byte[]> parseVorbisCodecPrivate(byte[] bArr) throws ParserException {
            int i = 0;
            try {
                if (bArr[0] != (byte) 2) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                int i2 = 0;
                int i3 = 1;
                while (bArr[i3] == (byte) -1) {
                    i3++;
                    i2 += 255;
                }
                int i4 = i3 + 1;
                i2 += bArr[i3];
                while (bArr[i4] == (byte) -1) {
                    i += 255;
                    i4++;
                }
                i3 = i4 + 1;
                i += bArr[i4];
                if (bArr[i3] != (byte) 1) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                Object obj = new byte[i2];
                System.arraycopy(bArr, i3, obj, 0, i2);
                i2 += i3;
                if (bArr[i2] != (byte) 3) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                i += i2;
                if (bArr[i] != (byte) 5) {
                    throw new ParserException("Error parsing vorbis codec private");
                }
                Object obj2 = new byte[(bArr.length - i)];
                System.arraycopy(bArr, i, obj2, 0, bArr.length - i);
                List<byte[]> arrayList = new ArrayList(2);
                arrayList.add(obj);
                arrayList.add(obj2);
                return arrayList;
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new ParserException("Error parsing vorbis codec private");
            }
        }
    }

    public WebmExtractor() {
        this(new DefaultEbmlReader());
    }

    WebmExtractor(EbmlReader ebmlReader) {
        this.segmentContentPosition = -1;
        this.segmentContentSize = -1;
        this.timecodeScale = -1;
        this.durationTimecode = -1;
        this.durationUs = -1;
        this.cuesContentPosition = -1;
        this.seekPositionAfterBuildingCues = -1;
        this.clusterTimecodeUs = -1;
        this.reader = ebmlReader;
        this.reader.init(new InnerEbmlReaderOutput());
        this.varintReader = new VarintReader();
        this.tracks = new SparseArray();
        this.scratch = new ParsableByteArray(4);
        this.vorbisNumPageSamples = new ParsableByteArray(ByteBuffer.allocate(4).putInt(-1).array());
        this.seekEntryIdBytes = new ParsableByteArray(4);
        this.nalStartCode = new ParsableByteArray(NalUnitUtil.NAL_START_CODE);
        this.nalLength = new ParsableByteArray(4);
        this.sampleStrippedBytes = new ParsableByteArray();
        this.subripSample = new ParsableByteArray();
    }

    public final boolean sniff(ExtractorInput extractorInput) throws IOException, InterruptedException {
        return new Sniffer().sniff(extractorInput);
    }

    public final void init(ExtractorOutput extractorOutput) {
        this.extractorOutput = extractorOutput;
    }

    public final void seek() {
        this.clusterTimecodeUs = -1;
        this.blockState = 0;
        this.reader.reset();
        this.varintReader.reset();
        resetSample();
    }

    public final int read(ExtractorInput extractorInput, PositionHolder positionHolder) throws IOException, InterruptedException {
        this.sampleRead = false;
        boolean z = true;
        while (z && !this.sampleRead) {
            z = this.reader.read(extractorInput);
            if (z && maybeSeekForCues(positionHolder, extractorInput.getPosition())) {
                return 1;
            }
        }
        return z ? 0 : -1;
    }

    final int getElementType(int i) {
        switch (i) {
            case ID_TRACK_TYPE /*131*/:
            case ID_BLOCK_DURATION /*155*/:
            case ID_CHANNELS /*159*/:
            case ID_PIXEL_WIDTH /*176*/:
            case ID_CUE_TIME /*179*/:
            case ID_PIXEL_HEIGHT /*186*/:
            case ID_TRACK_NUMBER /*215*/:
            case ID_TIME_CODE /*231*/:
            case ID_CUE_CLUSTER_POSITION /*241*/:
            case ID_REFERENCE_BLOCK /*251*/:
            case ID_CONTENT_COMPRESSION_ALGORITHM /*16980*/:
            case ID_DOC_TYPE_READ_VERSION /*17029*/:
            case ID_EBML_READ_VERSION /*17143*/:
            case ID_CONTENT_ENCRYPTION_ALGORITHM /*18401*/:
            case ID_CONTENT_ENCRYPTION_AES_SETTINGS_CIPHER_MODE /*18408*/:
            case ID_CONTENT_ENCODING_ORDER /*20529*/:
            case ID_CONTENT_ENCODING_SCOPE /*20530*/:
            case ID_SEEK_POSITION /*21420*/:
            case ID_CODEC_DELAY /*22186*/:
            case ID_SEEK_PRE_ROLL /*22203*/:
            case ID_DEFAULT_DURATION /*2352003*/:
            case ID_TIMECODE_SCALE /*2807729*/:
                return 2;
            case ID_CODEC_ID /*134*/:
            case ID_DOC_TYPE /*17026*/:
            case ID_LANGUAGE /*2274716*/:
                return 3;
            case ID_BLOCK_GROUP /*160*/:
            case ID_TRACK_ENTRY /*174*/:
            case ID_CUE_TRACK_POSITIONS /*183*/:
            case ID_CUE_POINT /*187*/:
            case 224:
            case ID_AUDIO /*225*/:
            case ID_CONTENT_ENCRYPTION_AES_SETTINGS /*18407*/:
            case ID_SEEK /*19899*/:
            case ID_CONTENT_COMPRESSION /*20532*/:
            case ID_CONTENT_ENCRYPTION /*20533*/:
            case ID_CONTENT_ENCODING /*25152*/:
            case ID_CONTENT_ENCODINGS /*28032*/:
            case ID_SEEK_HEAD /*290298740*/:
            case 357149030:
            case ID_TRACKS /*374648427*/:
            case ID_SEGMENT /*408125543*/:
            case ID_EBML /*440786851*/:
            case ID_CUES /*475249515*/:
            case ID_CLUSTER /*524531317*/:
                return 1;
            case ID_BLOCK /*161*/:
            case ID_SIMPLE_BLOCK /*163*/:
            case ID_CONTENT_COMPRESSION_SETTINGS /*16981*/:
            case ID_CONTENT_ENCRYPTION_KEY_ID /*18402*/:
            case ID_SEEK_ID /*21419*/:
            case ID_CODEC_PRIVATE /*25506*/:
                return 4;
            case ID_SAMPLING_FREQUENCY /*181*/:
            case ID_DURATION /*17545*/:
                return 5;
            default:
                return 0;
        }
    }

    final boolean isLevel1Element(int i) {
        return i == 357149030 || i == ID_CLUSTER || i == ID_CUES || i == ID_TRACKS;
    }

    final void startMasterElement(int i, long j, long j2) throws ParserException {
        switch (i) {
            case ID_BLOCK_GROUP /*160*/:
                this.sampleSeenReferenceBlock = false;
                return;
            case ID_TRACK_ENTRY /*174*/:
                this.currentTrack = new Track();
                return;
            case ID_CUE_POINT /*187*/:
                this.seenClusterPositionForCurrentCuePoint = false;
                return;
            case ID_SEEK /*19899*/:
                this.seekEntryId = -1;
                this.seekEntryPosition = -1;
                return;
            case ID_CONTENT_ENCRYPTION /*20533*/:
                this.currentTrack.hasContentEncryption = true;
                return;
            case ID_SEGMENT /*408125543*/:
                if (this.segmentContentPosition == -1 || this.segmentContentPosition == j) {
                    this.segmentContentPosition = j;
                    this.segmentContentSize = j2;
                    return;
                }
                throw new ParserException("Multiple Segment elements not supported");
            case ID_CUES /*475249515*/:
                this.cueTimesUs = new LongArray();
                this.cueClusterPositions = new LongArray();
                return;
            case ID_CLUSTER /*524531317*/:
                if (!this.sentSeekMap) {
                    if (this.cuesContentPosition != -1) {
                        this.seekForCues = true;
                        return;
                    }
                    this.extractorOutput.seekMap(SeekMap.UNSEEKABLE);
                    this.sentSeekMap = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    final void endMasterElement(int i) throws ParserException {
        switch (i) {
            case ID_BLOCK_GROUP /*160*/:
                if (this.blockState == 2) {
                    if (!this.sampleSeenReferenceBlock) {
                        this.blockFlags |= 1;
                    }
                    commitSampleToOutput((Track) this.tracks.get(this.blockTrackNumber), this.blockTimeUs);
                    this.blockState = 0;
                    return;
                }
                return;
            case ID_TRACK_ENTRY /*174*/:
                if (this.tracks.get(this.currentTrack.number) == null && isCodecSupported(this.currentTrack.codecId)) {
                    this.currentTrack.initializeOutput(this.extractorOutput, this.currentTrack.number, this.durationUs);
                    this.tracks.put(this.currentTrack.number, this.currentTrack);
                }
                this.currentTrack = null;
                return;
            case ID_SEEK /*19899*/:
                if (this.seekEntryId == -1 || this.seekEntryPosition == -1) {
                    throw new ParserException("Mandatory element SeekID or SeekPosition not found");
                } else if (this.seekEntryId == ID_CUES) {
                    this.cuesContentPosition = this.seekEntryPosition;
                    return;
                } else {
                    return;
                }
            case ID_CONTENT_ENCODING /*25152*/:
                if (!this.currentTrack.hasContentEncryption) {
                    return;
                }
                if (this.currentTrack.encryptionKeyId == null) {
                    throw new ParserException("Encrypted Track found but ContentEncKeyID was not found");
                } else if (!this.sentDrmInitData) {
                    this.extractorOutput.drmInitData(new Universal(new SchemeInitData(MimeTypes.VIDEO_WEBM, this.currentTrack.encryptionKeyId)));
                    this.sentDrmInitData = true;
                    return;
                } else {
                    return;
                }
            case ID_CONTENT_ENCODINGS /*28032*/:
                if (this.currentTrack.hasContentEncryption && this.currentTrack.sampleStrippedBytes != null) {
                    throw new ParserException("Combining encryption and compression is not supported");
                }
                return;
            case 357149030:
                if (this.timecodeScale == -1) {
                    this.timecodeScale = C1893C.MICROS_PER_SECOND;
                }
                if (this.durationTimecode != -1) {
                    this.durationUs = scaleTimecodeToUs(this.durationTimecode);
                    return;
                }
                return;
            case ID_TRACKS /*374648427*/:
                if (this.tracks.size() == 0) {
                    throw new ParserException("No valid tracks were found");
                }
                this.extractorOutput.endTracks();
                return;
            case ID_CUES /*475249515*/:
                if (!this.sentSeekMap) {
                    this.extractorOutput.seekMap(buildSeekMap());
                    this.sentSeekMap = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    final void integerElement(int i, long j) throws ParserException {
        switch (i) {
            case ID_TRACK_TYPE /*131*/:
                this.currentTrack.type = (int) j;
                return;
            case ID_BLOCK_DURATION /*155*/:
                this.blockDurationUs = scaleTimecodeToUs(j);
                return;
            case ID_CHANNELS /*159*/:
                this.currentTrack.channelCount = (int) j;
                return;
            case ID_PIXEL_WIDTH /*176*/:
                this.currentTrack.width = (int) j;
                return;
            case ID_CUE_TIME /*179*/:
                this.cueTimesUs.add(scaleTimecodeToUs(j));
                return;
            case ID_PIXEL_HEIGHT /*186*/:
                this.currentTrack.height = (int) j;
                return;
            case ID_TRACK_NUMBER /*215*/:
                this.currentTrack.number = (int) j;
                return;
            case ID_TIME_CODE /*231*/:
                this.clusterTimecodeUs = scaleTimecodeToUs(j);
                return;
            case ID_CUE_CLUSTER_POSITION /*241*/:
                if (!this.seenClusterPositionForCurrentCuePoint) {
                    this.cueClusterPositions.add(j);
                    this.seenClusterPositionForCurrentCuePoint = true;
                    return;
                }
                return;
            case ID_REFERENCE_BLOCK /*251*/:
                this.sampleSeenReferenceBlock = true;
                return;
            case ID_CONTENT_COMPRESSION_ALGORITHM /*16980*/:
                if (j != 3) {
                    throw new ParserException("ContentCompAlgo " + j + " not supported");
                }
                return;
            case ID_DOC_TYPE_READ_VERSION /*17029*/:
                if (j < 1 || j > 2) {
                    throw new ParserException("DocTypeReadVersion " + j + " not supported");
                }
                return;
            case ID_EBML_READ_VERSION /*17143*/:
                if (j != 1) {
                    throw new ParserException("EBMLReadVersion " + j + " not supported");
                }
                return;
            case ID_CONTENT_ENCRYPTION_ALGORITHM /*18401*/:
                if (j != 5) {
                    throw new ParserException("ContentEncAlgo " + j + " not supported");
                }
                return;
            case ID_CONTENT_ENCRYPTION_AES_SETTINGS_CIPHER_MODE /*18408*/:
                if (j != 1) {
                    throw new ParserException("AESSettingsCipherMode " + j + " not supported");
                }
                return;
            case ID_CONTENT_ENCODING_ORDER /*20529*/:
                if (j != 0) {
                    throw new ParserException("ContentEncodingOrder " + j + " not supported");
                }
                return;
            case ID_CONTENT_ENCODING_SCOPE /*20530*/:
                if (j != 1) {
                    throw new ParserException("ContentEncodingScope " + j + " not supported");
                }
                return;
            case ID_SEEK_POSITION /*21420*/:
                this.seekEntryPosition = this.segmentContentPosition + j;
                return;
            case ID_CODEC_DELAY /*22186*/:
                this.currentTrack.codecDelayNs = j;
                return;
            case ID_SEEK_PRE_ROLL /*22203*/:
                this.currentTrack.seekPreRollNs = j;
                return;
            case ID_DEFAULT_DURATION /*2352003*/:
                this.currentTrack.defaultSampleDurationNs = (int) j;
                return;
            case ID_TIMECODE_SCALE /*2807729*/:
                this.timecodeScale = j;
                return;
            default:
                return;
        }
    }

    final void floatElement(int i, double d) {
        switch (i) {
            case ID_SAMPLING_FREQUENCY /*181*/:
                this.currentTrack.sampleRate = (int) d;
                return;
            case ID_DURATION /*17545*/:
                this.durationTimecode = (long) d;
                return;
            default:
                return;
        }
    }

    final void stringElement(int i, String str) throws ParserException {
        switch (i) {
            case ID_CODEC_ID /*134*/:
                this.currentTrack.codecId = str;
                return;
            case ID_DOC_TYPE /*17026*/:
                if (!DOC_TYPE_WEBM.equals(str) && !DOC_TYPE_MATROSKA.equals(str)) {
                    throw new ParserException("DocType " + str + " not supported");
                }
                return;
            case ID_LANGUAGE /*2274716*/:
                this.currentTrack.language = str;
                return;
            default:
                return;
        }
    }

    final void binaryElement(int i, int i2, ExtractorInput extractorInput) throws IOException, InterruptedException {
        switch (i) {
            case ID_BLOCK /*161*/:
            case ID_SIMPLE_BLOCK /*163*/:
                if (this.blockState == 0) {
                    this.blockTrackNumber = (int) this.varintReader.readUnsignedVarint(extractorInput, false, true, 8);
                    this.blockTrackNumberLength = this.varintReader.getLastLength();
                    this.blockDurationUs = -1;
                    this.blockState = 1;
                    this.scratch.reset();
                }
                Track track = (Track) this.tracks.get(this.blockTrackNumber);
                if (track == null) {
                    extractorInput.skipFully(i2 - this.blockTrackNumberLength);
                    this.blockState = 0;
                    return;
                }
                if (this.blockState == 1) {
                    int i3;
                    readScratch(extractorInput, 3);
                    int i4 = (this.scratch.data[2] & 6) >> 1;
                    if (i4 == 0) {
                        this.blockLacingSampleCount = 1;
                        this.blockLacingSampleSizes = ensureArrayCapacity(this.blockLacingSampleSizes, 1);
                        this.blockLacingSampleSizes[0] = (i2 - this.blockTrackNumberLength) - 3;
                    } else if (i != ID_SIMPLE_BLOCK) {
                        throw new ParserException("Lacing only supported in SimpleBlocks.");
                    } else {
                        readScratch(extractorInput, 4);
                        this.blockLacingSampleCount = (this.scratch.data[3] & 255) + 1;
                        this.blockLacingSampleSizes = ensureArrayCapacity(this.blockLacingSampleSizes, this.blockLacingSampleCount);
                        if (i4 == 2) {
                            Arrays.fill(this.blockLacingSampleSizes, 0, this.blockLacingSampleCount, ((i2 - this.blockTrackNumberLength) - 4) / this.blockLacingSampleCount);
                        } else if (i4 == 1) {
                            i3 = 0;
                            r5 = 4;
                            for (i4 = 0; i4 < this.blockLacingSampleCount - 1; i4++) {
                                this.blockLacingSampleSizes[i4] = 0;
                                do {
                                    r5++;
                                    readScratch(extractorInput, r5);
                                    r6 = this.scratch.data[r5 - 1] & 255;
                                    r7 = this.blockLacingSampleSizes;
                                    r7[i4] = r7[i4] + r6;
                                } while (r6 == 255);
                                i3 += this.blockLacingSampleSizes[i4];
                            }
                            this.blockLacingSampleSizes[this.blockLacingSampleCount - 1] = ((i2 - this.blockTrackNumberLength) - r5) - i3;
                        } else if (i4 == 3) {
                            i3 = 0;
                            r5 = 4;
                            i4 = 0;
                            while (i4 < this.blockLacingSampleCount - 1) {
                                this.blockLacingSampleSizes[i4] = 0;
                                r5++;
                                readScratch(extractorInput, r5);
                                if (this.scratch.data[r5 - 1] == (byte) 0) {
                                    throw new ParserException("No valid varint length mask found");
                                }
                                long j = 0;
                                int i5 = 0;
                                while (i5 < 8) {
                                    int i6 = 1 << (7 - i5);
                                    if ((this.scratch.data[r5 - 1] & i6) != 0) {
                                        int i7 = r5 - 1;
                                        r5 += i5;
                                        readScratch(extractorInput, r5);
                                        j = (long) ((this.scratch.data[i7] & 255) & (i6 ^ -1));
                                        for (i6 = i7 + 1; i6 < r5; i6++) {
                                            j = ((long) (this.scratch.data[i6] & 255)) | (j << 8);
                                        }
                                        if (i4 > 0) {
                                            j -= (1 << ((i5 * 7) + 6)) - 1;
                                        }
                                        if (j >= -2147483648L || j > 2147483647L) {
                                            throw new ParserException("EBML lacing sample size out of range.");
                                        }
                                        r6 = (int) j;
                                        r7 = this.blockLacingSampleSizes;
                                        if (i4 != 0) {
                                            r6 += this.blockLacingSampleSizes[i4 - 1];
                                        }
                                        r7[i4] = r6;
                                        i3 += this.blockLacingSampleSizes[i4];
                                        i4++;
                                    } else {
                                        i5++;
                                    }
                                }
                                if (j >= -2147483648L) {
                                    break;
                                }
                                throw new ParserException("EBML lacing sample size out of range.");
                            }
                            this.blockLacingSampleSizes[this.blockLacingSampleCount - 1] = ((i2 - this.blockTrackNumberLength) - r5) - i3;
                        } else {
                            throw new ParserException("Unexpected lacing value: " + i4);
                        }
                    }
                    this.blockTimeUs = this.clusterTimecodeUs + scaleTimecodeToUs((long) ((this.scratch.data[0] << 8) | (this.scratch.data[1] & 255)));
                    Object obj = (this.scratch.data[2] & 8) == 8 ? 1 : null;
                    Object obj2 = (track.type == 2 || (i == ID_SIMPLE_BLOCK && (this.scratch.data[2] & 128) == 128)) ? 1 : null;
                    i3 = obj2 != null ? 1 : 0;
                    if (obj != null) {
                        i4 = C1893C.SAMPLE_FLAG_DECODE_ONLY;
                    } else {
                        i4 = 0;
                    }
                    this.blockFlags = i4 | i3;
                    this.blockState = 2;
                    this.blockLacingSampleIndex = 0;
                }
                if (i == ID_SIMPLE_BLOCK) {
                    while (this.blockLacingSampleIndex < this.blockLacingSampleCount) {
                        writeSampleData(extractorInput, track, this.blockLacingSampleSizes[this.blockLacingSampleIndex]);
                        commitSampleToOutput(track, this.blockTimeUs + ((long) ((this.blockLacingSampleIndex * track.defaultSampleDurationNs) / 1000)));
                        this.blockLacingSampleIndex++;
                    }
                    this.blockState = 0;
                    return;
                }
                writeSampleData(extractorInput, track, this.blockLacingSampleSizes[0]);
                return;
            case ID_CONTENT_COMPRESSION_SETTINGS /*16981*/:
                this.currentTrack.sampleStrippedBytes = new byte[i2];
                extractorInput.readFully(this.currentTrack.sampleStrippedBytes, 0, i2);
                return;
            case ID_CONTENT_ENCRYPTION_KEY_ID /*18402*/:
                this.currentTrack.encryptionKeyId = new byte[i2];
                extractorInput.readFully(this.currentTrack.encryptionKeyId, 0, i2);
                return;
            case ID_SEEK_ID /*21419*/:
                Arrays.fill(this.seekEntryIdBytes.data, (byte) 0);
                extractorInput.readFully(this.seekEntryIdBytes.data, 4 - i2, i2);
                this.seekEntryIdBytes.setPosition(0);
                this.seekEntryId = (int) this.seekEntryIdBytes.readUnsignedInt();
                return;
            case ID_CODEC_PRIVATE /*25506*/:
                this.currentTrack.codecPrivate = new byte[i2];
                extractorInput.readFully(this.currentTrack.codecPrivate, 0, i2);
                return;
            default:
                throw new ParserException("Unexpected id: " + i);
        }
    }

    private void commitSampleToOutput(Track track, long j) {
        if (CODEC_ID_SUBRIP.equals(track.codecId)) {
            writeSubripSample(track);
        }
        track.output.sampleMetadata(j, this.blockFlags, this.sampleBytesWritten, 0, track.encryptionKeyId);
        this.sampleRead = true;
        resetSample();
    }

    private void resetSample() {
        this.sampleBytesRead = 0;
        this.sampleBytesWritten = 0;
        this.sampleCurrentNalBytesRemaining = 0;
        this.sampleEncodingHandled = false;
        this.sampleStrippedBytes.reset();
    }

    private void readScratch(ExtractorInput extractorInput, int i) throws IOException, InterruptedException {
        if (this.scratch.limit() < i) {
            if (this.scratch.capacity() < i) {
                this.scratch.reset(Arrays.copyOf(this.scratch.data, Math.max(this.scratch.data.length * 2, i)), this.scratch.limit());
            }
            extractorInput.readFully(this.scratch.data, this.scratch.limit(), i - this.scratch.limit());
            this.scratch.setLimit(i);
        }
    }

    private void writeSampleData(ExtractorInput extractorInput, Track track, int i) throws IOException, InterruptedException {
        if (CODEC_ID_SUBRIP.equals(track.codecId)) {
            int length = SUBRIP_PREFIX.length + i;
            if (this.subripSample.capacity() < length) {
                this.subripSample.data = Arrays.copyOf(SUBRIP_PREFIX, length + i);
            }
            extractorInput.readFully(this.subripSample.data, SUBRIP_PREFIX.length, i);
            this.subripSample.setPosition(0);
            this.subripSample.setLimit(length);
            return;
        }
        TrackOutput trackOutput = track.output;
        if (!this.sampleEncodingHandled) {
            if (track.hasContentEncryption) {
                this.blockFlags &= -3;
                extractorInput.readFully(this.scratch.data, 0, 1);
                this.sampleBytesRead++;
                if ((this.scratch.data[0] & 128) == 128) {
                    throw new ParserException("Extension bit is set in signal byte");
                } else if ((this.scratch.data[0] & 1) == 1) {
                    this.scratch.data[0] = (byte) 8;
                    this.scratch.setPosition(0);
                    trackOutput.sampleData(this.scratch, 1);
                    this.sampleBytesWritten++;
                    this.blockFlags |= 2;
                }
            } else if (track.sampleStrippedBytes != null) {
                this.sampleStrippedBytes.reset(track.sampleStrippedBytes, track.sampleStrippedBytes.length);
            }
            this.sampleEncodingHandled = true;
        }
        int limit = this.sampleStrippedBytes.limit() + i;
        if (CODEC_ID_H264.equals(track.codecId) || CODEC_ID_H265.equals(track.codecId)) {
            byte[] bArr = this.nalLength.data;
            bArr[0] = (byte) 0;
            bArr[1] = (byte) 0;
            bArr[2] = (byte) 0;
            int i2 = track.nalUnitLengthFieldLength;
            int i3 = 4 - track.nalUnitLengthFieldLength;
            while (this.sampleBytesRead < limit) {
                if (this.sampleCurrentNalBytesRemaining == 0) {
                    readToTarget(extractorInput, bArr, i3, i2);
                    this.nalLength.setPosition(0);
                    this.sampleCurrentNalBytesRemaining = this.nalLength.readUnsignedIntToInt();
                    this.nalStartCode.setPosition(0);
                    trackOutput.sampleData(this.nalStartCode, 4);
                    this.sampleBytesWritten += 4;
                } else {
                    this.sampleCurrentNalBytesRemaining -= readToOutput(extractorInput, trackOutput, this.sampleCurrentNalBytesRemaining);
                }
            }
        } else {
            while (this.sampleBytesRead < limit) {
                readToOutput(extractorInput, trackOutput, limit - this.sampleBytesRead);
            }
        }
        if (CODEC_ID_VORBIS.equals(track.codecId)) {
            this.vorbisNumPageSamples.setPosition(0);
            trackOutput.sampleData(this.vorbisNumPageSamples, 4);
            this.sampleBytesWritten += 4;
        }
    }

    private void writeSubripSample(Track track) {
        setSubripSampleEndTimecode(this.subripSample.data, this.blockDurationUs);
        track.output.sampleData(this.subripSample, this.subripSample.limit());
        this.sampleBytesWritten += this.subripSample.limit();
    }

    private static void setSubripSampleEndTimecode(byte[] bArr, long j) {
        Object obj;
        if (j == -1) {
            obj = SUBRIP_TIMECODE_EMPTY;
        } else {
            long j2 = j - (((long) ((int) (j / 3600000000L))) * 3600000000L);
            j2 -= (long) (60000000 * ((int) (j2 / 60000000)));
            int i = (int) ((j2 - ((long) (1000000 * ((int) (j2 / C1893C.MICROS_PER_SECOND))))) / 1000);
            obj = String.format(Locale.US, "%02d:%02d:%02d,%03d", new Object[]{Integer.valueOf((int) (j / 3600000000L)), Integer.valueOf(r1), Integer.valueOf(r4), Integer.valueOf(i)}).getBytes();
        }
        System.arraycopy(obj, 0, bArr, 19, 12);
    }

    private void readToTarget(ExtractorInput extractorInput, byte[] bArr, int i, int i2) throws IOException, InterruptedException {
        int min = Math.min(i2, this.sampleStrippedBytes.bytesLeft());
        extractorInput.readFully(bArr, i + min, i2 - min);
        if (min > 0) {
            this.sampleStrippedBytes.readBytes(bArr, i, min);
        }
        this.sampleBytesRead += i2;
    }

    private int readToOutput(ExtractorInput extractorInput, TrackOutput trackOutput, int i) throws IOException, InterruptedException {
        int bytesLeft = this.sampleStrippedBytes.bytesLeft();
        if (bytesLeft > 0) {
            bytesLeft = Math.min(i, bytesLeft);
            trackOutput.sampleData(this.sampleStrippedBytes, bytesLeft);
        } else {
            bytesLeft = trackOutput.sampleData(extractorInput, i, false);
        }
        this.sampleBytesRead += bytesLeft;
        this.sampleBytesWritten += bytesLeft;
        return bytesLeft;
    }

    private SeekMap buildSeekMap() {
        int i = 0;
        if (this.segmentContentPosition == -1 || this.durationUs == -1 || this.cueTimesUs == null || this.cueTimesUs.size() == 0 || this.cueClusterPositions == null || this.cueClusterPositions.size() != this.cueTimesUs.size()) {
            this.cueTimesUs = null;
            this.cueClusterPositions = null;
            return SeekMap.UNSEEKABLE;
        }
        int size = this.cueTimesUs.size();
        int[] iArr = new int[size];
        long[] jArr = new long[size];
        long[] jArr2 = new long[size];
        long[] jArr3 = new long[size];
        for (int i2 = 0; i2 < size; i2++) {
            jArr3[i2] = this.cueTimesUs.get(i2);
            jArr[i2] = this.segmentContentPosition + this.cueClusterPositions.get(i2);
        }
        while (i < size - 1) {
            iArr[i] = (int) (jArr[i + 1] - jArr[i]);
            jArr2[i] = jArr3[i + 1] - jArr3[i];
            i++;
        }
        iArr[size - 1] = (int) ((this.segmentContentPosition + this.segmentContentSize) - jArr[size - 1]);
        jArr2[size - 1] = this.durationUs - jArr3[size - 1];
        this.cueTimesUs = null;
        this.cueClusterPositions = null;
        return new ChunkIndex(iArr, jArr, jArr2, jArr3);
    }

    private boolean maybeSeekForCues(PositionHolder positionHolder, long j) {
        if (this.seekForCues) {
            this.seekPositionAfterBuildingCues = j;
            positionHolder.position = this.cuesContentPosition;
            this.seekForCues = false;
            return true;
        } else if (!this.sentSeekMap || this.seekPositionAfterBuildingCues == -1) {
            return false;
        } else {
            positionHolder.position = this.seekPositionAfterBuildingCues;
            this.seekPositionAfterBuildingCues = -1;
            return true;
        }
    }

    private long scaleTimecodeToUs(long j) throws ParserException {
        if (this.timecodeScale == -1) {
            throw new ParserException("Can't scale timecode prior to timecodeScale being set.");
        }
        return Util.scaleLargeTimestamp(j, this.timecodeScale, 1000);
    }

    private static boolean isCodecSupported(String str) {
        return CODEC_ID_VP8.equals(str) || CODEC_ID_VP9.equals(str) || CODEC_ID_MPEG2.equals(str) || CODEC_ID_MPEG4_SP.equals(str) || CODEC_ID_MPEG4_ASP.equals(str) || CODEC_ID_MPEG4_AP.equals(str) || CODEC_ID_H264.equals(str) || CODEC_ID_H265.equals(str) || CODEC_ID_OPUS.equals(str) || CODEC_ID_VORBIS.equals(str) || CODEC_ID_AAC.equals(str) || CODEC_ID_MP3.equals(str) || CODEC_ID_AC3.equals(str) || CODEC_ID_E_AC3.equals(str) || CODEC_ID_TRUEHD.equals(str) || CODEC_ID_DTS.equals(str) || CODEC_ID_DTS_EXPRESS.equals(str) || CODEC_ID_DTS_LOSSLESS.equals(str) || CODEC_ID_SUBRIP.equals(str);
    }

    private static int[] ensureArrayCapacity(int[] iArr, int i) {
        if (iArr == null) {
            return new int[i];
        }
        return iArr.length < i ? new int[Math.max(iArr.length * 2, i)] : iArr;
    }
}
