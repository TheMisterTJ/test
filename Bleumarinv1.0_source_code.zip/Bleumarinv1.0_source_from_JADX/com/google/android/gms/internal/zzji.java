package com.google.android.gms.internal;

public interface zzji<T> {

    public interface zzc<T> {
        void zze(T t);
    }

    public interface zza {
        void run();
    }

    public static class zzb implements zza {
        public void run() {
        }
    }

    void zza(zzc<T> com_google_android_gms_internal_zzji_zzc_T, zza com_google_android_gms_internal_zzji_zza);

    void zzh(T t);
}
