package com.google.android.gms.internal;

public class zzr extends Exception {
    private long zzC;
    public final zzi zzaj;

    public zzr() {
        this.zzaj = null;
    }

    public zzr(zzi com_google_android_gms_internal_zzi) {
        this.zzaj = com_google_android_gms_internal_zzi;
    }

    public zzr(Throwable th) {
        super(th);
        this.zzaj = null;
    }

    void zza(long j) {
        this.zzC = j;
    }
}
