package com.google.android.exoplayer.hls;

import java.util.Collections;
import java.util.List;

public final class HlsMasterPlaylist extends HlsPlaylist {
    public final List<Variant> subtitles;
    public final List<Variant> variants;

    public HlsMasterPlaylist(String str, List<Variant> list, List<Variant> list2) {
        super(str, 0);
        this.variants = Collections.unmodifiableList(list);
        this.subtitles = Collections.unmodifiableList(list2);
    }
}
