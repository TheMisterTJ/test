package com.google.android.exoplayer.upstream;

public interface UriDataSource extends DataSource {
    String getUri();
}
