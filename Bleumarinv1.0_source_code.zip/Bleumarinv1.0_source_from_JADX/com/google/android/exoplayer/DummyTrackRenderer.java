package com.google.android.exoplayer;

public final class DummyTrackRenderer extends TrackRenderer {
    protected final boolean doPrepare(long j) throws ExoPlaybackException {
        return true;
    }

    protected final int getTrackCount() {
        return 0;
    }

    protected final MediaFormat getFormat(int i) {
        throw new IllegalStateException();
    }

    protected final boolean isEnded() {
        throw new IllegalStateException();
    }

    protected final boolean isReady() {
        throw new IllegalStateException();
    }

    protected final void seekTo(long j) {
        throw new IllegalStateException();
    }

    protected final void doSomeWork(long j, long j2) {
        throw new IllegalStateException();
    }

    protected final void maybeThrowError() {
        throw new IllegalStateException();
    }

    protected final long getDurationUs() {
        throw new IllegalStateException();
    }

    protected final long getBufferedPositionUs() {
        throw new IllegalStateException();
    }
}
