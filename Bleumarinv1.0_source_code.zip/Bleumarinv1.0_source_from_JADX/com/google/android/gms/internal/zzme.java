package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzmk.zza;

public class zzme extends zza {
    public void zzcb(int i) throws RemoteException {
    }
}
