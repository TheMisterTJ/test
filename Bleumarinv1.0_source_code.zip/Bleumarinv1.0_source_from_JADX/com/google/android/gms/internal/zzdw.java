package com.google.android.gms.internal;

import android.os.Handler;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzk;
import com.google.android.gms.ads.internal.zzr;
import java.util.LinkedList;
import java.util.List;

@zzhb
class zzdw {
    private final List<zza> zzpH = new LinkedList();

    interface zza {
        void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException;
    }

    class C21241 extends com.google.android.gms.ads.internal.client.zzq.zza {
        final /* synthetic */ zzdw zzAc;

        class C21191 implements zza {
            final /* synthetic */ C21241 zzAd;

            C21191(C21241 c21241) {
                this.zzAd = c21241;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzpK != null) {
                    com_google_android_gms_internal_zzdx.zzpK.onAdClosed();
                }
                zzr.zzbN().zzee();
            }
        }

        class C21213 implements zza {
            final /* synthetic */ C21241 zzAd;

            C21213(C21241 c21241) {
                this.zzAd = c21241;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzpK != null) {
                    com_google_android_gms_internal_zzdx.zzpK.onAdLeftApplication();
                }
            }
        }

        class C21224 implements zza {
            final /* synthetic */ C21241 zzAd;

            C21224(C21241 c21241) {
                this.zzAd = c21241;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzpK != null) {
                    com_google_android_gms_internal_zzdx.zzpK.onAdLoaded();
                }
            }
        }

        class C21235 implements zza {
            final /* synthetic */ C21241 zzAd;

            C21235(C21241 c21241) {
                this.zzAd = c21241;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzpK != null) {
                    com_google_android_gms_internal_zzdx.zzpK.onAdOpened();
                }
            }
        }

        C21241(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void onAdClosed() throws RemoteException {
            this.zzAc.zzpH.add(new C21191(this));
        }

        public void onAdFailedToLoad(final int i) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21241 zzAd;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzpK != null) {
                        com_google_android_gms_internal_zzdx.zzpK.onAdFailedToLoad(i);
                    }
                }
            });
            zzin.m6492v("Pooled interstitial failed to load.");
        }

        public void onAdLeftApplication() throws RemoteException {
            this.zzAc.zzpH.add(new C21213(this));
        }

        public void onAdLoaded() throws RemoteException {
            this.zzAc.zzpH.add(new C21224(this));
            zzin.m6492v("Pooled interstitial loaded.");
        }

        public void onAdOpened() throws RemoteException {
            this.zzAc.zzpH.add(new C21235(this));
        }
    }

    class C21262 extends com.google.android.gms.ads.internal.client.zzw.zza {
        final /* synthetic */ zzdw zzAc;

        C21262(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void onAppEvent(final String str, final String str2) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21262 zzAg;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzAq != null) {
                        com_google_android_gms_internal_zzdx.zzAq.onAppEvent(str, str2);
                    }
                }
            });
        }
    }

    class C21283 extends com.google.android.gms.internal.zzgd.zza {
        final /* synthetic */ zzdw zzAc;

        C21283(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void zza(final zzgc com_google_android_gms_internal_zzgc) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21283 zzAi;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzAr != null) {
                        com_google_android_gms_internal_zzdx.zzAr.zza(com_google_android_gms_internal_zzgc);
                    }
                }
            });
        }
    }

    class C21304 extends com.google.android.gms.internal.zzcf.zza {
        final /* synthetic */ zzdw zzAc;

        C21304(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void zza(final zzce com_google_android_gms_internal_zzce) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21304 zzAk;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzAs != null) {
                        com_google_android_gms_internal_zzdx.zzAs.zza(com_google_android_gms_internal_zzce);
                    }
                }
            });
        }
    }

    class C21325 extends com.google.android.gms.ads.internal.client.zzp.zza {
        final /* synthetic */ zzdw zzAc;

        class C21311 implements zza {
            final /* synthetic */ C21325 zzAl;

            C21311(C21325 c21325) {
                this.zzAl = c21325;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAt != null) {
                    com_google_android_gms_internal_zzdx.zzAt.onAdClicked();
                }
            }
        }

        C21325(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void onAdClicked() throws RemoteException {
            this.zzAc.zzpH.add(new C21311(this));
        }
    }

    class C21406 extends com.google.android.gms.ads.internal.reward.client.zzd.zza {
        final /* synthetic */ zzdw zzAc;

        class C21331 implements zza {
            final /* synthetic */ C21406 zzAm;

            C21331(C21406 c21406) {
                this.zzAm = c21406;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAu != null) {
                    com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoAdLoaded();
                }
            }
        }

        class C21342 implements zza {
            final /* synthetic */ C21406 zzAm;

            C21342(C21406 c21406) {
                this.zzAm = c21406;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAu != null) {
                    com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoAdOpened();
                }
            }
        }

        class C21353 implements zza {
            final /* synthetic */ C21406 zzAm;

            C21353(C21406 c21406) {
                this.zzAm = c21406;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAu != null) {
                    com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoStarted();
                }
            }
        }

        class C21364 implements zza {
            final /* synthetic */ C21406 zzAm;

            C21364(C21406 c21406) {
                this.zzAm = c21406;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAu != null) {
                    com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoAdClosed();
                }
            }
        }

        class C21386 implements zza {
            final /* synthetic */ C21406 zzAm;

            C21386(C21406 c21406) {
                this.zzAm = c21406;
            }

            public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                if (com_google_android_gms_internal_zzdx.zzAu != null) {
                    com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoAdLeftApplication();
                }
            }
        }

        C21406(zzdw com_google_android_gms_internal_zzdw) {
            this.zzAc = com_google_android_gms_internal_zzdw;
        }

        public void onRewardedVideoAdClosed() throws RemoteException {
            this.zzAc.zzpH.add(new C21364(this));
        }

        public void onRewardedVideoAdFailedToLoad(final int i) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21406 zzAm;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzAu != null) {
                        com_google_android_gms_internal_zzdx.zzAu.onRewardedVideoAdFailedToLoad(i);
                    }
                }
            });
        }

        public void onRewardedVideoAdLeftApplication() throws RemoteException {
            this.zzAc.zzpH.add(new C21386(this));
        }

        public void onRewardedVideoAdLoaded() throws RemoteException {
            this.zzAc.zzpH.add(new C21331(this));
        }

        public void onRewardedVideoAdOpened() throws RemoteException {
            this.zzAc.zzpH.add(new C21342(this));
        }

        public void onRewardedVideoStarted() throws RemoteException {
            this.zzAc.zzpH.add(new C21353(this));
        }

        public void zza(final com.google.android.gms.ads.internal.reward.client.zza com_google_android_gms_ads_internal_reward_client_zza) throws RemoteException {
            this.zzAc.zzpH.add(new zza(this) {
                final /* synthetic */ C21406 zzAm;

                public void zzb(zzdx com_google_android_gms_internal_zzdx) throws RemoteException {
                    if (com_google_android_gms_internal_zzdx.zzAu != null) {
                        com_google_android_gms_internal_zzdx.zzAu.zza(com_google_android_gms_ads_internal_reward_client_zza);
                    }
                }
            });
        }
    }

    zzdw() {
    }

    void zza(final zzdx com_google_android_gms_internal_zzdx) {
        Handler handler = zzir.zzMc;
        for (final zza com_google_android_gms_internal_zzdw_zza : this.zzpH) {
            handler.post(new Runnable(this) {
                final /* synthetic */ zzdw zzAc;

                public void run() {
                    try {
                        com_google_android_gms_internal_zzdw_zza.zzb(com_google_android_gms_internal_zzdx);
                    } catch (Throwable e) {
                        zzb.zzd("Could not propagate interstitial ad event.", e);
                    }
                }
            });
        }
    }

    void zzc(zzk com_google_android_gms_ads_internal_zzk) {
        com_google_android_gms_ads_internal_zzk.zza(new C21241(this));
        com_google_android_gms_ads_internal_zzk.zza(new C21262(this));
        com_google_android_gms_ads_internal_zzk.zza(new C21283(this));
        com_google_android_gms_ads_internal_zzk.zza(new C21304(this));
        com_google_android_gms_ads_internal_zzk.zza(new C21325(this));
        com_google_android_gms_ads_internal_zzk.zza(new C21406(this));
    }
}
