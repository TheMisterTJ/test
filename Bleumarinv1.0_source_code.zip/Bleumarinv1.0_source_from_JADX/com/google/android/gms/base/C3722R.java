package com.google.android.gms.base;

import com.bleumarin.agency.R;

public final class C3722R {

    public static final class attr {
        public static final int adSize = 2130772030;
        public static final int adSizes = 2130772031;
        public static final int adUnitId = 2130772032;
        public static final int buttonSize = 2130772253;
        public static final int circleCrop = 2130772196;
        public static final int colorScheme = 2130772254;
        public static final int imageAspectRatio = 2130772195;
        public static final int imageAspectRatioAdjust = 2130772194;
        public static final int scopeUris = 2130772255;
    }

    public static final class color {
        public static final int common_action_bar_splitter = 2131624014;
        public static final int common_google_signin_btn_text_dark = 2131624520;
        public static final int common_google_signin_btn_text_dark_default = 2131624015;
        public static final int common_google_signin_btn_text_dark_disabled = 2131624016;
        public static final int common_google_signin_btn_text_dark_focused = 2131624017;
        public static final int common_google_signin_btn_text_dark_pressed = 2131624018;
        public static final int common_google_signin_btn_text_light = 2131624521;
        public static final int common_google_signin_btn_text_light_default = 2131624019;
        public static final int common_google_signin_btn_text_light_disabled = 2131624020;
        public static final int common_google_signin_btn_text_light_focused = 2131624021;
        public static final int common_google_signin_btn_text_light_pressed = 2131624022;
        public static final int common_plus_signin_btn_text_dark = 2131624522;
        public static final int common_plus_signin_btn_text_dark_default = 2131624023;
        public static final int common_plus_signin_btn_text_dark_disabled = 2131624024;
        public static final int common_plus_signin_btn_text_dark_focused = 2131624025;
        public static final int common_plus_signin_btn_text_dark_pressed = 2131624026;
        public static final int common_plus_signin_btn_text_light = 2131624523;
        public static final int common_plus_signin_btn_text_light_default = 2131624027;
        public static final int common_plus_signin_btn_text_light_disabled = 2131624028;
        public static final int common_plus_signin_btn_text_light_focused = 2131624029;
        public static final int common_plus_signin_btn_text_light_pressed = 2131624030;
    }

    public static final class dimen {
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2130837635;
        public static final int common_google_signin_btn_icon_dark = 2130837636;
        public static final int common_google_signin_btn_icon_dark_disabled = 2130837637;
        public static final int common_google_signin_btn_icon_dark_focused = 2130837638;
        public static final int common_google_signin_btn_icon_dark_normal = 2130837639;
        public static final int common_google_signin_btn_icon_dark_pressed = 2130837640;
        public static final int common_google_signin_btn_icon_light = 2130837641;
        public static final int common_google_signin_btn_icon_light_disabled = 2130837642;
        public static final int common_google_signin_btn_icon_light_focused = 2130837643;
        public static final int common_google_signin_btn_icon_light_normal = 2130837644;
        public static final int common_google_signin_btn_icon_light_pressed = 2130837645;
        public static final int common_google_signin_btn_text_dark = 2130837646;
        public static final int common_google_signin_btn_text_dark_disabled = 2130837647;
        public static final int common_google_signin_btn_text_dark_focused = 2130837648;
        public static final int common_google_signin_btn_text_dark_normal = 2130837649;
        public static final int common_google_signin_btn_text_dark_pressed = 2130837650;
        public static final int common_google_signin_btn_text_light = 2130837651;
        public static final int common_google_signin_btn_text_light_disabled = 2130837652;
        public static final int common_google_signin_btn_text_light_focused = 2130837653;
        public static final int common_google_signin_btn_text_light_normal = 2130837654;
        public static final int common_google_signin_btn_text_light_pressed = 2130837655;
        public static final int common_ic_googleplayservices = 2130837656;
        public static final int common_plus_signin_btn_icon_dark = 2130837657;
        public static final int common_plus_signin_btn_icon_dark_disabled = 2130837658;
        public static final int common_plus_signin_btn_icon_dark_focused = 2130837659;
        public static final int common_plus_signin_btn_icon_dark_normal = 2130837660;
        public static final int common_plus_signin_btn_icon_dark_pressed = 2130837661;
        public static final int common_plus_signin_btn_icon_light = 2130837662;
        public static final int common_plus_signin_btn_icon_light_disabled = 2130837663;
        public static final int common_plus_signin_btn_icon_light_focused = 2130837664;
        public static final int common_plus_signin_btn_icon_light_normal = 2130837665;
        public static final int common_plus_signin_btn_icon_light_pressed = 2130837666;
        public static final int common_plus_signin_btn_text_dark = 2130837667;
        public static final int common_plus_signin_btn_text_dark_disabled = 2130837668;
        public static final int common_plus_signin_btn_text_dark_focused = 2130837669;
        public static final int common_plus_signin_btn_text_dark_normal = 2130837670;
        public static final int common_plus_signin_btn_text_dark_pressed = 2130837671;
        public static final int common_plus_signin_btn_text_light = 2130837672;
        public static final int common_plus_signin_btn_text_light_disabled = 2130837673;
        public static final int common_plus_signin_btn_text_light_focused = 2130837674;
        public static final int common_plus_signin_btn_text_light_normal = 2130837675;
        public static final int common_plus_signin_btn_text_light_pressed = 2130837676;
        public static final int ic_plusone_medium_off_client = 2130837810;
        public static final int ic_plusone_small_off_client = 2130837811;
        public static final int ic_plusone_standard_off_client = 2130837812;
        public static final int ic_plusone_tall_off_client = 2130837813;
    }

    public static final class id {
        public static final int adjust_height = 2131689517;
        public static final int adjust_width = 2131689518;
        public static final int auto = 2131689527;
        public static final int dark = 2131689528;
        public static final int icon_only = 2131689524;
        public static final int light = 2131689529;
        public static final int none = 2131689498;
        public static final int normal = 2131689494;
        public static final int standard = 2131689525;
        public static final int wide = 2131689526;
        public static final int wrap_content = 2131689532;
    }

    public static final class integer {
        public static final int google_play_services_version = 2131492875;
    }

    public static final class layout {
    }

    public static final class raw {
        public static final int gtm_analytics = 2131099648;
    }

    public static final class string {
        public static final int accept = 2131165198;
        public static final int auth_google_play_services_client_facebook_display_name = 2131165220;
        public static final int auth_google_play_services_client_google_display_name = 2131165221;
        public static final int common_google_play_services_api_unavailable_text = 2131165286;
        public static final int common_google_play_services_enable_button = 2131165287;
        public static final int common_google_play_services_enable_text = 2131165288;
        public static final int common_google_play_services_enable_title = 2131165289;
        public static final int common_google_play_services_install_button = 2131165290;
        public static final int common_google_play_services_install_text_phone = 2131165291;
        public static final int common_google_play_services_install_text_tablet = 2131165292;
        public static final int common_google_play_services_install_title = 2131165293;
        public static final int common_google_play_services_invalid_account_text = 2131165294;
        public static final int common_google_play_services_invalid_account_title = 2131165295;
        public static final int common_google_play_services_network_error_text = 2131165296;
        public static final int common_google_play_services_network_error_title = 2131165297;
        public static final int common_google_play_services_notification_ticker = 2131165298;
        public static final int common_google_play_services_restricted_profile_text = 2131165299;
        public static final int common_google_play_services_restricted_profile_title = 2131165300;
        public static final int common_google_play_services_sign_in_failed_text = 2131165301;
        public static final int common_google_play_services_sign_in_failed_title = 2131165302;
        public static final int common_google_play_services_unknown_issue = 2131165303;
        public static final int common_google_play_services_unsupported_text = 2131165304;
        public static final int common_google_play_services_unsupported_title = 2131165305;
        public static final int common_google_play_services_update_button = 2131165306;
        public static final int common_google_play_services_update_text = 2131165307;
        public static final int common_google_play_services_update_title = 2131165308;
        public static final int common_google_play_services_updating_text = 2131165309;
        public static final int common_google_play_services_updating_title = 2131165310;
        public static final int common_google_play_services_wear_update_text = 2131165311;
        public static final int common_open_on_phone = 2131165312;
        public static final int common_signin_button_text = 2131165313;
        public static final int common_signin_button_text_long = 2131165314;
        public static final int create_calendar_message = 2131165727;
        public static final int create_calendar_title = 2131165728;
        public static final int decline = 2131165331;
        public static final int store_picture_message = 2131165767;
        public static final int store_picture_title = 2131165768;
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131362123;
    }

    public static final class styleable {
        public static final int[] AdsAttrs = new int[]{R.attr.adSize, R.attr.adSizes, R.attr.adUnitId};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] LoadingImageView = new int[]{R.attr.imageAspectRatioAdjust, R.attr.imageAspectRatio, R.attr.circleCrop};
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int[] SignInButton = new int[]{R.attr.buttonSize, R.attr.colorScheme, R.attr.scopeUris};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;
    }
}
