package com.google.android.gms.internal;

@zzhb
public final class zzic implements zzib {
    public final String zzaz(String str) {
        return null;
    }
}
