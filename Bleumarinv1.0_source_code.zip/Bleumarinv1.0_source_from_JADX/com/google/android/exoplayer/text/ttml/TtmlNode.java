package com.google.android.exoplayer.text.ttml;

import android.text.SpannableStringBuilder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

final class TtmlNode {
    public static final String ATTR_ID = "id";
    public static final String ATTR_TTS_BACKGROUND_COLOR = "backgroundColor";
    public static final String ATTR_TTS_COLOR = "color";
    public static final String ATTR_TTS_FONT_FAMILY = "fontFamily";
    public static final String ATTR_TTS_FONT_SIZE = "fontSize";
    public static final String ATTR_TTS_FONT_STYLE = "fontStyle";
    public static final String ATTR_TTS_FONT_WEIGHT = "fontWeight";
    public static final String ATTR_TTS_TEXT_ALIGN = "textAlign";
    public static final String ATTR_TTS_TEXT_DECORATION = "textDecoration";
    public static final String BOLD = "bold";
    public static final String CENTER = "center";
    public static final String END = "end";
    public static final String ITALIC = "italic";
    public static final String LEFT = "left";
    public static final String LINETHROUGH = "linethrough";
    public static final String NO_LINETHROUGH = "nolinethrough";
    public static final String NO_UNDERLINE = "nounderline";
    public static final String RIGHT = "right";
    public static final String START = "start";
    public static final String TAG_BODY = "body";
    public static final String TAG_BR = "br";
    public static final String TAG_DIV = "div";
    public static final String TAG_HEAD = "head";
    public static final String TAG_LAYOUT = "layout";
    public static final String TAG_METADATA = "metadata";
    public static final String TAG_P = "p";
    public static final String TAG_REGION = "region";
    public static final String TAG_SMPTE_DATA = "smpte:data";
    public static final String TAG_SMPTE_IMAGE = "smpte:image";
    public static final String TAG_SMPTE_INFORMATION = "smpte:information";
    public static final String TAG_SPAN = "span";
    public static final String TAG_STYLE = "style";
    public static final String TAG_STYLING = "styling";
    public static final String TAG_TT = "tt";
    public static final long UNDEFINED_TIME = -1;
    public static final String UNDERLINE = "underline";
    private List<TtmlNode> children;
    private int end;
    public final long endTimeUs;
    public final boolean isTextNode;
    private int start;
    public final long startTimeUs;
    public final TtmlStyle style;
    private String[] styleIds;
    public final String tag;
    public final String text;

    public static TtmlNode buildTextNode(String str) {
        return new TtmlNode(null, TtmlRenderUtil.applyTextElementSpacePolicy(str), -1, -1, null, null);
    }

    public static TtmlNode buildNode(String str, long j, long j2, TtmlStyle ttmlStyle, String[] strArr) {
        return new TtmlNode(str, null, j, j2, ttmlStyle, strArr);
    }

    private TtmlNode(String str, String str2, long j, long j2, TtmlStyle ttmlStyle, String[] strArr) {
        this.tag = str;
        this.text = str2;
        this.style = ttmlStyle;
        this.styleIds = strArr;
        this.isTextNode = str2 != null;
        this.startTimeUs = j;
        this.endTimeUs = j2;
    }

    public final boolean isActive(long j) {
        return (this.startTimeUs == -1 && this.endTimeUs == -1) || ((this.startTimeUs <= j && this.endTimeUs == -1) || ((this.startTimeUs == -1 && j < this.endTimeUs) || (this.startTimeUs <= j && j < this.endTimeUs)));
    }

    public final void addChild(TtmlNode ttmlNode) {
        if (this.children == null) {
            this.children = new ArrayList();
        }
        this.children.add(ttmlNode);
    }

    public final TtmlNode getChild(int i) {
        if (this.children != null) {
            return (TtmlNode) this.children.get(i);
        }
        throw new IndexOutOfBoundsException();
    }

    public final int getChildCount() {
        return this.children == null ? 0 : this.children.size();
    }

    public final long[] getEventTimesUs() {
        TreeSet treeSet = new TreeSet();
        getEventTimes(treeSet, false);
        long[] jArr = new long[treeSet.size()];
        Iterator it = treeSet.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = i + 1;
            jArr[i] = ((Long) it.next()).longValue();
            i = i2;
        }
        return jArr;
    }

    private void getEventTimes(TreeSet<Long> treeSet, boolean z) {
        boolean equals = TAG_P.equals(this.tag);
        if (z || equals) {
            if (this.startTimeUs != -1) {
                treeSet.add(Long.valueOf(this.startTimeUs));
            }
            if (this.endTimeUs != -1) {
                treeSet.add(Long.valueOf(this.endTimeUs));
            }
        }
        if (this.children != null) {
            for (int i = 0; i < this.children.size(); i++) {
                boolean z2;
                TtmlNode ttmlNode = (TtmlNode) this.children.get(i);
                if (z || equals) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                ttmlNode.getEventTimes(treeSet, z2);
            }
        }
    }

    public final String[] getStyleIds() {
        return this.styleIds;
    }

    public final CharSequence getText(long j, Map<String, TtmlStyle> map) {
        int i;
        CharSequence spannableStringBuilder = new SpannableStringBuilder();
        traverseForText(j, spannableStringBuilder, false);
        traverseForStyle(spannableStringBuilder, map);
        int length = spannableStringBuilder.length();
        int i2 = 0;
        while (i2 < length) {
            if (spannableStringBuilder.charAt(i2) == ' ') {
                i = i2 + 1;
                while (i < spannableStringBuilder.length() && spannableStringBuilder.charAt(i) == ' ') {
                    i++;
                }
                i -= i2 + 1;
                if (i > 0) {
                    spannableStringBuilder.delete(i2, i2 + i);
                    i = length - i;
                    i2++;
                    length = i;
                }
            }
            i = length;
            i2++;
            length = i;
        }
        if (length > 0 && spannableStringBuilder.charAt(0) == ' ') {
            spannableStringBuilder.delete(0, 1);
            length--;
        }
        i = length;
        length = 0;
        while (length < i - 1) {
            if (spannableStringBuilder.charAt(length) == '\n' && spannableStringBuilder.charAt(length + 1) == ' ') {
                spannableStringBuilder.delete(length + 1, length + 2);
                i--;
            }
            length++;
        }
        if (i > 0 && spannableStringBuilder.charAt(i - 1) == ' ') {
            spannableStringBuilder.delete(i - 1, i);
            i--;
        }
        length = 0;
        while (length < i - 1) {
            if (spannableStringBuilder.charAt(length) == ' ' && spannableStringBuilder.charAt(length + 1) == '\n') {
                spannableStringBuilder.delete(length, length + 1);
                i--;
            }
            length++;
        }
        if (i > 0 && spannableStringBuilder.charAt(i - 1) == '\n') {
            spannableStringBuilder.delete(i - 1, i);
        }
        return spannableStringBuilder;
    }

    private SpannableStringBuilder traverseForText(long j, SpannableStringBuilder spannableStringBuilder, boolean z) {
        this.start = spannableStringBuilder.length();
        this.end = this.start;
        if (this.isTextNode && z) {
            spannableStringBuilder.append(this.text);
        } else if (TAG_BR.equals(this.tag) && z) {
            spannableStringBuilder.append('\n');
        } else if (!TAG_METADATA.equals(this.tag) && isActive(j)) {
            boolean equals = TAG_P.equals(this.tag);
            for (int i = 0; i < getChildCount(); i++) {
                boolean z2;
                TtmlNode child = getChild(i);
                if (z || equals) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                child.traverseForText(j, spannableStringBuilder, z2);
            }
            if (equals) {
                TtmlRenderUtil.endParagraph(spannableStringBuilder);
            }
            this.end = spannableStringBuilder.length();
        }
        return spannableStringBuilder;
    }

    private void traverseForStyle(SpannableStringBuilder spannableStringBuilder, Map<String, TtmlStyle> map) {
        if (this.start != this.end) {
            TtmlStyle resolveStyle = TtmlRenderUtil.resolveStyle(this.style, this.styleIds, map);
            if (resolveStyle != null) {
                TtmlRenderUtil.applyStylesToSpan(spannableStringBuilder, this.start, this.end, resolveStyle);
            }
            for (int i = 0; i < getChildCount(); i++) {
                getChild(i).traverseForStyle(spannableStringBuilder, map);
            }
        }
    }
}
