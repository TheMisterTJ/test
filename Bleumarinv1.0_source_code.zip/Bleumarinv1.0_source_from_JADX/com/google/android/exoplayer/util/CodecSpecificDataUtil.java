package com.google.android.exoplayer.util;

import android.util.Log;
import android.util.Pair;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.List;

public final class CodecSpecificDataUtil {
    private static final int AUDIO_OBJECT_TYPE_AAC_LC = 2;
    private static final int AUDIO_OBJECT_TYPE_ER_BSAC = 22;
    private static final int AUDIO_OBJECT_TYPE_PS = 29;
    private static final int AUDIO_OBJECT_TYPE_SBR = 5;
    private static final int AUDIO_SPECIFIC_CONFIG_CHANNEL_CONFIGURATION_INVALID = -1;
    private static final int[] AUDIO_SPECIFIC_CONFIG_CHANNEL_COUNT_TABLE = new int[]{0, 1, 2, 3, 4, 5, 6, 8, -1, -1, -1, 7, 8, -1, 8, -1};
    private static final int AUDIO_SPECIFIC_CONFIG_FREQUENCY_INDEX_ARBITRARY = 15;
    private static final int[] AUDIO_SPECIFIC_CONFIG_SAMPLING_RATE_TABLE = new int[]{96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    private static final byte[] NAL_START_CODE = new byte[]{(byte) 0, (byte) 0, (byte) 0, (byte) 1};
    private static final String TAG = "CodecSpecificDataUtil";

    public static final class SpsData {
        public final int height;
        public final float pixelWidthAspectRatio;
        public final int width;

        public SpsData(int i, int i2, float f) {
            this.width = i;
            this.height = i2;
            this.pixelWidthAspectRatio = f;
        }
    }

    private CodecSpecificDataUtil() {
    }

    public static Pair<Integer, Integer> parseAacAudioSpecificConfig(byte[] bArr) {
        int readBits;
        boolean z;
        boolean z2 = true;
        ParsableBitArray parsableBitArray = new ParsableBitArray(bArr);
        int readBits2 = parsableBitArray.readBits(5);
        int readBits3 = parsableBitArray.readBits(4);
        if (readBits3 == 15) {
            readBits = parsableBitArray.readBits(24);
        } else {
            if (readBits3 < 13) {
                z = true;
            } else {
                z = false;
            }
            Assertions.checkArgument(z);
            readBits = AUDIO_SPECIFIC_CONFIG_SAMPLING_RATE_TABLE[readBits3];
        }
        readBits3 = parsableBitArray.readBits(4);
        if (readBits2 == 5 || readBits2 == 29) {
            readBits2 = parsableBitArray.readBits(4);
            if (readBits2 == 15) {
                readBits = parsableBitArray.readBits(24);
            } else {
                if (readBits2 < 13) {
                    z = true;
                } else {
                    z = false;
                }
                Assertions.checkArgument(z);
                readBits = AUDIO_SPECIFIC_CONFIG_SAMPLING_RATE_TABLE[readBits2];
            }
            if (parsableBitArray.readBits(5) == 22) {
                readBits3 = readBits;
                readBits = parsableBitArray.readBits(4);
                readBits = AUDIO_SPECIFIC_CONFIG_CHANNEL_COUNT_TABLE[readBits];
                if (readBits == -1) {
                    z2 = false;
                }
                Assertions.checkArgument(z2);
                return Pair.create(Integer.valueOf(readBits3), Integer.valueOf(readBits));
            }
        }
        int i = readBits3;
        readBits3 = readBits;
        readBits = i;
        readBits = AUDIO_SPECIFIC_CONFIG_CHANNEL_COUNT_TABLE[readBits];
        if (readBits == -1) {
            z2 = false;
        }
        Assertions.checkArgument(z2);
        return Pair.create(Integer.valueOf(readBits3), Integer.valueOf(readBits));
    }

    public static byte[] buildAacAudioSpecificConfig(int i, int i2, int i3) {
        return new byte[]{(byte) (((i << 3) & 248) | ((i2 >> 1) & 7)), (byte) (((i2 << 7) & 128) | ((i3 << 3) & 120))};
    }

    public static byte[] buildAacAudioSpecificConfig(int i, int i2) {
        int i3;
        int i4 = -1;
        int i5 = -1;
        for (i3 = 0; i3 < AUDIO_SPECIFIC_CONFIG_SAMPLING_RATE_TABLE.length; i3++) {
            if (i == AUDIO_SPECIFIC_CONFIG_SAMPLING_RATE_TABLE[i3]) {
                i5 = i3;
            }
        }
        for (i3 = 0; i3 < AUDIO_SPECIFIC_CONFIG_CHANNEL_COUNT_TABLE.length; i3++) {
            if (i2 == AUDIO_SPECIFIC_CONFIG_CHANNEL_COUNT_TABLE[i3]) {
                i4 = i3;
            }
        }
        return new byte[]{(byte) ((i5 >> 1) | 16), (byte) (((i5 & 1) << 7) | (i4 << 3))};
    }

    public static byte[] buildNalUnit(byte[] bArr, int i, int i2) {
        Object obj = new byte[(NAL_START_CODE.length + i2)];
        System.arraycopy(NAL_START_CODE, 0, obj, 0, NAL_START_CODE.length);
        System.arraycopy(bArr, i, obj, NAL_START_CODE.length, i2);
        return obj;
    }

    public static byte[][] splitNalUnits(byte[] bArr) {
        if (!isNalStartCode(bArr, 0)) {
            return null;
        }
        List arrayList = new ArrayList();
        int i = 0;
        do {
            arrayList.add(Integer.valueOf(i));
            i = findNalStartCode(bArr, i + NAL_START_CODE.length);
        } while (i != -1);
        byte[][] bArr2 = new byte[arrayList.size()][];
        int i2 = 0;
        while (i2 < arrayList.size()) {
            int intValue = ((Integer) arrayList.get(i2)).intValue();
            Object obj = new byte[((i2 < arrayList.size() + -1 ? ((Integer) arrayList.get(i2 + 1)).intValue() : bArr.length) - intValue)];
            System.arraycopy(bArr, intValue, obj, 0, obj.length);
            bArr2[i2] = obj;
            i2++;
        }
        return bArr2;
    }

    private static int findNalStartCode(byte[] bArr, int i) {
        int length = bArr.length - NAL_START_CODE.length;
        for (int i2 = i; i2 <= length; i2++) {
            if (isNalStartCode(bArr, i2)) {
                return i2;
            }
        }
        return -1;
    }

    private static boolean isNalStartCode(byte[] bArr, int i) {
        if (bArr.length - i <= NAL_START_CODE.length) {
            return false;
        }
        for (int i2 = 0; i2 < NAL_START_CODE.length; i2++) {
            if (bArr[i + i2] != NAL_START_CODE[i2]) {
                return false;
            }
        }
        return true;
    }

    public static SpsData parseSpsNalUnit(ParsableBitArray parsableBitArray) {
        int readUnsignedExpGolombCodedInt;
        int i;
        int i2;
        int i3 = 1;
        int readBits = parsableBitArray.readBits(8);
        parsableBitArray.skipBits(16);
        parsableBitArray.readUnsignedExpGolombCodedInt();
        if (readBits == 100 || readBits == 110 || readBits == 122 || readBits == 244 || readBits == 44 || readBits == 83 || readBits == 86 || readBits == 118 || readBits == 128 || readBits == 138) {
            readUnsignedExpGolombCodedInt = parsableBitArray.readUnsignedExpGolombCodedInt();
            if (readUnsignedExpGolombCodedInt == 3) {
                parsableBitArray.skipBits(1);
            }
            parsableBitArray.readUnsignedExpGolombCodedInt();
            parsableBitArray.readUnsignedExpGolombCodedInt();
            parsableBitArray.skipBits(1);
            if (parsableBitArray.readBit()) {
                readBits = readUnsignedExpGolombCodedInt != 3 ? 8 : 12;
                i = 0;
                while (i < readBits) {
                    if (parsableBitArray.readBit()) {
                        skipScalingList(parsableBitArray, i < 6 ? 16 : 64);
                    }
                    i++;
                }
            }
            readBits = readUnsignedExpGolombCodedInt;
        } else {
            readBits = 1;
        }
        parsableBitArray.readUnsignedExpGolombCodedInt();
        long readUnsignedExpGolombCodedInt2 = (long) parsableBitArray.readUnsignedExpGolombCodedInt();
        if (readUnsignedExpGolombCodedInt2 == 0) {
            parsableBitArray.readUnsignedExpGolombCodedInt();
        } else if (readUnsignedExpGolombCodedInt2 == 1) {
            parsableBitArray.skipBits(1);
            parsableBitArray.readSignedExpGolombCodedInt();
            parsableBitArray.readSignedExpGolombCodedInt();
            readUnsignedExpGolombCodedInt2 = (long) parsableBitArray.readUnsignedExpGolombCodedInt();
            for (i2 = 0; ((long) i2) < readUnsignedExpGolombCodedInt2; i2++) {
                parsableBitArray.readUnsignedExpGolombCodedInt();
            }
        }
        parsableBitArray.readUnsignedExpGolombCodedInt();
        parsableBitArray.skipBits(1);
        readUnsignedExpGolombCodedInt = parsableBitArray.readUnsignedExpGolombCodedInt() + 1;
        i = parsableBitArray.readUnsignedExpGolombCodedInt() + 1;
        boolean readBit = parsableBitArray.readBit();
        if (readBit) {
            i2 = 1;
        } else {
            i2 = 0;
        }
        i2 = (2 - i2) * i;
        if (!readBit) {
            parsableBitArray.skipBits(1);
        }
        parsableBitArray.skipBits(1);
        readUnsignedExpGolombCodedInt *= 16;
        i = i2 * 16;
        if (parsableBitArray.readBit()) {
            int readUnsignedExpGolombCodedInt3 = parsableBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt4 = parsableBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt5 = parsableBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt6 = parsableBitArray.readUnsignedExpGolombCodedInt();
            if (readBits == 0) {
                readBits = 2 - (readBit ? 1 : 0);
            } else {
                i2 = readBits == 3 ? 1 : 2;
                if (readBits == 1) {
                    readBits = 2;
                } else {
                    readBits = 1;
                }
                if (!readBit) {
                    i3 = 0;
                }
                readBits *= 2 - i3;
                i3 = i2;
            }
            i2 = i - (readBits * (readUnsignedExpGolombCodedInt5 + readUnsignedExpGolombCodedInt6));
            readBits = readUnsignedExpGolombCodedInt - ((readUnsignedExpGolombCodedInt3 + readUnsignedExpGolombCodedInt4) * i3);
        } else {
            readBits = readUnsignedExpGolombCodedInt;
            i2 = i;
        }
        float f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
        if (parsableBitArray.readBit() && parsableBitArray.readBit()) {
            int readBits2 = parsableBitArray.readBits(8);
            if (readBits2 == 255) {
                readBits2 = parsableBitArray.readBits(16);
                int readBits3 = parsableBitArray.readBits(16);
                float f2 = (readBits2 == 0 || readBits3 == 0) ? DefaultRetryPolicy.DEFAULT_BACKOFF_MULT : ((float) readBits2) / ((float) readBits3);
                f = f2;
            } else if (readBits2 < NalUnitUtil.ASPECT_RATIO_IDC_VALUES.length) {
                f = NalUnitUtil.ASPECT_RATIO_IDC_VALUES[readBits2];
            } else {
                Log.w(TAG, "Unexpected aspect_ratio_idc value: " + readBits2);
            }
        }
        return new SpsData(readBits, i2, f);
    }

    private static void skipScalingList(ParsableBitArray parsableBitArray, int i) {
        int i2 = 8;
        int i3 = 8;
        for (int i4 = 0; i4 < i; i4++) {
            if (i2 != 0) {
                i2 = ((parsableBitArray.readSignedExpGolombCodedInt() + i3) + 256) % 256;
            }
            if (i2 != 0) {
                i3 = i2;
            }
        }
    }
}
