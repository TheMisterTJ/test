package com.google.android.gms.internal;

@zzhb
public interface zzit<T> {
    void cancel();

    T zzgd();
}
