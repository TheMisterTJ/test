package com.google.android.gms.internal;

public interface zzay {
    void zza(zzau com_google_android_gms_internal_zzau);
}
