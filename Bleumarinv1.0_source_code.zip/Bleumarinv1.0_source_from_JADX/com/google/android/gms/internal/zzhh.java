package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;

public interface zzhh {
    void zza(Context context, String str, Bundle bundle);
}
