package com.google.android.gms.internal;

@zzhb
public final class zzes {
    public final int zzCo;
    public final zzen zzCp;
    public final zzey zzCq;
    public final String zzCr;
    public final zzeq zzCs;
    public final zzfa zzCt;

    public interface zza {
        void zza(int i, zzfa com_google_android_gms_internal_zzfa);

        void zzr(int i);
    }

    public zzes(int i) {
        this(null, null, null, null, i, null);
    }

    public zzes(zzen com_google_android_gms_internal_zzen, zzey com_google_android_gms_internal_zzey, String str, zzeq com_google_android_gms_internal_zzeq, int i, zzfa com_google_android_gms_internal_zzfa) {
        this.zzCp = com_google_android_gms_internal_zzen;
        this.zzCq = com_google_android_gms_internal_zzey;
        this.zzCr = str;
        this.zzCs = com_google_android_gms_internal_zzeq;
        this.zzCo = i;
        this.zzCt = com_google_android_gms_internal_zzfa;
    }
}
