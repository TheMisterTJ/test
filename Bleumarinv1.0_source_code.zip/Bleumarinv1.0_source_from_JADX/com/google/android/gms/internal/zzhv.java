package com.google.android.gms.internal;

public interface zzhv {
    void zzN(int i);

    void zzgN();
}
