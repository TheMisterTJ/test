package com.p026c.p027a;

import android.util.Log;
import com.mopub.volley.DefaultRetryPolicy;
import com.p026c.p027a.C0564f.C0565a;
import com.p026c.p027a.C0564f.C0566b;
import com.p026c.p038b.C0569c;
import com.p026c.p038b.C0570a;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* compiled from: PropertyValuesHolder */
public class C0582j implements Cloneable {
    static final C0559k f1537f = new C0563e();
    static final C0559k f1538g = new C0560c();
    private static Class[] f1539l = new Class[]{Float.TYPE, Float.class, Double.TYPE, Integer.TYPE, Double.class, Integer.class};
    private static Class[] f1540m = new Class[]{Integer.TYPE, Integer.class, Float.TYPE, Double.TYPE, Float.class, Double.class};
    private static Class[] f1541n = new Class[]{Double.TYPE, Double.class, Float.TYPE, Integer.TYPE, Float.class, Integer.class};
    private static final HashMap<Class, HashMap<String, Method>> f1542o = new HashMap();
    private static final HashMap<Class, HashMap<String, Method>> f1543p = new HashMap();
    String f1544a;
    protected C0569c f1545b;
    Method f1546c;
    Class f1547d;
    C0561g f1548e;
    final ReentrantReadWriteLock f1549h;
    final Object[] f1550i;
    C0559k f1551j;
    private Method f1552k;
    private Object f1553q;

    /* compiled from: PropertyValuesHolder */
    static class C0583a extends C0582j {
        C0562d f1554k;
        float f1555l;
        private C0570a f1556m;

        public final /* synthetic */ C0582j mo1675a() {
            return m1337c();
        }

        public final /* synthetic */ Object clone() throws CloneNotSupportedException {
            return m1337c();
        }

        public C0583a(String str, float... fArr) {
            super(str);
            mo1678a(fArr);
        }

        public C0583a(C0569c c0569c, float... fArr) {
            super(c0569c);
            mo1678a(fArr);
            if (c0569c instanceof C0570a) {
                this.f1556m = (C0570a) this.b;
            }
        }

        public final void mo1678a(float... fArr) {
            super.mo1678a(fArr);
            this.f1554k = (C0562d) this.e;
        }

        final void mo1676a(float f) {
            this.f1555l = this.f1554k.m1245b(f);
        }

        final Object mo1679b() {
            return Float.valueOf(this.f1555l);
        }

        private C0583a m1337c() {
            C0583a c0583a = (C0583a) super.mo1675a();
            c0583a.f1554k = (C0562d) c0583a.e;
            return c0583a;
        }

        final void mo1680b(Object obj) {
            if (this.f1556m != null) {
                this.f1556m.mo1674a(obj, this.f1555l);
            } else if (this.b != null) {
                this.b.mo1672a(obj, Float.valueOf(this.f1555l));
            } else if (this.c != null) {
                try {
                    this.i[0] = Float.valueOf(this.f1555l);
                    this.c.invoke(obj, this.i);
                } catch (InvocationTargetException e) {
                    Log.e("PropertyValuesHolder", e.toString());
                } catch (IllegalAccessException e2) {
                    Log.e("PropertyValuesHolder", e2.toString());
                }
            }
        }

        final void mo1677a(Class cls) {
            if (this.b == null) {
                super.mo1677a(cls);
            }
        }
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return mo1675a();
    }

    private C0582j(String str) {
        this.f1546c = null;
        this.f1552k = null;
        this.f1548e = null;
        this.f1549h = new ReentrantReadWriteLock();
        this.f1550i = new Object[1];
        this.f1544a = str;
    }

    private C0582j(C0569c c0569c) {
        this.f1546c = null;
        this.f1552k = null;
        this.f1548e = null;
        this.f1549h = new ReentrantReadWriteLock();
        this.f1550i = new Object[1];
        this.f1545b = c0569c;
        if (c0569c != null) {
            this.f1544a = c0569c.f1521a;
        }
    }

    public static C0582j m1326a(String str, float... fArr) {
        return new C0583a(str, fArr);
    }

    public static C0582j m1324a(C0569c<?, Float> c0569c, float... fArr) {
        return new C0583a((C0569c) c0569c, fArr);
    }

    public static C0582j m1325a(String str, C0559k c0559k, Object... objArr) {
        C0582j c0582j = new C0582j(str);
        c0582j.f1547d = objArr[0].getClass();
        C0564f[] c0564fArr = new C0566b[Math.max(1, 2)];
        c0564fArr[0] = new C0566b(0.0f, null);
        c0564fArr[1] = new C0566b(DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, objArr[0]);
        c0582j.f1548e = new C0561g(c0564fArr);
        c0582j.f1551j = c0559k;
        c0582j.f1548e.f1477f = c0559k;
        return c0582j;
    }

    public void mo1678a(float... fArr) {
        int i = 1;
        this.f1547d = Float.TYPE;
        int length = fArr.length;
        C0565a[] c0565aArr = new C0565a[Math.max(length, 2)];
        if (length == 1) {
            c0565aArr[0] = new C0565a();
            c0565aArr[1] = (C0565a) C0564f.m1247a(DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, fArr[0]);
        } else {
            c0565aArr[0] = (C0565a) C0564f.m1247a(0.0f, fArr[0]);
            while (i < length) {
                c0565aArr[i] = (C0565a) C0564f.m1247a(((float) i) / ((float) (length - 1)), fArr[i]);
                i++;
            }
        }
        this.f1548e = new C0562d(c0565aArr);
    }

    private Method m1327a(Class cls, String str, Class cls2) {
        Method method = null;
        String str2 = this.f1544a;
        if (!(str2 == null || str2.length() == 0)) {
            str = str + Character.toUpperCase(str2.charAt(0)) + str2.substring(1);
        }
        if (cls2 == null) {
            try {
                return cls.getMethod(str, null);
            } catch (NoSuchMethodException e) {
                Method declaredMethod;
                try {
                    declaredMethod = cls.getDeclaredMethod(str, null);
                    try {
                        declaredMethod.setAccessible(true);
                        return declaredMethod;
                    } catch (NoSuchMethodException e2) {
                        Log.e("PropertyValuesHolder", "Couldn't find no-arg method for property " + this.f1544a + ": " + e);
                        return declaredMethod;
                    }
                } catch (NoSuchMethodException e3) {
                    declaredMethod = null;
                    Log.e("PropertyValuesHolder", "Couldn't find no-arg method for property " + this.f1544a + ": " + e);
                    return declaredMethod;
                }
            }
        }
        Class[] clsArr;
        Class[] clsArr2 = new Class[1];
        if (this.f1547d.equals(Float.class)) {
            clsArr = f1539l;
        } else if (this.f1547d.equals(Integer.class)) {
            clsArr = f1540m;
        } else {
            clsArr = this.f1547d.equals(Double.class) ? f1541n : new Class[]{this.f1547d};
        }
        int length = clsArr.length;
        int i = 0;
        while (i < length) {
            Class cls3 = clsArr[i];
            clsArr2[0] = cls3;
            try {
                method = cls.getMethod(str, clsArr2);
                this.f1547d = cls3;
                return method;
            } catch (NoSuchMethodException e4) {
                try {
                    method = cls.getDeclaredMethod(str, clsArr2);
                    method.setAccessible(true);
                    this.f1547d = cls3;
                    return method;
                } catch (NoSuchMethodException e5) {
                    i++;
                }
            }
        }
        Log.e("PropertyValuesHolder", "Couldn't find setter/getter for property " + this.f1544a + " with value type " + this.f1547d);
        return method;
    }

    private Method m1328a(Class cls, HashMap<Class, HashMap<String, Method>> hashMap, String str, Class cls2) {
        Method method = null;
        try {
            this.f1549h.writeLock().lock();
            HashMap hashMap2 = (HashMap) hashMap.get(cls);
            if (hashMap2 != null) {
                method = (Method) hashMap2.get(this.f1544a);
            }
            if (method == null) {
                method = m1327a(cls, str, cls2);
                if (hashMap2 == null) {
                    hashMap2 = new HashMap();
                    hashMap.put(cls, hashMap2);
                }
                hashMap2.put(this.f1544a, method);
            }
            Method method2 = method;
            this.f1549h.writeLock().unlock();
            return method2;
        } catch (Throwable th) {
            this.f1549h.writeLock().unlock();
        }
    }

    void mo1677a(Class cls) {
        this.f1546c = m1328a(cls, f1542o, "set", this.f1547d);
    }

    final void m1333a(Object obj) {
        C0564f c0564f;
        if (this.f1545b != null) {
            try {
                this.f1545b.mo1673a(obj);
                Iterator it = this.f1548e.f1476e.iterator();
                while (it.hasNext()) {
                    c0564f = (C0564f) it.next();
                    if (!c0564f.f1485d) {
                        c0564f.mo1659a(this.f1545b.mo1673a(obj));
                    }
                }
                return;
            } catch (ClassCastException e) {
                Log.e("PropertyValuesHolder", "No such property (" + this.f1545b.f1521a + ") on target object " + obj + ". Trying reflection instead");
                this.f1545b = null;
            }
        }
        Class cls = obj.getClass();
        if (this.f1546c == null) {
            mo1677a(cls);
        }
        Iterator it2 = this.f1548e.f1476e.iterator();
        while (it2.hasNext()) {
            c0564f = (C0564f) it2.next();
            if (!c0564f.f1485d) {
                if (this.f1552k == null) {
                    this.f1552k = m1328a(cls, f1543p, "get", null);
                }
                try {
                    c0564f.mo1659a(this.f1552k.invoke(obj, new Object[0]));
                } catch (InvocationTargetException e2) {
                    Log.e("PropertyValuesHolder", e2.toString());
                } catch (IllegalAccessException e3) {
                    Log.e("PropertyValuesHolder", e3.toString());
                }
            }
        }
    }

    public C0582j mo1675a() {
        try {
            C0582j c0582j = (C0582j) super.clone();
            c0582j.f1544a = this.f1544a;
            c0582j.f1545b = this.f1545b;
            c0582j.f1548e = this.f1548e.mo1655a();
            c0582j.f1551j = this.f1551j;
            return c0582j;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    void mo1680b(Object obj) {
        if (this.f1545b != null) {
            this.f1545b.mo1672a(obj, mo1679b());
        }
        if (this.f1546c != null) {
            try {
                this.f1550i[0] = mo1679b();
                this.f1546c.invoke(obj, this.f1550i);
            } catch (InvocationTargetException e) {
                Log.e("PropertyValuesHolder", e.toString());
            } catch (IllegalAccessException e2) {
                Log.e("PropertyValuesHolder", e2.toString());
            }
        }
    }

    void mo1676a(float f) {
        this.f1553q = this.f1548e.mo1656a(f);
    }

    public final void m1331a(C0569c c0569c) {
        this.f1545b = c0569c;
    }

    Object mo1679b() {
        return this.f1553q;
    }

    public String toString() {
        return this.f1544a + ": " + this.f1548e.toString();
    }
}
