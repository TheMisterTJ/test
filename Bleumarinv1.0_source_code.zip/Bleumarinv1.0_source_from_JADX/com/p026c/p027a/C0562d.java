package com.p026c.p027a;

import com.mopub.volley.DefaultRetryPolicy;
import com.p026c.p027a.C0564f.C0565a;
import java.util.ArrayList;

/* compiled from: FloatKeyframeSet */
final class C0562d extends C0561g {
    private float f1478g;
    private float f1479h;
    private float f1480i;
    private boolean f1481j = true;

    public final /* synthetic */ C0561g mo1655a() {
        return m1242b();
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return m1242b();
    }

    public C0562d(C0565a... c0565aArr) {
        super(c0565aArr);
    }

    public final Object mo1656a(float f) {
        return Float.valueOf(m1245b(f));
    }

    private C0562d m1242b() {
        ArrayList arrayList = this.e;
        int size = this.e.size();
        C0565a[] c0565aArr = new C0565a[size];
        for (int i = 0; i < size; i++) {
            c0565aArr[i] = (C0565a) ((C0564f) arrayList.get(i)).mo1660b();
        }
        return new C0562d(c0565aArr);
    }

    public final float m1245b(float f) {
        int i = 1;
        if (this.a == 2) {
            if (this.f1481j) {
                this.f1481j = false;
                this.f1478g = ((C0565a) this.e.get(0)).f1486e;
                this.f1479h = ((C0565a) this.e.get(1)).f1486e;
                this.f1480i = this.f1479h - this.f1478g;
            }
            if (this.d != null) {
                f = this.d.getInterpolation(f);
            }
            if (this.f == null) {
                return this.f1478g + (this.f1480i * f);
            }
            return ((Number) this.f.mo1654a(f, Float.valueOf(this.f1478g), Float.valueOf(this.f1479h))).floatValue();
        } else if (f <= 0.0f) {
            r0 = (C0565a) this.e.get(0);
            r1 = (C0565a) this.e.get(1);
            r2 = r0.f1486e;
            r3 = r1.f1486e;
            r0 = r0.f1482a;
            r4 = r1.f1482a;
            r1 = r1.f1484c;
            if (r1 != null) {
                f = r1.getInterpolation(f);
            }
            r0 = (f - r0) / (r4 - r0);
            return this.f == null ? (r0 * (r3 - r2)) + r2 : ((Number) this.f.mo1654a(r0, Float.valueOf(r2), Float.valueOf(r3))).floatValue();
        } else if (f >= DefaultRetryPolicy.DEFAULT_BACKOFF_MULT) {
            r0 = (C0565a) this.e.get(this.a - 2);
            r1 = (C0565a) this.e.get(this.a - 1);
            r2 = r0.f1486e;
            r3 = r1.f1486e;
            r0 = r0.f1482a;
            r4 = r1.f1482a;
            r1 = r1.f1484c;
            if (r1 != null) {
                f = r1.getInterpolation(f);
            }
            r0 = (f - r0) / (r4 - r0);
            return this.f == null ? (r0 * (r3 - r2)) + r2 : ((Number) this.f.mo1654a(r0, Float.valueOf(r2), Float.valueOf(r3))).floatValue();
        } else {
            C0564f c0564f = (C0565a) this.e.get(0);
            while (i < this.a) {
                C0564f c0564f2 = (C0565a) this.e.get(i);
                if (f < c0564f2.f1482a) {
                    r1 = c0564f2.f1484c;
                    if (r1 != null) {
                        f = r1.getInterpolation(f);
                    }
                    float f2 = (f - c0564f.f1482a) / (c0564f2.f1482a - c0564f.f1482a);
                    r2 = c0564f.f1486e;
                    r0 = c0564f2.f1486e;
                    return this.f == null ? ((r0 - r2) * f2) + r2 : ((Number) this.f.mo1654a(f2, Float.valueOf(r2), Float.valueOf(r0))).floatValue();
                } else {
                    i++;
                    c0564f = c0564f2;
                }
            }
            return ((Number) ((C0564f) this.e.get(this.a - 1)).mo1658a()).floatValue();
        }
    }
}
