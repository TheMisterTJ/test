package com.p026c.p027a;

/* compiled from: TypeEvaluator */
public interface C0559k<T> {
    T mo1654a(float f, T t, T t2);
}
