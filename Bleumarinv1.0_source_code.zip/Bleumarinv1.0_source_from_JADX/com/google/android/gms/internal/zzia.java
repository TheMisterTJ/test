package com.google.android.gms.internal;

@zzhb
public class zzia {
    private final zzey zzCi;
    private final zzhx zzKQ;

    public zzia(zzey com_google_android_gms_internal_zzey, zzhw com_google_android_gms_internal_zzhw) {
        this.zzCi = com_google_android_gms_internal_zzey;
        this.zzKQ = new zzhx(com_google_android_gms_internal_zzhw);
    }

    public zzey zzgP() {
        return this.zzCi;
    }

    public zzhx zzgQ() {
        return this.zzKQ;
    }
}
