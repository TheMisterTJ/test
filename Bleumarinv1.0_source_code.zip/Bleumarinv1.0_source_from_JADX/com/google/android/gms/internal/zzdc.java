package com.google.android.gms.internal;

@zzhb
public class zzdc implements zzdt {
    public zzdr zza(zzjp com_google_android_gms_internal_zzjp, int i, String str) {
        return new zzdu(com_google_android_gms_internal_zzjp);
    }
}
