package com.google.android.gms.internal;

import android.location.Location;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import java.util.Date;
import java.util.Set;

@zzhb
public final class zzfd implements MediationAdRequest {
    private final int zzCH;
    private final Date zzbf;
    private final Set<String> zzbh;
    private final boolean zzbi;
    private final Location zzbj;
    private final int zztT;
    private final boolean zzuf;

    public zzfd(Date date, int i, Set<String> set, Location location, boolean z, int i2, boolean z2) {
        this.zzbf = date;
        this.zztT = i;
        this.zzbh = set;
        this.zzbj = location;
        this.zzbi = z;
        this.zzCH = i2;
        this.zzuf = z2;
    }

    public final Date getBirthday() {
        return this.zzbf;
    }

    public final int getGender() {
        return this.zztT;
    }

    public final Set<String> getKeywords() {
        return this.zzbh;
    }

    public final Location getLocation() {
        return this.zzbj;
    }

    public final boolean isDesignedForFamilies() {
        return this.zzuf;
    }

    public final boolean isTesting() {
        return this.zzbi;
    }

    public final int taggedForChildDirectedTreatment() {
        return this.zzCH;
    }
}
