package com.google.android.exoplayer.chunk;

import android.os.Handler;
import android.os.SystemClock;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.LoadControl;
import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.MediaFormatHolder;
import com.google.android.exoplayer.SampleHolder;
import com.google.android.exoplayer.SampleSource;
import com.google.android.exoplayer.SampleSource.SampleSourceReader;
import com.google.android.exoplayer.extractor.DefaultTrackOutput;
import com.google.android.exoplayer.hls.HlsChunkSource;
import com.google.android.exoplayer.upstream.Loader;
import com.google.android.exoplayer.upstream.Loader.Callback;
import com.google.android.exoplayer.upstream.Loader.Loadable;
import com.google.android.exoplayer.util.Assertions;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ChunkSampleSource implements SampleSource, SampleSourceReader, Callback {
    public static final int DEFAULT_MIN_LOADABLE_RETRY_COUNT = 3;
    private static final long NO_RESET_PENDING = Long.MIN_VALUE;
    private static final int STATE_ENABLED = 3;
    private static final int STATE_IDLE = 0;
    private static final int STATE_INITIALIZED = 1;
    private static final int STATE_PREPARED = 2;
    private final int bufferSizeContribution;
    private final ChunkSource chunkSource;
    private long currentLoadStartTimeMs;
    private IOException currentLoadableException;
    private int currentLoadableExceptionCount;
    private long currentLoadableExceptionTimestamp;
    private final ChunkOperationHolder currentLoadableHolder;
    private Format downstreamFormat;
    private MediaFormat downstreamMediaFormat;
    private long downstreamPositionUs;
    private int enabledTrackCount;
    private final Handler eventHandler;
    private final EventListener eventListener;
    private final int eventSourceId;
    private long lastPerformedBufferOperation;
    private long lastSeekPositionUs;
    private final LoadControl loadControl;
    private Loader loader;
    private boolean loadingFinished;
    private final LinkedList<BaseMediaChunk> mediaChunks;
    private final int minLoadableRetryCount;
    private boolean pendingDiscontinuity;
    private long pendingResetPositionUs;
    private final List<BaseMediaChunk> readOnlyMediaChunks;
    private final DefaultTrackOutput sampleQueue;
    private int state;

    public interface EventListener extends BaseChunkSampleSourceEventListener {
    }

    public ChunkSampleSource(ChunkSource chunkSource, LoadControl loadControl, int i) {
        this(chunkSource, loadControl, i, null, null, 0);
    }

    public ChunkSampleSource(ChunkSource chunkSource, LoadControl loadControl, int i, Handler handler, EventListener eventListener, int i2) {
        this(chunkSource, loadControl, i, handler, eventListener, i2, 3);
    }

    public ChunkSampleSource(ChunkSource chunkSource, LoadControl loadControl, int i, Handler handler, EventListener eventListener, int i2, int i3) {
        this.chunkSource = chunkSource;
        this.loadControl = loadControl;
        this.bufferSizeContribution = i;
        this.eventHandler = handler;
        this.eventListener = eventListener;
        this.eventSourceId = i2;
        this.minLoadableRetryCount = i3;
        this.currentLoadableHolder = new ChunkOperationHolder();
        this.mediaChunks = new LinkedList();
        this.readOnlyMediaChunks = Collections.unmodifiableList(this.mediaChunks);
        this.sampleQueue = new DefaultTrackOutput(loadControl.getAllocator());
        this.state = 0;
        this.pendingResetPositionUs = Long.MIN_VALUE;
    }

    public SampleSourceReader register() {
        Assertions.checkState(this.state == 0);
        this.state = 1;
        return this;
    }

    public boolean prepare(long j) {
        boolean z = this.state == 1 || this.state == 2;
        Assertions.checkState(z);
        if (this.state == 2) {
            return true;
        }
        if (!this.chunkSource.prepare()) {
            return false;
        }
        if (this.chunkSource.getTrackCount() > 0) {
            this.loader = new Loader("Loader:" + this.chunkSource.getFormat(0).mimeType);
        }
        this.state = 2;
        return true;
    }

    public int getTrackCount() {
        boolean z = this.state == 2 || this.state == 3;
        Assertions.checkState(z);
        return this.chunkSource.getTrackCount();
    }

    public MediaFormat getFormat(int i) {
        boolean z = this.state == 2 || this.state == 3;
        Assertions.checkState(z);
        return this.chunkSource.getFormat(i);
    }

    public void enable(int i, long j) {
        boolean z = true;
        Assertions.checkState(this.state == 2);
        int i2 = this.enabledTrackCount;
        this.enabledTrackCount = i2 + 1;
        if (i2 != 0) {
            z = false;
        }
        Assertions.checkState(z);
        this.state = 3;
        this.chunkSource.enable(i);
        this.loadControl.register(this, this.bufferSizeContribution);
        this.downstreamFormat = null;
        this.downstreamMediaFormat = null;
        this.downstreamPositionUs = j;
        this.lastSeekPositionUs = j;
        this.pendingDiscontinuity = false;
        restartFrom(j);
    }

    public void disable(int i) {
        boolean z = true;
        Assertions.checkState(this.state == 3);
        int i2 = this.enabledTrackCount - 1;
        this.enabledTrackCount = i2;
        if (i2 != 0) {
            z = false;
        }
        Assertions.checkState(z);
        this.state = 2;
        try {
            this.chunkSource.disable(this.mediaChunks);
        } finally {
            this.loadControl.unregister(this);
            if (this.loader.isLoading()) {
                this.loader.cancelLoading();
            } else {
                this.sampleQueue.clear();
                this.mediaChunks.clear();
                clearCurrentLoadable();
                this.loadControl.trimAllocator();
            }
        }
    }

    public boolean continueBuffering(int i, long j) {
        boolean z;
        if (this.state == 3) {
            z = true;
        } else {
            z = false;
        }
        Assertions.checkState(z);
        this.downstreamPositionUs = j;
        this.chunkSource.continueBuffering(j);
        updateLoadControl();
        if (this.loadingFinished || !this.sampleQueue.isEmpty()) {
            return true;
        }
        return false;
    }

    public long readDiscontinuity(int i) {
        if (!this.pendingDiscontinuity) {
            return Long.MIN_VALUE;
        }
        this.pendingDiscontinuity = false;
        return this.lastSeekPositionUs;
    }

    public int readData(int i, long j, MediaFormatHolder mediaFormatHolder, SampleHolder sampleHolder) {
        int i2 = 0;
        int i3 = 1;
        Assertions.checkState(this.state == 3);
        this.downstreamPositionUs = j;
        if (this.pendingDiscontinuity || isPendingReset()) {
            return -2;
        }
        int i4 = !this.sampleQueue.isEmpty() ? 1 : 0;
        MediaChunk mediaChunk = (BaseMediaChunk) this.mediaChunks.getFirst();
        while (i4 != 0 && this.mediaChunks.size() > 1 && ((BaseMediaChunk) this.mediaChunks.get(1)).getFirstSampleIndex() <= this.sampleQueue.getReadIndex()) {
            this.mediaChunks.removeFirst();
            mediaChunk = (BaseMediaChunk) this.mediaChunks.getFirst();
        }
        if (this.downstreamFormat == null || !this.downstreamFormat.equals(mediaChunk.format)) {
            notifyDownstreamFormatChanged(mediaChunk.format, mediaChunk.trigger, mediaChunk.startTimeUs);
            this.downstreamFormat = mediaChunk.format;
        }
        if (i4 != 0 || mediaChunk.isMediaFormatFinal) {
            MediaFormat mediaFormat = mediaChunk.getMediaFormat();
            if (!mediaFormat.equals(this.downstreamMediaFormat)) {
                mediaFormatHolder.format = mediaFormat;
                mediaFormatHolder.drmInitData = mediaChunk.getDrmInitData();
                this.downstreamMediaFormat = mediaFormat;
                return -4;
            }
        }
        if (i4 == 0) {
            return this.loadingFinished ? -1 : -2;
        } else {
            if (!this.sampleQueue.getSample(sampleHolder)) {
                return -2;
            }
            if (sampleHolder.timeUs >= this.lastSeekPositionUs) {
                i3 = 0;
            }
            int i5 = sampleHolder.flags;
            if (i3 != 0) {
                i2 = C1893C.SAMPLE_FLAG_DECODE_ONLY;
            }
            sampleHolder.flags = i5 | i2;
            onSampleRead(mediaChunk, sampleHolder);
            return -3;
        }
    }

    public void seekToUs(long j) {
        boolean z = false;
        Assertions.checkState(this.state == 3);
        long j2 = isPendingReset() ? this.pendingResetPositionUs : this.downstreamPositionUs;
        this.downstreamPositionUs = j;
        this.lastSeekPositionUs = j;
        if (j2 != j) {
            boolean z2 = !isPendingReset() && this.sampleQueue.skipToKeyframeBefore(j);
            if (z2) {
                if (!this.sampleQueue.isEmpty()) {
                    z = true;
                }
                while (z && this.mediaChunks.size() > 1 && ((BaseMediaChunk) this.mediaChunks.get(1)).getFirstSampleIndex() <= this.sampleQueue.getReadIndex()) {
                    this.mediaChunks.removeFirst();
                }
            } else {
                restartFrom(j);
            }
            this.pendingDiscontinuity = true;
        }
    }

    public void maybeThrowError() throws IOException {
        if (this.currentLoadableException != null && this.currentLoadableExceptionCount > this.minLoadableRetryCount) {
            throw this.currentLoadableException;
        } else if (this.currentLoadableHolder.chunk == null) {
            this.chunkSource.maybeThrowError();
        }
    }

    public long getBufferedPositionUs() {
        Assertions.checkState(this.state == 3);
        if (isPendingReset()) {
            return this.pendingResetPositionUs;
        }
        if (this.loadingFinished) {
            return -3;
        }
        long largestParsedTimestampUs = this.sampleQueue.getLargestParsedTimestampUs();
        return largestParsedTimestampUs == Long.MIN_VALUE ? this.downstreamPositionUs : largestParsedTimestampUs;
    }

    public void release() {
        Assertions.checkState(this.state != 3);
        if (this.loader != null) {
            this.loader.release();
            this.loader = null;
        }
        this.state = 0;
    }

    public void onLoadCompleted(Loadable loadable) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j = elapsedRealtime - this.currentLoadStartTimeMs;
        Chunk chunk = this.currentLoadableHolder.chunk;
        this.chunkSource.onChunkLoadCompleted(chunk);
        if (isMediaChunk(chunk)) {
            BaseMediaChunk baseMediaChunk = (BaseMediaChunk) chunk;
            notifyLoadCompleted(chunk.bytesLoaded(), baseMediaChunk.type, baseMediaChunk.trigger, baseMediaChunk.format, baseMediaChunk.startTimeUs, baseMediaChunk.endTimeUs, elapsedRealtime, j);
        } else {
            notifyLoadCompleted(chunk.bytesLoaded(), chunk.type, chunk.trigger, chunk.format, -1, -1, elapsedRealtime, j);
        }
        clearCurrentLoadable();
        updateLoadControl();
    }

    public void onLoadCanceled(Loadable loadable) {
        notifyLoadCanceled(this.currentLoadableHolder.chunk.bytesLoaded());
        clearCurrentLoadable();
        if (this.state == 3) {
            restartFrom(this.pendingResetPositionUs);
            return;
        }
        this.sampleQueue.clear();
        this.mediaChunks.clear();
        clearCurrentLoadable();
        this.loadControl.trimAllocator();
    }

    public void onLoadError(Loadable loadable, IOException iOException) {
        this.currentLoadableException = iOException;
        this.currentLoadableExceptionCount++;
        this.currentLoadableExceptionTimestamp = SystemClock.elapsedRealtime();
        notifyLoadError(iOException);
        this.chunkSource.onChunkLoadError(this.currentLoadableHolder.chunk, iOException);
        updateLoadControl();
    }

    protected void onSampleRead(MediaChunk mediaChunk, SampleHolder sampleHolder) {
    }

    private void restartFrom(long j) {
        this.pendingResetPositionUs = j;
        this.loadingFinished = false;
        if (this.loader.isLoading()) {
            this.loader.cancelLoading();
            return;
        }
        this.sampleQueue.clear();
        this.mediaChunks.clear();
        clearCurrentLoadable();
        updateLoadControl();
    }

    private void clearCurrentLoadable() {
        this.currentLoadableHolder.chunk = null;
        clearCurrentLoadableException();
    }

    private void clearCurrentLoadableException() {
        this.currentLoadableException = null;
        this.currentLoadableExceptionCount = 0;
    }

    private void updateLoadControl() {
        boolean z;
        boolean discardUpstreamMediaChunks;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long nextLoadPositionUs = getNextLoadPositionUs();
        Object obj = this.currentLoadableException != null ? 1 : null;
        if (this.loader.isLoading() || obj != null) {
            z = true;
        } else {
            z = false;
        }
        if (!z && ((this.currentLoadableHolder.chunk == null && nextLoadPositionUs != -1) || elapsedRealtime - this.lastPerformedBufferOperation > 2000)) {
            this.lastPerformedBufferOperation = elapsedRealtime;
            doChunkOperation();
            discardUpstreamMediaChunks = discardUpstreamMediaChunks(this.currentLoadableHolder.queueSize);
            if (this.currentLoadableHolder.chunk == null) {
                nextLoadPositionUs = -1;
            } else if (discardUpstreamMediaChunks) {
                nextLoadPositionUs = getNextLoadPositionUs();
            }
        }
        discardUpstreamMediaChunks = this.loadControl.update(this, this.downstreamPositionUs, nextLoadPositionUs, z);
        if (obj != null) {
            if (elapsedRealtime - this.currentLoadableExceptionTimestamp >= getRetryDelayMillis((long) this.currentLoadableExceptionCount)) {
                resumeFromBackOff();
            }
        } else if (!this.loader.isLoading() && discardUpstreamMediaChunks) {
            maybeStartLoading();
        }
    }

    private long getNextLoadPositionUs() {
        if (isPendingReset()) {
            return this.pendingResetPositionUs;
        }
        return this.loadingFinished ? -1 : ((BaseMediaChunk) this.mediaChunks.getLast()).endTimeUs;
    }

    private void resumeFromBackOff() {
        this.currentLoadableException = null;
        Chunk chunk = this.currentLoadableHolder.chunk;
        if (!isMediaChunk(chunk)) {
            doChunkOperation();
            discardUpstreamMediaChunks(this.currentLoadableHolder.queueSize);
            if (this.currentLoadableHolder.chunk == chunk) {
                this.loader.startLoading(chunk, this);
                return;
            }
            notifyLoadCanceled(chunk.bytesLoaded());
            maybeStartLoading();
        } else if (chunk == this.mediaChunks.getFirst()) {
            this.loader.startLoading(chunk, this);
        } else {
            Chunk chunk2 = (BaseMediaChunk) this.mediaChunks.removeLast();
            Assertions.checkState(chunk == chunk2);
            doChunkOperation();
            this.mediaChunks.add(chunk2);
            if (this.currentLoadableHolder.chunk == chunk) {
                this.loader.startLoading(chunk, this);
                return;
            }
            notifyLoadCanceled(chunk.bytesLoaded());
            discardUpstreamMediaChunks(this.currentLoadableHolder.queueSize);
            clearCurrentLoadableException();
            maybeStartLoading();
        }
    }

    private void maybeStartLoading() {
        Chunk chunk = this.currentLoadableHolder.chunk;
        if (chunk != null) {
            this.currentLoadStartTimeMs = SystemClock.elapsedRealtime();
            if (isMediaChunk(chunk)) {
                BaseMediaChunk baseMediaChunk = (BaseMediaChunk) chunk;
                baseMediaChunk.init(this.sampleQueue);
                this.mediaChunks.add(baseMediaChunk);
                if (isPendingReset()) {
                    this.pendingResetPositionUs = Long.MIN_VALUE;
                }
                notifyLoadStarted(baseMediaChunk.dataSpec.length, baseMediaChunk.type, baseMediaChunk.trigger, baseMediaChunk.format, baseMediaChunk.startTimeUs, baseMediaChunk.endTimeUs);
            } else {
                notifyLoadStarted(chunk.dataSpec.length, chunk.type, chunk.trigger, chunk.format, -1, -1);
            }
            this.loader.startLoading(chunk, this);
        }
    }

    private void doChunkOperation() {
        this.currentLoadableHolder.endOfStream = false;
        this.currentLoadableHolder.queueSize = this.readOnlyMediaChunks.size();
        this.chunkSource.getChunkOperation(this.readOnlyMediaChunks, this.pendingResetPositionUs != Long.MIN_VALUE ? this.pendingResetPositionUs : this.downstreamPositionUs, this.currentLoadableHolder);
        this.loadingFinished = this.currentLoadableHolder.endOfStream;
    }

    private boolean discardUpstreamMediaChunks(int i) {
        if (this.mediaChunks.size() <= i) {
            return false;
        }
        long j = 0;
        long j2 = ((BaseMediaChunk) this.mediaChunks.getLast()).endTimeUs;
        BaseMediaChunk baseMediaChunk = null;
        while (this.mediaChunks.size() > i) {
            baseMediaChunk = (BaseMediaChunk) this.mediaChunks.removeLast();
            j = baseMediaChunk.startTimeUs;
        }
        this.sampleQueue.discardUpstreamSamples(baseMediaChunk.getFirstSampleIndex());
        notifyUpstreamDiscarded(j, j2);
        return true;
    }

    private boolean isMediaChunk(Chunk chunk) {
        return chunk instanceof BaseMediaChunk;
    }

    private boolean isPendingReset() {
        return this.pendingResetPositionUs != Long.MIN_VALUE;
    }

    private long getRetryDelayMillis(long j) {
        return Math.min((j - 1) * 1000, HlsChunkSource.DEFAULT_MIN_BUFFER_TO_SWITCH_UP_MS);
    }

    protected final long usToMs(long j) {
        return j / 1000;
    }

    private void notifyLoadStarted(long j, int i, int i2, Format format, long j2, long j3) {
        if (this.eventHandler != null && this.eventListener != null) {
            final long j4 = j;
            final int i3 = i;
            final int i4 = i2;
            final Format format2 = format;
            final long j5 = j2;
            final long j6 = j3;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onLoadStarted(ChunkSampleSource.this.eventSourceId, j4, i3, i4, format2, ChunkSampleSource.this.usToMs(j5), ChunkSampleSource.this.usToMs(j6));
                }
            });
        }
    }

    private void notifyLoadCompleted(long j, int i, int i2, Format format, long j2, long j3, long j4, long j5) {
        if (this.eventHandler != null && this.eventListener != null) {
            final long j6 = j;
            final int i3 = i;
            final int i4 = i2;
            final Format format2 = format;
            final long j7 = j2;
            final long j8 = j3;
            final long j9 = j4;
            final long j10 = j5;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onLoadCompleted(ChunkSampleSource.this.eventSourceId, j6, i3, i4, format2, ChunkSampleSource.this.usToMs(j7), ChunkSampleSource.this.usToMs(j8), j9, j10);
                }
            });
        }
    }

    private void notifyLoadCanceled(final long j) {
        if (this.eventHandler != null && this.eventListener != null) {
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onLoadCanceled(ChunkSampleSource.this.eventSourceId, j);
                }
            });
        }
    }

    private void notifyLoadError(final IOException iOException) {
        if (this.eventHandler != null && this.eventListener != null) {
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onLoadError(ChunkSampleSource.this.eventSourceId, iOException);
                }
            });
        }
    }

    private void notifyUpstreamDiscarded(long j, long j2) {
        if (this.eventHandler != null && this.eventListener != null) {
            final long j3 = j;
            final long j4 = j2;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onUpstreamDiscarded(ChunkSampleSource.this.eventSourceId, ChunkSampleSource.this.usToMs(j3), ChunkSampleSource.this.usToMs(j4));
                }
            });
        }
    }

    private void notifyDownstreamFormatChanged(Format format, int i, long j) {
        if (this.eventHandler != null && this.eventListener != null) {
            final Format format2 = format;
            final int i2 = i;
            final long j2 = j;
            this.eventHandler.post(new Runnable() {
                public void run() {
                    ChunkSampleSource.this.eventListener.onDownstreamFormatChanged(ChunkSampleSource.this.eventSourceId, format2, i2, ChunkSampleSource.this.usToMs(j2));
                }
            });
        }
    }
}
