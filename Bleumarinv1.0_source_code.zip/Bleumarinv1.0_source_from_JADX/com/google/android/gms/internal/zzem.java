package com.google.android.gms.internal;

import java.util.List;

public interface zzem {
    void cancel();

    zzes zzc(List<zzen> list);
}
