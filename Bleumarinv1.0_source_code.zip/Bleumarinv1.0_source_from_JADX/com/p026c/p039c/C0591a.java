package com.p026c.p039c;

import android.view.View;
import com.p026c.p039c.p040a.C0590a;

/* compiled from: ViewHelper */
public final class C0591a {
    public static float m1351a(View view) {
        if (C0590a.f1557a) {
            return C0590a.m1344a(view).f1570m;
        }
        return view.getTranslationY();
    }

    public static void m1352a(View view, float f) {
        if (C0590a.f1557a) {
            C0590a.m1344a(view).m1350b(f);
        } else {
            view.setTranslationY(f);
        }
    }
}
