package com.p026c.p038b;

/* compiled from: Property */
public abstract class C0569c<T, V> {
    public final String f1521a;
    private final Class<V> f1522b;

    public abstract V mo1673a(T t);

    public C0569c(Class<V> cls, String str) {
        this.f1521a = str;
        this.f1522b = cls;
    }

    public void mo1672a(T t, V v) {
        throw new UnsupportedOperationException("Property " + this.f1521a + " is read-only");
    }
}
