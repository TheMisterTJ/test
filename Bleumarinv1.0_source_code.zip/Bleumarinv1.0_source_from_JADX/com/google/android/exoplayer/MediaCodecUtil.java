package com.google.android.exoplayer;

import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.media.MediaCodecInfo.CodecCapabilities;
import android.media.MediaCodecInfo.CodecProfileLevel;
import android.media.MediaCodecInfo.VideoCapabilities;
import android.media.MediaCodecList;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.Util;
import java.io.IOException;
import java.util.HashMap;

@TargetApi(16)
public final class MediaCodecUtil {
    private static final String TAG = "MediaCodecUtil";
    private static final HashMap<CodecKey, Pair<String, CodecCapabilities>> codecs = new HashMap();

    private static final class CodecKey {
        public final String mimeType;
        public final boolean secure;

        public CodecKey(String str, boolean z) {
            this.mimeType = str;
            this.secure = z;
        }

        public final int hashCode() {
            return (this.secure ? 1231 : 1237) + (((this.mimeType == null ? 0 : this.mimeType.hashCode()) + 31) * 31);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || obj.getClass() != CodecKey.class) {
                return false;
            }
            CodecKey codecKey = (CodecKey) obj;
            if (TextUtils.equals(this.mimeType, codecKey.mimeType) && this.secure == codecKey.secure) {
                return true;
            }
            return false;
        }
    }

    public static class DecoderQueryException extends IOException {
        private DecoderQueryException(Throwable th) {
            super("Failed to query underlying media codecs", th);
        }
    }

    private interface MediaCodecListCompat {
        int getCodecCount();

        MediaCodecInfo getCodecInfoAt(int i);

        boolean isSecurePlaybackSupported(String str, CodecCapabilities codecCapabilities);

        boolean secureDecodersExplicit();
    }

    private static final class MediaCodecListCompatV16 implements MediaCodecListCompat {
        private MediaCodecListCompatV16() {
        }

        public final int getCodecCount() {
            return MediaCodecList.getCodecCount();
        }

        public final MediaCodecInfo getCodecInfoAt(int i) {
            return MediaCodecList.getCodecInfoAt(i);
        }

        public final boolean secureDecodersExplicit() {
            return false;
        }

        public final boolean isSecurePlaybackSupported(String str, CodecCapabilities codecCapabilities) {
            return MimeTypes.VIDEO_H264.equals(str);
        }
    }

    @TargetApi(21)
    private static final class MediaCodecListCompatV21 implements MediaCodecListCompat {
        private final int codecKind;
        private MediaCodecInfo[] mediaCodecInfos;

        public MediaCodecListCompatV21(boolean z) {
            this.codecKind = z ? 1 : 0;
        }

        public final int getCodecCount() {
            ensureMediaCodecInfosInitialized();
            return this.mediaCodecInfos.length;
        }

        public final MediaCodecInfo getCodecInfoAt(int i) {
            ensureMediaCodecInfosInitialized();
            return this.mediaCodecInfos[i];
        }

        public final boolean secureDecodersExplicit() {
            return true;
        }

        public final boolean isSecurePlaybackSupported(String str, CodecCapabilities codecCapabilities) {
            return codecCapabilities.isFeatureSupported("secure-playback");
        }

        private void ensureMediaCodecInfosInitialized() {
            if (this.mediaCodecInfos == null) {
                this.mediaCodecInfos = new MediaCodecList(this.codecKind).getCodecInfos();
            }
        }
    }

    private MediaCodecUtil() {
    }

    public static DecoderInfo getDecoderInfo(String str, boolean z) throws DecoderQueryException {
        Pair mediaCodecInfo = getMediaCodecInfo(str, z);
        if (mediaCodecInfo == null) {
            return null;
        }
        return new DecoderInfo((String) mediaCodecInfo.first, isAdaptive((CodecCapabilities) mediaCodecInfo.second));
    }

    public static synchronized void warmCodec(String str, boolean z) {
        synchronized (MediaCodecUtil.class) {
            try {
                getMediaCodecInfo(str, z);
            } catch (Throwable e) {
                Log.e(TAG, "Codec warming failed", e);
            }
        }
    }

    public static synchronized Pair<String, CodecCapabilities> getMediaCodecInfo(String str, boolean z) throws DecoderQueryException {
        Pair<String, CodecCapabilities> pair;
        synchronized (MediaCodecUtil.class) {
            CodecKey codecKey = new CodecKey(str, z);
            if (codecs.containsKey(codecKey)) {
                pair = (Pair) codecs.get(codecKey);
            } else {
                pair = getMediaCodecInfo(codecKey, Util.SDK_INT >= 21 ? new MediaCodecListCompatV21(z) : new MediaCodecListCompatV16());
                if (z && pair == null && 21 <= Util.SDK_INT && Util.SDK_INT <= 23) {
                    Pair<String, CodecCapabilities> mediaCodecInfo = getMediaCodecInfo(codecKey, new MediaCodecListCompatV16());
                    if (mediaCodecInfo != null) {
                        Log.w(TAG, "MediaCodecList API didn't list secure decoder for: " + str + ". Assuming: " + ((String) mediaCodecInfo.first));
                    }
                    pair = mediaCodecInfo;
                }
            }
        }
        return pair;
    }

    private static Pair<String, CodecCapabilities> getMediaCodecInfo(CodecKey codecKey, MediaCodecListCompat mediaCodecListCompat) throws DecoderQueryException {
        try {
            return getMediaCodecInfoInternal(codecKey, mediaCodecListCompat);
        } catch (Throwable e) {
            throw new DecoderQueryException(e);
        }
    }

    private static Pair<String, CodecCapabilities> getMediaCodecInfoInternal(CodecKey codecKey, MediaCodecListCompat mediaCodecListCompat) {
        String str = codecKey.mimeType;
        int codecCount = mediaCodecListCompat.getCodecCount();
        boolean secureDecodersExplicit = mediaCodecListCompat.secureDecodersExplicit();
        for (int i = 0; i < codecCount; i++) {
            MediaCodecInfo codecInfoAt = mediaCodecListCompat.getCodecInfoAt(i);
            String name = codecInfoAt.getName();
            if (isCodecUsableDecoder(codecInfoAt, name, secureDecodersExplicit)) {
                String[] supportedTypes = codecInfoAt.getSupportedTypes();
                for (String str2 : supportedTypes) {
                    if (str2.equalsIgnoreCase(str)) {
                        CodecCapabilities capabilitiesForType = codecInfoAt.getCapabilitiesForType(str2);
                        boolean isSecurePlaybackSupported = mediaCodecListCompat.isSecurePlaybackSupported(codecKey.mimeType, capabilitiesForType);
                        if (secureDecodersExplicit) {
                            codecs.put(codecKey.secure == isSecurePlaybackSupported ? codecKey : new CodecKey(str, isSecurePlaybackSupported), Pair.create(name, capabilitiesForType));
                        } else {
                            Object codecKey2;
                            HashMap hashMap = codecs;
                            if (codecKey.secure) {
                                codecKey2 = new CodecKey(str, false);
                            } else {
                                CodecKey codecKey3 = codecKey;
                            }
                            hashMap.put(codecKey2, Pair.create(name, capabilitiesForType));
                            if (isSecurePlaybackSupported) {
                                codecs.put(codecKey.secure ? codecKey : new CodecKey(str, true), Pair.create(name + ".secure", capabilitiesForType));
                            }
                        }
                        if (codecs.containsKey(codecKey)) {
                            return (Pair) codecs.get(codecKey);
                        }
                    }
                }
                continue;
            }
        }
        return null;
    }

    private static boolean isCodecUsableDecoder(MediaCodecInfo mediaCodecInfo, String str, boolean z) {
        if (mediaCodecInfo.isEncoder()) {
            return false;
        }
        if (!z && str.endsWith(".secure")) {
            return false;
        }
        if ((Util.SDK_INT < 21 && "CIPAACDecoder".equals(str)) || "CIPMP3Decoder".equals(str) || "CIPVorbisDecoder".equals(str) || "AACDecoder".equals(str) || "MP3Decoder".equals(str)) {
            return false;
        }
        if (Util.SDK_INT == 16 && "OMX.SEC.MP3.Decoder".equals(str)) {
            return false;
        }
        if (Util.SDK_INT == 16 && "OMX.qcom.audio.decoder.mp3".equals(str) && ("dlxu".equals(Util.DEVICE) || "protou".equals(Util.DEVICE) || "C6602".equals(Util.DEVICE) || "C6603".equals(Util.DEVICE) || "C6606".equals(Util.DEVICE) || "C6616".equals(Util.DEVICE) || "L36h".equals(Util.DEVICE) || "SO-02E".equals(Util.DEVICE))) {
            return false;
        }
        if (Util.SDK_INT == 16 && "OMX.qcom.audio.decoder.aac".equals(str) && ("C1504".equals(Util.DEVICE) || "C1505".equals(Util.DEVICE) || "C1604".equals(Util.DEVICE) || "C1605".equals(Util.DEVICE))) {
            return false;
        }
        if (Util.SDK_INT > 19 || Util.DEVICE == null || ((!Util.DEVICE.startsWith("d2") && !Util.DEVICE.startsWith("serrano")) || !"samsung".equals(Util.MANUFACTURER) || !str.equals("OMX.SEC.vp8.dec"))) {
            return true;
        }
        return false;
    }

    private static boolean isAdaptive(CodecCapabilities codecCapabilities) {
        if (Util.SDK_INT >= 19) {
            return isAdaptiveV19(codecCapabilities);
        }
        return false;
    }

    @TargetApi(19)
    private static boolean isAdaptiveV19(CodecCapabilities codecCapabilities) {
        return codecCapabilities.isFeatureSupported("adaptive-playback");
    }

    @TargetApi(21)
    public static boolean isSizeSupportedV21(String str, boolean z, int i, int i2) throws DecoderQueryException {
        boolean z2;
        if (Util.SDK_INT >= 21) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        VideoCapabilities videoCapabilitiesV21 = getVideoCapabilitiesV21(str, z);
        return videoCapabilitiesV21 != null && videoCapabilitiesV21.isSizeSupported(i, i2);
    }

    @TargetApi(21)
    public static boolean isSizeAndRateSupportedV21(String str, boolean z, int i, int i2, double d) throws DecoderQueryException {
        boolean z2;
        if (Util.SDK_INT >= 21) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        VideoCapabilities videoCapabilitiesV21 = getVideoCapabilitiesV21(str, z);
        return videoCapabilitiesV21 != null && videoCapabilitiesV21.areSizeAndRateSupported(i, i2, d);
    }

    public static boolean isH264ProfileSupported(int i, int i2) throws DecoderQueryException {
        Pair mediaCodecInfo = getMediaCodecInfo(MimeTypes.VIDEO_H264, false);
        if (mediaCodecInfo == null) {
            return false;
        }
        CodecCapabilities codecCapabilities = (CodecCapabilities) mediaCodecInfo.second;
        for (CodecProfileLevel codecProfileLevel : codecCapabilities.profileLevels) {
            if (codecProfileLevel.profile == i && codecProfileLevel.level >= i2) {
                return true;
            }
        }
        return false;
    }

    public static int maxH264DecodableFrameSize() throws DecoderQueryException {
        int i = 0;
        Pair mediaCodecInfo = getMediaCodecInfo(MimeTypes.VIDEO_H264, false);
        if (mediaCodecInfo == null) {
            return 0;
        }
        CodecCapabilities codecCapabilities = (CodecCapabilities) mediaCodecInfo.second;
        int i2 = 0;
        while (i < codecCapabilities.profileLevels.length) {
            i2 = Math.max(avcLevelToMaxFrameSize(codecCapabilities.profileLevels[i].level), i2);
            i++;
        }
        return i2;
    }

    @TargetApi(21)
    private static VideoCapabilities getVideoCapabilitiesV21(String str, boolean z) throws DecoderQueryException {
        Pair mediaCodecInfo = getMediaCodecInfo(str, z);
        if (mediaCodecInfo == null) {
            return null;
        }
        return ((CodecCapabilities) mediaCodecInfo.second).getVideoCapabilities();
    }

    private static int avcLevelToMaxFrameSize(int i) {
        switch (i) {
            case 1:
            case 2:
                return 25344;
            case 8:
                return 101376;
            case 16:
                return 101376;
            case 32:
                return 101376;
            case 64:
                return 202752;
            case 128:
                return 414720;
            case 256:
                return 414720;
            case 512:
                return 921600;
            case 1024:
                return 1310720;
            case 2048:
                return 2097152;
            case 4096:
                return 2097152;
            case 8192:
                return 2228224;
            case 16384:
                return 5652480;
            case 32768:
                return 9437184;
            default:
                return -1;
        }
    }
}
