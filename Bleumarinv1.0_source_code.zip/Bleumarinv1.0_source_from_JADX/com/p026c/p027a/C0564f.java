package com.p026c.p027a;

import android.view.animation.Interpolator;

/* compiled from: Keyframe */
public abstract class C0564f implements Cloneable {
    float f1482a;
    Class f1483b;
    Interpolator f1484c = null;
    boolean f1485d = false;

    /* compiled from: Keyframe */
    static class C0565a extends C0564f {
        float f1486e;

        public final /* synthetic */ C0564f mo1660b() {
            return m1251c();
        }

        public final /* synthetic */ Object clone() throws CloneNotSupportedException {
            return m1251c();
        }

        C0565a(float f, float f2) {
            this.a = f;
            this.f1486e = f2;
            this.b = Float.TYPE;
            this.d = true;
        }

        C0565a() {
            this.a = 0.0f;
            this.b = Float.TYPE;
        }

        public final Object mo1658a() {
            return Float.valueOf(this.f1486e);
        }

        public final void mo1659a(Object obj) {
            if (obj != null && obj.getClass() == Float.class) {
                this.f1486e = ((Float) obj).floatValue();
                this.d = true;
            }
        }

        private C0565a m1251c() {
            C0564f c0565a = new C0565a(this.f1482a, this.f1486e);
            c0565a.f1484c = this.f1484c;
            return c0565a;
        }
    }

    /* compiled from: Keyframe */
    static class C0566b extends C0564f {
        Object f1487e;

        public final /* synthetic */ C0564f mo1660b() {
            return m1255c();
        }

        public final /* synthetic */ Object clone() throws CloneNotSupportedException {
            return m1255c();
        }

        C0566b(float f, Object obj) {
            this.a = f;
            this.f1487e = obj;
            this.d = obj != null;
            this.b = this.d ? obj.getClass() : Object.class;
        }

        public final Object mo1658a() {
            return this.f1487e;
        }

        public final void mo1659a(Object obj) {
            this.f1487e = obj;
            this.d = obj != null;
        }

        private C0566b m1255c() {
            C0564f c0566b = new C0566b(this.f1482a, this.f1487e);
            c0566b.f1484c = this.f1484c;
            return c0566b;
        }
    }

    public abstract Object mo1658a();

    public abstract void mo1659a(Object obj);

    public abstract C0564f mo1660b();

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return mo1660b();
    }

    public static C0564f m1247a(float f, float f2) {
        return new C0565a(f, f2);
    }
}
