package com.google.android.exoplayer.text.ttml;

import com.google.android.exoplayer.text.Cue;
import com.google.android.exoplayer.text.Subtitle;
import com.google.android.exoplayer.util.Util;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class TtmlSubtitle implements Subtitle {
    private final long[] eventTimesUs;
    private final Map<String, TtmlStyle> globalStyles;
    private final TtmlNode root;

    public TtmlSubtitle(TtmlNode ttmlNode, Map<String, TtmlStyle> map) {
        this.root = ttmlNode;
        this.globalStyles = map != null ? Collections.unmodifiableMap(map) : Collections.emptyMap();
        this.eventTimesUs = ttmlNode.getEventTimesUs();
    }

    public final int getNextEventTimeIndex(long j) {
        int binarySearchCeil = Util.binarySearchCeil(this.eventTimesUs, j, false, false);
        return binarySearchCeil < this.eventTimesUs.length ? binarySearchCeil : -1;
    }

    public final int getEventTimeCount() {
        return this.eventTimesUs.length;
    }

    public final long getEventTime(int i) {
        return this.eventTimesUs[i];
    }

    public final long getLastEventTime() {
        return this.eventTimesUs.length == 0 ? -1 : this.eventTimesUs[this.eventTimesUs.length - 1];
    }

    final TtmlNode getRoot() {
        return this.root;
    }

    public final List<Cue> getCues(long j) {
        CharSequence text = this.root.getText(j, this.globalStyles);
        if (text == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(new Cue(text));
    }

    final Map<String, TtmlStyle> getGlobalStyles() {
        return this.globalStyles;
    }
}
