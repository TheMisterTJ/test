package com.p026c.p027a;

/* compiled from: IntEvaluator */
public final class C0563e implements C0559k<Integer> {
    public final /* synthetic */ Object mo1654a(float f, Object obj, Object obj2) {
        Integer num = (Integer) obj2;
        int intValue = ((Integer) obj).intValue();
        return Integer.valueOf((int) ((((float) (num.intValue() - intValue)) * f) + ((float) intValue)));
    }
}
