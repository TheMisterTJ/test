package com.google.android.exoplayer.dash.mpd;

import com.google.android.exoplayer.dash.DashSegmentIndex;

final class DashSingleSegmentIndex implements DashSegmentIndex {
    private final RangedUri uri;

    public DashSingleSegmentIndex(RangedUri rangedUri) {
        this.uri = rangedUri;
    }

    public final int getSegmentNum(long j, long j2) {
        return 0;
    }

    public final long getTimeUs(int i) {
        return 0;
    }

    public final long getDurationUs(int i, long j) {
        return j;
    }

    public final RangedUri getSegmentUrl(int i) {
        return this.uri;
    }

    public final int getFirstSegmentNum() {
        return 0;
    }

    public final int getLastSegmentNum(long j) {
        return 0;
    }

    public final boolean isExplicit() {
        return true;
    }
}
