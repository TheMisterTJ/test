package com.p026c.p038b;

/* compiled from: FloatProperty */
public abstract class C0570a<T> extends C0569c<T, Float> {
    public abstract void mo1674a(T t, float f);

    public final /* synthetic */ void mo1672a(Object obj, Object obj2) {
        mo1674a(obj, ((Float) obj2).floatValue());
    }

    public C0570a(String str) {
        super(Float.class, str);
    }
}
