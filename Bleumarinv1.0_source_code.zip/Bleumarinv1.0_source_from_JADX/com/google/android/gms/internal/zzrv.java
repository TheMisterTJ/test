package com.google.android.gms.internal;

import java.io.IOException;
import java.io.InputStream;

public interface zzrv {
    void close();

    InputStream zzgI(String str) throws IOException;
}
