package com.google.android.exoplayer.upstream.cache;

import android.os.ConditionVariable;
import com.google.android.exoplayer.upstream.cache.Cache.Listener;
import com.google.android.exoplayer.util.Assertions;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

public final class SimpleCache implements Cache {
    private final File cacheDir;
    private final HashMap<String, TreeSet<CacheSpan>> cachedSpans;
    private final CacheEvictor evictor;
    private final HashMap<String, ArrayList<Listener>> listeners;
    private final HashMap<String, CacheSpan> lockedSpans;
    private long totalSpace = 0;

    public SimpleCache(File file, CacheEvictor cacheEvictor) {
        this.cacheDir = file;
        this.evictor = cacheEvictor;
        this.lockedSpans = new HashMap();
        this.cachedSpans = new HashMap();
        this.listeners = new HashMap();
        final ConditionVariable conditionVariable = new ConditionVariable();
        new Thread() {
            public void run() {
                synchronized (SimpleCache.this) {
                    conditionVariable.open();
                    SimpleCache.this.initialize();
                }
            }
        }.start();
        conditionVariable.block();
    }

    public final synchronized NavigableSet<CacheSpan> addListener(String str, Listener listener) {
        ArrayList arrayList = (ArrayList) this.listeners.get(str);
        if (arrayList == null) {
            arrayList = new ArrayList();
            this.listeners.put(str, arrayList);
        }
        arrayList.add(listener);
        return getCachedSpans(str);
    }

    public final synchronized void removeListener(String str, Listener listener) {
        ArrayList arrayList = (ArrayList) this.listeners.get(str);
        if (arrayList != null) {
            arrayList.remove(listener);
            if (arrayList.isEmpty()) {
                this.listeners.remove(str);
            }
        }
    }

    public final synchronized NavigableSet<CacheSpan> getCachedSpans(String str) {
        NavigableSet<CacheSpan> navigableSet;
        TreeSet treeSet = (TreeSet) this.cachedSpans.get(str);
        if (treeSet == null) {
            navigableSet = null;
        } else {
            Object treeSet2 = new TreeSet(treeSet);
        }
        return navigableSet;
    }

    public final synchronized Set<String> getKeys() {
        return new HashSet(this.cachedSpans.keySet());
    }

    public final synchronized long getCacheSpace() {
        return this.totalSpace;
    }

    public final synchronized CacheSpan startReadWrite(String str, long j) throws InterruptedException {
        CacheSpan startReadWriteNonBlocking;
        CacheSpan createLookup = CacheSpan.createLookup(str, j);
        while (true) {
            startReadWriteNonBlocking = startReadWriteNonBlocking(createLookup);
            if (startReadWriteNonBlocking == null) {
                wait();
            }
        }
        return startReadWriteNonBlocking;
    }

    public final synchronized CacheSpan startReadWriteNonBlocking(String str, long j) {
        return startReadWriteNonBlocking(CacheSpan.createLookup(str, j));
    }

    private synchronized CacheSpan startReadWriteNonBlocking(CacheSpan cacheSpan) {
        CacheSpan cacheSpan2;
        CacheSpan span = getSpan(cacheSpan);
        if (span.isCached) {
            TreeSet treeSet = (TreeSet) this.cachedSpans.get(span.key);
            Assertions.checkState(treeSet.remove(span));
            CacheSpan touch = span.touch();
            treeSet.add(touch);
            notifySpanTouched(span, touch);
            cacheSpan2 = touch;
        } else if (this.lockedSpans.containsKey(cacheSpan.key)) {
            cacheSpan2 = null;
        } else {
            this.lockedSpans.put(cacheSpan.key, span);
            cacheSpan2 = span;
        }
        return cacheSpan2;
    }

    public final synchronized File startFile(String str, long j, long j2) {
        Assertions.checkState(this.lockedSpans.containsKey(str));
        if (!this.cacheDir.exists()) {
            removeStaleSpans();
            this.cacheDir.mkdirs();
        }
        this.evictor.onStartFile(this, str, j, j2);
        return CacheSpan.getCacheFileName(this.cacheDir, str, j, System.currentTimeMillis());
    }

    public final synchronized void commitFile(File file) {
        CacheSpan createCacheEntry = CacheSpan.createCacheEntry(file);
        Assertions.checkState(createCacheEntry != null);
        Assertions.checkState(this.lockedSpans.containsKey(createCacheEntry.key));
        if (file.exists()) {
            if (file.length() == 0) {
                file.delete();
            } else {
                addSpan(createCacheEntry);
                notifyAll();
            }
        }
    }

    public final synchronized void releaseHoleSpan(CacheSpan cacheSpan) {
        Assertions.checkState(cacheSpan == this.lockedSpans.remove(cacheSpan.key));
        notifyAll();
    }

    private CacheSpan getSpan(CacheSpan cacheSpan) {
        String str;
        TreeSet treeSet;
        CacheSpan cacheSpan2;
        while (true) {
            str = cacheSpan.key;
            long j = cacheSpan.position;
            treeSet = (TreeSet) this.cachedSpans.get(str);
            if (treeSet == null) {
                return CacheSpan.createOpenHole(str, cacheSpan.position);
            }
            CacheSpan cacheSpan3 = (CacheSpan) treeSet.floor(cacheSpan);
            if (cacheSpan3 == null || cacheSpan3.position > j || j >= cacheSpan3.position + cacheSpan3.length) {
                cacheSpan2 = (CacheSpan) treeSet.ceiling(cacheSpan);
            } else if (cacheSpan3.file.exists()) {
                return cacheSpan3;
            } else {
                removeStaleSpans();
            }
        }
        cacheSpan2 = (CacheSpan) treeSet.ceiling(cacheSpan);
        return cacheSpan2 == null ? CacheSpan.createOpenHole(str, cacheSpan.position) : CacheSpan.createClosedHole(str, cacheSpan.position, cacheSpan2.position - cacheSpan.position);
    }

    private void initialize() {
        if (!this.cacheDir.exists()) {
            this.cacheDir.mkdirs();
        }
        File[] listFiles = this.cacheDir.listFiles();
        if (listFiles != null) {
            for (File file : listFiles) {
                if (file.length() == 0) {
                    file.delete();
                } else {
                    CacheSpan createCacheEntry = CacheSpan.createCacheEntry(file);
                    if (createCacheEntry == null) {
                        file.delete();
                    } else {
                        addSpan(createCacheEntry);
                    }
                }
            }
        }
    }

    private void addSpan(CacheSpan cacheSpan) {
        TreeSet treeSet = (TreeSet) this.cachedSpans.get(cacheSpan.key);
        if (treeSet == null) {
            treeSet = new TreeSet();
            this.cachedSpans.put(cacheSpan.key, treeSet);
        }
        treeSet.add(cacheSpan);
        this.totalSpace += cacheSpan.length;
        notifySpanAdded(cacheSpan);
    }

    public final synchronized void removeSpan(CacheSpan cacheSpan) {
        TreeSet treeSet = (TreeSet) this.cachedSpans.get(cacheSpan.key);
        this.totalSpace -= cacheSpan.length;
        Assertions.checkState(treeSet.remove(cacheSpan));
        cacheSpan.file.delete();
        if (treeSet.isEmpty()) {
            this.cachedSpans.remove(cacheSpan.key);
        }
        notifySpanRemoved(cacheSpan);
    }

    private void removeStaleSpans() {
        Iterator it = this.cachedSpans.entrySet().iterator();
        while (it.hasNext()) {
            Iterator it2 = ((TreeSet) ((Entry) it.next()).getValue()).iterator();
            Object obj = 1;
            while (it2.hasNext()) {
                CacheSpan cacheSpan = (CacheSpan) it2.next();
                if (cacheSpan.file.exists()) {
                    obj = null;
                } else {
                    it2.remove();
                    if (cacheSpan.isCached) {
                        this.totalSpace -= cacheSpan.length;
                    }
                    notifySpanRemoved(cacheSpan);
                }
            }
            if (obj != null) {
                it.remove();
            }
        }
    }

    private void notifySpanRemoved(CacheSpan cacheSpan) {
        ArrayList arrayList = (ArrayList) this.listeners.get(cacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanRemoved(this, cacheSpan);
            }
        }
        this.evictor.onSpanRemoved(this, cacheSpan);
    }

    private void notifySpanAdded(CacheSpan cacheSpan) {
        ArrayList arrayList = (ArrayList) this.listeners.get(cacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanAdded(this, cacheSpan);
            }
        }
        this.evictor.onSpanAdded(this, cacheSpan);
    }

    private void notifySpanTouched(CacheSpan cacheSpan, CacheSpan cacheSpan2) {
        ArrayList arrayList = (ArrayList) this.listeners.get(cacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanTouched(this, cacheSpan, cacheSpan2);
            }
        }
        this.evictor.onSpanTouched(this, cacheSpan, cacheSpan2);
    }

    public final synchronized boolean isCached(String str, long j, long j2) {
        boolean z;
        TreeSet treeSet = (TreeSet) this.cachedSpans.get(str);
        if (treeSet == null) {
            z = false;
        } else {
            CacheSpan cacheSpan = (CacheSpan) treeSet.floor(CacheSpan.createLookup(str, j));
            if (cacheSpan == null || cacheSpan.position + cacheSpan.length <= j) {
                z = false;
            } else {
                long j3 = j + j2;
                long j4 = cacheSpan.position + cacheSpan.length;
                if (j4 >= j3) {
                    z = true;
                } else {
                    for (CacheSpan cacheSpan2 : treeSet.tailSet(cacheSpan, false)) {
                        if (cacheSpan2.position > j4) {
                            z = false;
                            break;
                        }
                        long max = Math.max(j4, cacheSpan2.length + cacheSpan2.position);
                        if (max >= j3) {
                            z = true;
                            break;
                        }
                        j4 = max;
                    }
                    z = false;
                }
            }
        }
        return z;
    }
}
