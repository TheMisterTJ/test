package com.p026c.p027a;

import java.util.ArrayList;

/* compiled from: Animator */
public abstract class C0557a implements Cloneable {
    public ArrayList<C0556a> f1471a = null;

    /* compiled from: Animator */
    public interface C0556a {
        void mo1652a(C0557a c0557a);

        void mo1653b(C0557a c0557a);
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return mo1663b();
    }

    public void mo1662a() {
    }

    public C0557a mo1663b() {
        try {
            C0557a c0557a = (C0557a) super.clone();
            if (this.f1471a != null) {
                ArrayList arrayList = this.f1471a;
                c0557a.f1471a = new ArrayList();
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    c0557a.f1471a.add(arrayList.get(i));
                }
            }
            return c0557a;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
