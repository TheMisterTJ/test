package com.p026c.p027a;

import android.view.View;
import com.p026c.p038b.C0569c;
import com.p026c.p038b.C0570a;
import com.p026c.p038b.C0573b;
import com.p026c.p039c.p040a.C0590a;

/* compiled from: PreHoneycombCompat */
final class C0581i {
    static C0569c<View, Float> f1523a = new C0570a<View>("alpha") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1561d);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1561d != f) {
                a.f1561d = f;
                View view = (View) a.f1559b.get();
                if (view != null) {
                    view.invalidate();
                }
            }
        }
    };
    static C0569c<View, Float> f1524b = new C0570a<View>("pivotX") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1562e);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (!a.f1560c || a.f1562e != f) {
                a.m1347a();
                a.f1560c = true;
                a.f1562e = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1525c = new C0570a<View>("pivotY") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1563f);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (!a.f1560c || a.f1563f != f) {
                a.m1347a();
                a.f1560c = true;
                a.f1563f = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1526d = new C0570a<View>("translationX") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1569l);
        }

        public final /* bridge */ /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a.m1344a((View) obj).m1348a(f);
        }
    };
    static C0569c<View, Float> f1527e = new C0570a<View>("translationY") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1570m);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a.m1344a((View) obj).m1350b(f);
        }
    };
    static C0569c<View, Float> f1528f = new C0570a<View>("rotation") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1566i);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1566i != f) {
                a.m1347a();
                a.f1566i = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1529g = new C0570a<View>("rotationX") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1564g);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1564g != f) {
                a.m1347a();
                a.f1564g = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1530h = new C0570a<View>("rotationY") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1565h);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1565h != f) {
                a.m1347a();
                a.f1565h = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1531i = new C0570a<View>("scaleX") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1567j);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1567j != f) {
                a.m1347a();
                a.f1567j = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Float> f1532j = new C0570a<View>("scaleY") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            return Float.valueOf(C0590a.m1344a((View) obj).f1568k);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            if (a.f1568k != f) {
                a.m1347a();
                a.f1568k = f;
                a.m1349b();
            }
        }
    };
    static C0569c<View, Integer> f1533k = new C0573b<View>("scrollX") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            int i;
            View view = (View) C0590a.m1344a((View) obj).f1559b.get();
            if (view == null) {
                i = 0;
            } else {
                i = view.getScrollX();
            }
            return Integer.valueOf(i);
        }
    };
    static C0569c<View, Integer> f1534l = new C0573b<View>("scrollY") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            int i;
            View view = (View) C0590a.m1344a((View) obj).f1559b.get();
            if (view == null) {
                i = 0;
            } else {
                i = view.getScrollY();
            }
            return Integer.valueOf(i);
        }
    };
    static C0569c<View, Float> f1535m = new C0570a<View>("x") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            float f;
            C0590a a = C0590a.m1344a((View) obj);
            View view = (View) a.f1559b.get();
            if (view == null) {
                f = 0.0f;
            } else {
                f = ((float) view.getLeft()) + a.f1569l;
            }
            return Float.valueOf(f);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            View view = (View) a.f1559b.get();
            if (view != null) {
                a.m1348a(f - ((float) view.getLeft()));
            }
        }
    };
    static C0569c<View, Float> f1536n = new C0570a<View>("y") {
        public final /* synthetic */ Object mo1673a(Object obj) {
            float f;
            C0590a a = C0590a.m1344a((View) obj);
            View view = (View) a.f1559b.get();
            if (view == null) {
                f = 0.0f;
            } else {
                f = ((float) view.getTop()) + a.f1570m;
            }
            return Float.valueOf(f);
        }

        public final /* synthetic */ void mo1674a(Object obj, float f) {
            C0590a a = C0590a.m1344a((View) obj);
            View view = (View) a.f1559b.get();
            if (view != null) {
                a.m1350b(f - ((float) view.getTop()));
            }
        }
    };
}
