package com.p026c.p038b;

/* compiled from: IntProperty */
public abstract class C0573b<T> extends C0569c<T, Integer> {
    public final /* synthetic */ void mo1672a(Object obj, Object obj2) {
        obj2 = (Integer) obj2;
        while (true) {
            obj2 = Integer.valueOf(obj2.intValue());
        }
    }

    public C0573b(String str) {
        super(Integer.class, str);
    }
}
