package com.p026c.p027a;

/* compiled from: FloatEvaluator */
public final class C0560c implements C0559k<Number> {
    public final /* synthetic */ Object mo1654a(float f, Object obj, Object obj2) {
        Number number = (Number) obj2;
        float floatValue = ((Number) obj).floatValue();
        return Float.valueOf(floatValue + ((number.floatValue() - floatValue) * f));
    }
}
