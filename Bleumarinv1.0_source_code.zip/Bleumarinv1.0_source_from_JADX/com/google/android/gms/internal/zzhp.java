package com.google.android.gms.internal;

@zzhb
public final class zzhp implements zzhm {
    public final void zzgJ() {
    }

    public final void zzgK() {
    }
}
