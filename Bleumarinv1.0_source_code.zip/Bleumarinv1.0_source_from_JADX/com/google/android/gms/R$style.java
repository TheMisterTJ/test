package com.google.android.gms;

public final class R$style {
    public static final int Theme_IAPTheme = 2131362123;
}
