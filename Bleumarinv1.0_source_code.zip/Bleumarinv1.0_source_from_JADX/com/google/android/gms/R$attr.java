package com.google.android.gms;

public final class R$attr {
    public static final int adSize = 2130772030;
    public static final int adSizes = 2130772031;
    public static final int adUnitId = 2130772032;
    public static final int buttonSize = 2130772253;
    public static final int circleCrop = 2130772196;
    public static final int colorScheme = 2130772254;
    public static final int imageAspectRatio = 2130772195;
    public static final int imageAspectRatioAdjust = 2130772194;
    public static final int scopeUris = 2130772255;
}
