package com.google.android.exoplayer.extractor;

import android.net.Uri;
import android.os.SystemClock;
import android.util.SparseArray;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.MediaFormatHolder;
import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.SampleHolder;
import com.google.android.exoplayer.SampleSource;
import com.google.android.exoplayer.SampleSource.SampleSourceReader;
import com.google.android.exoplayer.drm.DrmInitData;
import com.google.android.exoplayer.hls.HlsChunkSource;
import com.google.android.exoplayer.upstream.Allocator;
import com.google.android.exoplayer.upstream.DataSource;
import com.google.android.exoplayer.upstream.DataSpec;
import com.google.android.exoplayer.upstream.Loader;
import com.google.android.exoplayer.upstream.Loader.Callback;
import com.google.android.exoplayer.upstream.Loader.Loadable;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.Util;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class ExtractorSampleSource implements SampleSource, SampleSourceReader, ExtractorOutput, Callback {
    private static final List<Class<? extends Extractor>> DEFAULT_EXTRACTOR_CLASSES = new ArrayList();
    public static final int DEFAULT_MIN_LOADABLE_RETRY_COUNT_LIVE = 6;
    public static final int DEFAULT_MIN_LOADABLE_RETRY_COUNT_ON_DEMAND = 3;
    private static final int MIN_RETRY_COUNT_DEFAULT_FOR_MEDIA = -1;
    private static final long NO_RESET_PENDING = Long.MIN_VALUE;
    private final Allocator allocator;
    private IOException currentLoadableException;
    private int currentLoadableExceptionCount;
    private long currentLoadableExceptionTimestamp;
    private final DataSource dataSource;
    private long downstreamPositionUs;
    private volatile DrmInitData drmInitData;
    private int enabledTrackCount;
    private int extractedSampleCount;
    private int extractedSampleCountAtStartOfLoad;
    private final ExtractorHolder extractorHolder;
    private boolean havePendingNextSampleUs;
    private long lastSeekPositionUs;
    private ExtractingLoadable loadable;
    private Loader loader;
    private boolean loadingFinished;
    private long maxTrackDurationUs;
    private MediaFormat[] mediaFormats;
    private final int minLoadableRetryCount;
    private boolean[] pendingDiscontinuities;
    private boolean[] pendingMediaFormat;
    private long pendingNextSampleUs;
    private long pendingResetPositionUs;
    private boolean prepared;
    private int remainingReleaseCount;
    private final int requestedBufferSize;
    private final SparseArray<InternalTrackOutput> sampleQueues;
    private long sampleTimeOffsetUs;
    private volatile SeekMap seekMap;
    private boolean[] trackEnabledStates;
    private volatile boolean tracksBuilt;
    private final Uri uri;

    private static class ExtractingLoadable implements Loadable {
        private final Allocator allocator;
        private final DataSource dataSource;
        private final ExtractorHolder extractorHolder;
        private volatile boolean loadCanceled;
        private boolean pendingExtractorSeek;
        private final PositionHolder positionHolder = new PositionHolder();
        private final int requestedBufferSize;
        private final Uri uri;

        public ExtractingLoadable(Uri uri, DataSource dataSource, ExtractorHolder extractorHolder, Allocator allocator, int i, long j) {
            this.uri = (Uri) Assertions.checkNotNull(uri);
            this.dataSource = (DataSource) Assertions.checkNotNull(dataSource);
            this.extractorHolder = (ExtractorHolder) Assertions.checkNotNull(extractorHolder);
            this.allocator = (Allocator) Assertions.checkNotNull(allocator);
            this.requestedBufferSize = i;
            this.positionHolder.position = j;
            this.pendingExtractorSeek = true;
        }

        public void cancelLoad() {
            this.loadCanceled = true;
        }

        public boolean isLoadCanceled() {
            return this.loadCanceled;
        }

        public void load() throws IOException, InterruptedException {
            int i;
            ExtractorInput extractorInput;
            Throwable th;
            int i2 = 0;
            while (i2 == 0 && !this.loadCanceled) {
                try {
                    long j = this.positionHolder.position;
                    long open = this.dataSource.open(new DataSpec(this.uri, j, -1, null));
                    if (open != -1) {
                        open += j;
                    }
                    ExtractorInput defaultExtractorInput = new DefaultExtractorInput(this.dataSource, j, open);
                    try {
                        int i3;
                        Extractor selectExtractor = this.extractorHolder.selectExtractor(defaultExtractorInput);
                        if (this.pendingExtractorSeek) {
                            selectExtractor.seek();
                            this.pendingExtractorSeek = false;
                        }
                        int i4 = i2;
                        while (i4 == 0) {
                            try {
                                if (this.loadCanceled) {
                                    break;
                                }
                                this.allocator.blockWhileTotalBytesAllocatedExceeds(this.requestedBufferSize);
                                i4 = selectExtractor.read(defaultExtractorInput, this.positionHolder);
                            } catch (Throwable th2) {
                                Throwable th3 = th2;
                                i = i4;
                                extractorInput = defaultExtractorInput;
                                th = th3;
                            }
                        }
                        if (i4 == 1) {
                            i3 = 0;
                        } else {
                            this.positionHolder.position = defaultExtractorInput.getPosition();
                            i3 = i4;
                        }
                        this.dataSource.close();
                        i2 = i3;
                    } catch (Throwable th4) {
                        i = i2;
                        ExtractorInput extractorInput2 = defaultExtractorInput;
                        th = th4;
                        extractorInput = extractorInput2;
                    }
                } catch (Throwable th5) {
                    th = th5;
                    extractorInput = null;
                    i = i2;
                }
            }
            return;
            if (!(i == 1 || extractorInput == null)) {
                this.positionHolder.position = extractorInput.getPosition();
            }
            this.dataSource.close();
            throw th;
        }
    }

    private static final class ExtractorHolder {
        private Extractor extractor;
        private final ExtractorOutput extractorOutput;
        private final Extractor[] extractors;

        public ExtractorHolder(Extractor[] extractorArr, ExtractorOutput extractorOutput) {
            this.extractors = extractorArr;
            this.extractorOutput = extractorOutput;
        }

        public final Extractor selectExtractor(ExtractorInput extractorInput) throws UnrecognizedInputFormatException, IOException, InterruptedException {
            if (this.extractor != null) {
                return this.extractor;
            }
            Extractor[] extractorArr = this.extractors;
            int length = extractorArr.length;
            int i = 0;
            while (i < length) {
                Extractor extractor = extractorArr[i];
                try {
                    if (extractor.sniff(extractorInput)) {
                        this.extractor = extractor;
                        break;
                    }
                    extractorInput.resetPeekPosition();
                    i++;
                } catch (EOFException e) {
                }
            }
            if (this.extractor == null) {
                throw new UnrecognizedInputFormatException(this.extractors);
            }
            this.extractor.init(this.extractorOutput);
            return this.extractor;
        }
    }

    private class InternalTrackOutput extends DefaultTrackOutput {
        public InternalTrackOutput(Allocator allocator) {
            super(allocator);
        }

        public void sampleMetadata(long j, int i, int i2, int i3, byte[] bArr) {
            super.sampleMetadata(j, i, i2, i3, bArr);
            ExtractorSampleSource.this.extractedSampleCount = ExtractorSampleSource.this.extractedSampleCount + 1;
        }
    }

    public static final class UnrecognizedInputFormatException extends ParserException {
        public UnrecognizedInputFormatException(Extractor[] extractorArr) {
            super("None of the available extractors (" + Util.getCommaDelimitedSimpleClassNames(extractorArr) + ") could read the stream.");
        }
    }

    static {
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.webm.WebmExtractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.mp4.FragmentedMp4Extractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e2) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.mp4.Mp4Extractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e3) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.mp3.Mp3Extractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e4) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.ts.AdtsExtractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e5) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.ts.TsExtractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e6) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.flv.FlvExtractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e7) {
        }
        try {
            DEFAULT_EXTRACTOR_CLASSES.add(Class.forName("com.google.android.exoplayer.extractor.ts.PsExtractor").asSubclass(Extractor.class));
        } catch (ClassNotFoundException e8) {
        }
    }

    public ExtractorSampleSource(Uri uri, DataSource dataSource, Allocator allocator, int i, Extractor... extractorArr) {
        this(uri, dataSource, allocator, i, -1, extractorArr);
    }

    public ExtractorSampleSource(Uri uri, DataSource dataSource, Allocator allocator, int i, int i2, Extractor... extractorArr) {
        this.uri = uri;
        this.dataSource = dataSource;
        this.allocator = allocator;
        this.requestedBufferSize = i;
        this.minLoadableRetryCount = i2;
        if (extractorArr == null || extractorArr.length == 0) {
            extractorArr = new Extractor[DEFAULT_EXTRACTOR_CLASSES.size()];
            int i3 = 0;
            while (i3 < extractorArr.length) {
                try {
                    extractorArr[i3] = (Extractor) ((Class) DEFAULT_EXTRACTOR_CLASSES.get(i3)).newInstance();
                    i3++;
                } catch (Throwable e) {
                    throw new IllegalStateException("Unexpected error creating default extractor", e);
                } catch (Throwable e2) {
                    throw new IllegalStateException("Unexpected error creating default extractor", e2);
                }
            }
        }
        this.extractorHolder = new ExtractorHolder(extractorArr, this);
        this.sampleQueues = new SparseArray();
        this.pendingResetPositionUs = Long.MIN_VALUE;
    }

    public final SampleSourceReader register() {
        this.remainingReleaseCount++;
        return this;
    }

    public final boolean prepare(long j) {
        if (this.prepared) {
            return true;
        }
        if (this.loader == null) {
            this.loader = new Loader("Loader:ExtractorSampleSource");
        }
        maybeStartLoading();
        if (this.seekMap == null || !this.tracksBuilt || !haveFormatsForAllTracks()) {
            return false;
        }
        int size = this.sampleQueues.size();
        this.trackEnabledStates = new boolean[size];
        this.pendingDiscontinuities = new boolean[size];
        this.pendingMediaFormat = new boolean[size];
        this.mediaFormats = new MediaFormat[size];
        this.maxTrackDurationUs = -1;
        for (int i = 0; i < size; i++) {
            MediaFormat format = ((InternalTrackOutput) this.sampleQueues.valueAt(i)).getFormat();
            this.mediaFormats[i] = format;
            if (format.durationUs != -1 && format.durationUs > this.maxTrackDurationUs) {
                this.maxTrackDurationUs = format.durationUs;
            }
        }
        this.prepared = true;
        return true;
    }

    public final int getTrackCount() {
        return this.sampleQueues.size();
    }

    public final MediaFormat getFormat(int i) {
        Assertions.checkState(this.prepared);
        return this.mediaFormats[i];
    }

    public final void enable(int i, long j) {
        Assertions.checkState(this.prepared);
        Assertions.checkState(!this.trackEnabledStates[i]);
        this.enabledTrackCount++;
        this.trackEnabledStates[i] = true;
        this.pendingMediaFormat[i] = true;
        this.pendingDiscontinuities[i] = false;
        if (this.enabledTrackCount == 1) {
            if (!this.seekMap.isSeekable()) {
                j = 0;
            }
            this.downstreamPositionUs = j;
            this.lastSeekPositionUs = j;
            restartFrom(j);
        }
    }

    public final void disable(int i) {
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.trackEnabledStates[i]);
        this.enabledTrackCount--;
        this.trackEnabledStates[i] = false;
        if (this.enabledTrackCount == 0) {
            this.downstreamPositionUs = Long.MIN_VALUE;
            if (this.loader.isLoading()) {
                this.loader.cancelLoading();
                return;
            }
            clearState();
            this.allocator.trim(0);
        }
    }

    public final boolean continueBuffering(int i, long j) {
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.trackEnabledStates[i]);
        this.downstreamPositionUs = j;
        discardSamplesForDisabledTracks(this.downstreamPositionUs);
        if (this.loadingFinished) {
            return true;
        }
        maybeStartLoading();
        if (isPendingReset()) {
            return false;
        }
        return !((InternalTrackOutput) this.sampleQueues.valueAt(i)).isEmpty();
    }

    public final long readDiscontinuity(int i) {
        if (!this.pendingDiscontinuities[i]) {
            return Long.MIN_VALUE;
        }
        this.pendingDiscontinuities[i] = false;
        return this.lastSeekPositionUs;
    }

    public final int readData(int i, long j, MediaFormatHolder mediaFormatHolder, SampleHolder sampleHolder) {
        this.downstreamPositionUs = j;
        if (this.pendingDiscontinuities[i] || isPendingReset()) {
            return -2;
        }
        InternalTrackOutput internalTrackOutput = (InternalTrackOutput) this.sampleQueues.valueAt(i);
        if (this.pendingMediaFormat[i]) {
            mediaFormatHolder.format = internalTrackOutput.getFormat();
            mediaFormatHolder.drmInitData = this.drmInitData;
            this.pendingMediaFormat[i] = false;
            return -4;
        } else if (!internalTrackOutput.getSample(sampleHolder)) {
            return this.loadingFinished ? -1 : -2;
        } else {
            int i2;
            boolean z = sampleHolder.timeUs < this.lastSeekPositionUs;
            int i3 = sampleHolder.flags;
            if (z) {
                i2 = C1893C.SAMPLE_FLAG_DECODE_ONLY;
            } else {
                i2 = 0;
            }
            sampleHolder.flags = i2 | i3;
            if (this.havePendingNextSampleUs) {
                this.sampleTimeOffsetUs = this.pendingNextSampleUs - sampleHolder.timeUs;
                this.havePendingNextSampleUs = false;
            }
            sampleHolder.timeUs += this.sampleTimeOffsetUs;
            return -3;
        }
    }

    public final void maybeThrowError() throws IOException {
        if (this.currentLoadableException != null) {
            if (isCurrentLoadableExceptionFatal()) {
                throw this.currentLoadableException;
            }
            int i = this.minLoadableRetryCount != -1 ? this.minLoadableRetryCount : (this.seekMap == null || this.seekMap.isSeekable()) ? 3 : 6;
            if (this.currentLoadableExceptionCount > i) {
                throw this.currentLoadableException;
            }
        }
    }

    public final void seekToUs(long j) {
        int i = 0;
        Assertions.checkState(this.prepared);
        Assertions.checkState(this.enabledTrackCount > 0);
        if (!this.seekMap.isSeekable()) {
            j = 0;
        }
        long j2 = isPendingReset() ? this.pendingResetPositionUs : this.downstreamPositionUs;
        this.downstreamPositionUs = j;
        this.lastSeekPositionUs = j;
        if (j2 != j) {
            boolean z;
            if (isPendingReset()) {
                z = false;
            } else {
                z = true;
            }
            int i2 = 0;
            int i3 = z;
            while (i3 != 0 && i2 < this.sampleQueues.size()) {
                i3 &= ((InternalTrackOutput) this.sampleQueues.valueAt(i2)).skipToKeyframeBefore(j);
                i2++;
            }
            if (i3 == 0) {
                restartFrom(j);
            }
            while (i < this.pendingDiscontinuities.length) {
                this.pendingDiscontinuities[i] = true;
                i++;
            }
        }
    }

    public final long getBufferedPositionUs() {
        if (this.loadingFinished) {
            return -3;
        }
        if (isPendingReset()) {
            return this.pendingResetPositionUs;
        }
        long j = Long.MIN_VALUE;
        for (int i = 0; i < this.sampleQueues.size(); i++) {
            j = Math.max(j, ((InternalTrackOutput) this.sampleQueues.valueAt(i)).getLargestParsedTimestampUs());
        }
        return j == Long.MIN_VALUE ? this.downstreamPositionUs : j;
    }

    public final void release() {
        Assertions.checkState(this.remainingReleaseCount > 0);
        int i = this.remainingReleaseCount - 1;
        this.remainingReleaseCount = i;
        if (i == 0 && this.loader != null) {
            this.loader.release();
            this.loader = null;
        }
    }

    public final void onLoadCompleted(Loadable loadable) {
        this.loadingFinished = true;
    }

    public final void onLoadCanceled(Loadable loadable) {
        if (this.enabledTrackCount > 0) {
            restartFrom(this.pendingResetPositionUs);
            return;
        }
        clearState();
        this.allocator.trim(0);
    }

    public final void onLoadError(Loadable loadable, IOException iOException) {
        this.currentLoadableException = iOException;
        this.currentLoadableExceptionCount = this.extractedSampleCount > this.extractedSampleCountAtStartOfLoad ? 1 : this.currentLoadableExceptionCount + 1;
        this.currentLoadableExceptionTimestamp = SystemClock.elapsedRealtime();
        maybeStartLoading();
    }

    public final TrackOutput track(int i) {
        InternalTrackOutput internalTrackOutput = (InternalTrackOutput) this.sampleQueues.get(i);
        if (internalTrackOutput != null) {
            return internalTrackOutput;
        }
        TrackOutput internalTrackOutput2 = new InternalTrackOutput(this.allocator);
        this.sampleQueues.put(i, internalTrackOutput2);
        return internalTrackOutput2;
    }

    public final void endTracks() {
        this.tracksBuilt = true;
    }

    public final void seekMap(SeekMap seekMap) {
        this.seekMap = seekMap;
    }

    public final void drmInitData(DrmInitData drmInitData) {
        this.drmInitData = drmInitData;
    }

    private void restartFrom(long j) {
        this.pendingResetPositionUs = j;
        this.loadingFinished = false;
        if (this.loader.isLoading()) {
            this.loader.cancelLoading();
            return;
        }
        clearState();
        maybeStartLoading();
    }

    private void maybeStartLoading() {
        int i = 0;
        if (!this.loadingFinished && !this.loader.isLoading()) {
            if (this.currentLoadableException == null) {
                this.sampleTimeOffsetUs = 0;
                this.havePendingNextSampleUs = false;
                if (this.prepared) {
                    Assertions.checkState(isPendingReset());
                    if (this.maxTrackDurationUs == -1 || this.pendingResetPositionUs < this.maxTrackDurationUs) {
                        this.loadable = createLoadableFromPositionUs(this.pendingResetPositionUs);
                        this.pendingResetPositionUs = Long.MIN_VALUE;
                    } else {
                        this.loadingFinished = true;
                        this.pendingResetPositionUs = Long.MIN_VALUE;
                        return;
                    }
                }
                this.loadable = createLoadableFromStart();
                this.extractedSampleCountAtStartOfLoad = this.extractedSampleCount;
                this.loader.startLoading(this.loadable, this);
            } else if (!isCurrentLoadableExceptionFatal()) {
                Assertions.checkState(this.loadable != null);
                if (SystemClock.elapsedRealtime() - this.currentLoadableExceptionTimestamp >= getRetryDelayMillis((long) this.currentLoadableExceptionCount)) {
                    this.currentLoadableException = null;
                    if (!this.prepared) {
                        while (i < this.sampleQueues.size()) {
                            ((InternalTrackOutput) this.sampleQueues.valueAt(i)).clear();
                            i++;
                        }
                        this.loadable = createLoadableFromStart();
                    } else if (!this.seekMap.isSeekable() && this.maxTrackDurationUs == -1) {
                        while (i < this.sampleQueues.size()) {
                            ((InternalTrackOutput) this.sampleQueues.valueAt(i)).clear();
                            i++;
                        }
                        this.loadable = createLoadableFromStart();
                        this.pendingNextSampleUs = this.downstreamPositionUs;
                        this.havePendingNextSampleUs = true;
                    }
                    this.extractedSampleCountAtStartOfLoad = this.extractedSampleCount;
                    this.loader.startLoading(this.loadable, this);
                }
            }
        }
    }

    private ExtractingLoadable createLoadableFromStart() {
        return new ExtractingLoadable(this.uri, this.dataSource, this.extractorHolder, this.allocator, this.requestedBufferSize, 0);
    }

    private ExtractingLoadable createLoadableFromPositionUs(long j) {
        return new ExtractingLoadable(this.uri, this.dataSource, this.extractorHolder, this.allocator, this.requestedBufferSize, this.seekMap.getPosition(j));
    }

    private boolean haveFormatsForAllTracks() {
        for (int i = 0; i < this.sampleQueues.size(); i++) {
            if (!((InternalTrackOutput) this.sampleQueues.valueAt(i)).hasFormat()) {
                return false;
            }
        }
        return true;
    }

    private void discardSamplesForDisabledTracks(long j) {
        for (int i = 0; i < this.trackEnabledStates.length; i++) {
            if (!this.trackEnabledStates[i]) {
                ((InternalTrackOutput) this.sampleQueues.valueAt(i)).discardUntil(j);
            }
        }
    }

    private void clearState() {
        for (int i = 0; i < this.sampleQueues.size(); i++) {
            ((InternalTrackOutput) this.sampleQueues.valueAt(i)).clear();
        }
        this.loadable = null;
        this.currentLoadableException = null;
        this.currentLoadableExceptionCount = 0;
    }

    private boolean isPendingReset() {
        return this.pendingResetPositionUs != Long.MIN_VALUE;
    }

    private boolean isCurrentLoadableExceptionFatal() {
        return this.currentLoadableException instanceof UnrecognizedInputFormatException;
    }

    private long getRetryDelayMillis(long j) {
        return Math.min((j - 1) * 1000, HlsChunkSource.DEFAULT_MIN_BUFFER_TO_SWITCH_UP_MS);
    }
}
