package com.p026c.p027a;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AndroidRuntimeException;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import com.mopub.volley.DefaultRetryPolicy;
import com.p026c.p027a.C0557a.C0556a;
import java.util.ArrayList;
import java.util.HashMap;

/* compiled from: ValueAnimator */
public class C0567l extends C0557a {
    private static long f1488A = 10;
    private static ThreadLocal<C0589a> f1489b = new ThreadLocal();
    public static final ThreadLocal<ArrayList<C0567l>> f1490e = new C05852();
    public static final ThreadLocal<ArrayList<C0567l>> f1491f = new C05863();
    private static final ThreadLocal<ArrayList<C0567l>> f1492m = new C05841();
    private static final ThreadLocal<ArrayList<C0567l>> f1493n = new C05874();
    private static final ThreadLocal<ArrayList<C0567l>> f1494o = new C05885();
    private static final Interpolator f1495p = new AccelerateDecelerateInterpolator();
    private static final C0559k f1496q = new C0563e();
    private static final C0559k f1497r = new C0560c();
    private int f1498B = 0;
    private int f1499C = 1;
    private ArrayList<C0396b> f1500D = null;
    long f1501c;
    long f1502d = -1;
    public int f1503g = 0;
    public boolean f1504h = false;
    public boolean f1505i = false;
    public Interpolator f1506j = f1495p;
    C0582j[] f1507k;
    HashMap<String, C0582j> f1508l;
    private boolean f1509s = false;
    private int f1510t = 0;
    private float f1511u = 0.0f;
    private boolean f1512v = false;
    private long f1513w;
    private boolean f1514x = false;
    private long f1515y = 300;
    private long f1516z = 0;

    /* compiled from: ValueAnimator */
    public interface C0396b {
        void mo1612a(C0567l c0567l);
    }

    /* compiled from: ValueAnimator */
    static class C05841 extends ThreadLocal<ArrayList<C0567l>> {
        C05841() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new ArrayList();
        }
    }

    /* compiled from: ValueAnimator */
    static class C05852 extends ThreadLocal<ArrayList<C0567l>> {
        C05852() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new ArrayList();
        }
    }

    /* compiled from: ValueAnimator */
    static class C05863 extends ThreadLocal<ArrayList<C0567l>> {
        C05863() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new ArrayList();
        }
    }

    /* compiled from: ValueAnimator */
    static class C05874 extends ThreadLocal<ArrayList<C0567l>> {
        C05874() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new ArrayList();
        }
    }

    /* compiled from: ValueAnimator */
    static class C05885 extends ThreadLocal<ArrayList<C0567l>> {
        C05885() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new ArrayList();
        }
    }

    /* compiled from: ValueAnimator */
    private static class C0589a extends Handler {
        private C0589a() {
        }

        public final void handleMessage(Message message) {
            ArrayList arrayList;
            Object obj;
            ArrayList arrayList2;
            int size;
            int i;
            C0567l c0567l;
            ArrayList arrayList3 = (ArrayList) C0567l.f1492m.get();
            ArrayList arrayList4 = (ArrayList) C0567l.f1491f.get();
            switch (message.what) {
                case 0:
                    arrayList = (ArrayList) C0567l.f1490e.get();
                    if (arrayList3.size() > 0 || arrayList4.size() > 0) {
                        obj = null;
                    } else {
                        int i2 = 1;
                    }
                    while (arrayList.size() > 0) {
                        arrayList2 = (ArrayList) arrayList.clone();
                        arrayList.clear();
                        size = arrayList2.size();
                        for (i = 0; i < size; i++) {
                            c0567l = (C0567l) arrayList2.get(i);
                            if (c0567l.f1516z == 0) {
                                C0567l.m1263b(c0567l);
                            } else {
                                arrayList4.add(c0567l);
                            }
                        }
                    }
                    break;
                case 1:
                    obj = 1;
                    break;
                default:
                    return;
            }
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            arrayList = (ArrayList) C0567l.f1494o.get();
            arrayList2 = (ArrayList) C0567l.f1493n.get();
            size = arrayList4.size();
            for (i = 0; i < size; i++) {
                c0567l = (C0567l) arrayList4.get(i);
                if (C0567l.m1261a(c0567l, currentAnimationTimeMillis)) {
                    arrayList.add(c0567l);
                }
            }
            size = arrayList.size();
            if (size > 0) {
                for (i = 0; i < size; i++) {
                    c0567l = (C0567l) arrayList.get(i);
                    C0567l.m1263b(c0567l);
                    c0567l.f1504h = true;
                    arrayList4.remove(c0567l);
                }
                arrayList.clear();
            }
            i = 0;
            int size2 = arrayList3.size();
            while (i < size2) {
                C0567l c0567l2 = (C0567l) arrayList3.get(i);
                if (c0567l2.m1280c(currentAnimationTimeMillis)) {
                    arrayList2.add(c0567l2);
                }
                if (arrayList3.size() == size2) {
                    i++;
                } else {
                    size2--;
                    arrayList2.remove(c0567l2);
                }
            }
            if (arrayList2.size() > 0) {
                for (size2 = 0; size2 < arrayList2.size(); size2++) {
                    ((C0567l) arrayList2.get(size2)).m1283f();
                }
                arrayList2.clear();
            }
            if (obj == null) {
                return;
            }
            if (!arrayList3.isEmpty() || !arrayList4.isEmpty()) {
                sendEmptyMessageDelayed(1, Math.max(0, C0567l.f1488A - (AnimationUtils.currentAnimationTimeMillis() - currentAnimationTimeMillis)));
            }
        }
    }

    static /* synthetic */ boolean m1261a(C0567l c0567l, long j) {
        if (c0567l.f1512v) {
            long j2 = j - c0567l.f1513w;
            if (j2 > c0567l.f1516z) {
                c0567l.f1501c = j - (j2 - c0567l.f1516z);
                c0567l.f1503g = 1;
                return true;
            }
        }
        c0567l.f1512v = true;
        c0567l.f1513w = j;
        return false;
    }

    public /* synthetic */ C0557a mo1663b() {
        return mo1670d();
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return mo1670d();
    }

    public static C0567l m1262b(float... fArr) {
        C0567l c0567l = new C0567l();
        c0567l.mo1667a(fArr);
        return c0567l;
    }

    public void mo1667a(float... fArr) {
        if (fArr != null && fArr.length != 0) {
            if (this.f1507k == null || this.f1507k.length == 0) {
                m1276a(C0582j.m1326a("", fArr));
            } else {
                this.f1507k[0].mo1678a(fArr);
            }
            this.f1505i = false;
        }
    }

    public final void m1276a(C0582j... c0582jArr) {
        this.f1507k = c0582jArr;
        this.f1508l = new HashMap(r2);
        for (C0582j c0582j : c0582jArr) {
            this.f1508l.put(c0582j.f1544a, c0582j);
        }
        this.f1505i = false;
    }

    void mo1669c() {
        if (!this.f1505i) {
            for (C0582j c0582j : this.f1507k) {
                if (c0582j.f1551j == null) {
                    C0559k c0559k = c0582j.f1547d == Integer.class ? C0582j.f1537f : c0582j.f1547d == Float.class ? C0582j.f1538g : null;
                    c0582j.f1551j = c0559k;
                }
                if (c0582j.f1551j != null) {
                    c0582j.f1548e.f1477f = c0582j.f1551j;
                }
            }
            this.f1505i = true;
        }
    }

    public C0567l mo1668b(long j) {
        if (j < 0) {
            throw new IllegalArgumentException("Animators cannot have negative duration: " + j);
        }
        this.f1515y = j;
        return this;
    }

    private void mo1665a(long j) {
        mo1669c();
        long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        if (this.f1503g != 1) {
            this.f1502d = j;
            this.f1503g = 2;
        }
        this.f1501c = currentAnimationTimeMillis - j;
        m1280c(currentAnimationTimeMillis);
    }

    public final Object m1282e() {
        if (this.f1507k == null || this.f1507k.length <= 0) {
            return null;
        }
        return this.f1507k[0].mo1679b();
    }

    public final void m1274a(C0396b c0396b) {
        if (this.f1500D == null) {
            this.f1500D = new ArrayList();
        }
        this.f1500D.add(c0396b);
    }

    public void mo1662a() {
        if (Looper.myLooper() == null) {
            throw new AndroidRuntimeException("Animators may only be run on Looper threads");
        }
        this.f1509s = false;
        this.f1510t = 0;
        this.f1503g = 0;
        this.f1514x = true;
        this.f1512v = false;
        ((ArrayList) f1490e.get()).add(this);
        if (this.f1516z == 0) {
            long j;
            if (!this.f1505i || this.f1503g == 0) {
                j = 0;
            } else {
                j = AnimationUtils.currentAnimationTimeMillis() - this.f1501c;
            }
            mo1665a(j);
            this.f1503g = 0;
            this.f1504h = true;
            if (this.a != null) {
                ArrayList arrayList = (ArrayList) this.a.clone();
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    ((C0556a) arrayList.get(i)).mo1652a(this);
                }
            }
        }
        C0589a c0589a = (C0589a) f1489b.get();
        if (c0589a == null) {
            c0589a = new C0589a();
            f1489b.set(c0589a);
        }
        c0589a.sendEmptyMessage(0);
    }

    public final void m1283f() {
        ((ArrayList) f1492m.get()).remove(this);
        ((ArrayList) f1490e.get()).remove(this);
        ((ArrayList) f1491f.get()).remove(this);
        this.f1503g = 0;
        if (this.f1504h && this.a != null) {
            ArrayList arrayList = (ArrayList) this.a.clone();
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((C0556a) arrayList.get(i)).mo1653b(this);
            }
        }
        this.f1504h = false;
        this.f1514x = false;
    }

    final boolean m1280c(long j) {
        boolean z = true;
        boolean z2 = false;
        if (this.f1503g == 0) {
            this.f1503g = 1;
            if (this.f1502d < 0) {
                this.f1501c = j;
            } else {
                this.f1501c = j - this.f1502d;
                this.f1502d = -1;
            }
        }
        switch (this.f1503g) {
            case 1:
            case 2:
                float f;
                float f2 = this.f1515y > 0 ? ((float) (j - this.f1501c)) / ((float) this.f1515y) : DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
                if (f2 < DefaultRetryPolicy.DEFAULT_BACKOFF_MULT) {
                    f = f2;
                } else if (this.f1510t < this.f1498B || this.f1498B == -1) {
                    if (this.a != null) {
                        int size = this.a.size();
                        for (int i = 0; i < size; i++) {
                            this.a.get(i);
                        }
                    }
                    if (this.f1499C == 2) {
                        if (this.f1509s) {
                            z = false;
                        }
                        this.f1509s = z;
                    }
                    this.f1510t += (int) f2;
                    f = f2 % DefaultRetryPolicy.DEFAULT_BACKOFF_MULT;
                    this.f1501c += this.f1515y;
                } else {
                    f = Math.min(f2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                    z2 = true;
                }
                if (this.f1509s) {
                    f = DefaultRetryPolicy.DEFAULT_BACKOFF_MULT - f;
                }
                mo1666a(f);
                break;
        }
        return z2;
    }

    void mo1666a(float f) {
        int i;
        float interpolation = this.f1506j.getInterpolation(f);
        this.f1511u = interpolation;
        for (C0582j a : this.f1507k) {
            a.mo1676a(interpolation);
        }
        if (this.f1500D != null) {
            int size = this.f1500D.size();
            for (i = 0; i < size; i++) {
                ((C0396b) this.f1500D.get(i)).mo1612a(this);
            }
        }
    }

    public C0567l mo1670d() {
        int i = 0;
        C0567l c0567l = (C0567l) super.mo1663b();
        if (this.f1500D != null) {
            ArrayList arrayList = this.f1500D;
            c0567l.f1500D = new ArrayList();
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                c0567l.f1500D.add(arrayList.get(i2));
            }
        }
        c0567l.f1502d = -1;
        c0567l.f1509s = false;
        c0567l.f1510t = 0;
        c0567l.f1505i = false;
        c0567l.f1503g = 0;
        c0567l.f1512v = false;
        C0582j[] c0582jArr = this.f1507k;
        if (c0582jArr != null) {
            int length = c0582jArr.length;
            c0567l.f1507k = new C0582j[length];
            c0567l.f1508l = new HashMap(length);
            while (i < length) {
                C0582j a = c0582jArr[i].mo1675a();
                c0567l.f1507k[i] = a;
                c0567l.f1508l.put(a.f1544a, a);
                i++;
            }
        }
        return c0567l;
    }

    public String toString() {
        String str = "ValueAnimator@" + Integer.toHexString(hashCode());
        if (this.f1507k != null) {
            for (C0582j c0582j : this.f1507k) {
                str = str + "\n    " + c0582j.toString();
            }
        }
        return str;
    }

    static /* synthetic */ void m1263b(C0567l c0567l) {
        c0567l.mo1669c();
        ((ArrayList) f1492m.get()).add(c0567l);
        if (c0567l.f1516z > 0 && c0567l.a != null) {
            ArrayList arrayList = (ArrayList) c0567l.a.clone();
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((C0556a) arrayList.get(i)).mo1652a(c0567l);
            }
        }
    }
}
