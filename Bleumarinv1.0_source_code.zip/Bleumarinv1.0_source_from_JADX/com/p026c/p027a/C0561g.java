package com.p026c.p027a;

import android.view.animation.Interpolator;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.ArrayList;
import java.util.Arrays;

/* compiled from: KeyframeSet */
class C0561g {
    int f1472a;
    C0564f f1473b;
    C0564f f1474c;
    Interpolator f1475d;
    ArrayList<C0564f> f1476e = new ArrayList();
    C0559k f1477f;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return mo1655a();
    }

    public C0561g(C0564f... c0564fArr) {
        this.f1472a = c0564fArr.length;
        this.f1476e.addAll(Arrays.asList(c0564fArr));
        this.f1473b = (C0564f) this.f1476e.get(0);
        this.f1474c = (C0564f) this.f1476e.get(this.f1472a - 1);
        this.f1475d = this.f1474c.f1484c;
    }

    public C0561g mo1655a() {
        ArrayList arrayList = this.f1476e;
        int size = this.f1476e.size();
        C0564f[] c0564fArr = new C0564f[size];
        for (int i = 0; i < size; i++) {
            c0564fArr[i] = ((C0564f) arrayList.get(i)).mo1660b();
        }
        return new C0561g(c0564fArr);
    }

    public Object mo1656a(float f) {
        if (this.f1472a == 2) {
            if (this.f1475d != null) {
                f = this.f1475d.getInterpolation(f);
            }
            return this.f1477f.mo1654a(f, this.f1473b.mo1658a(), this.f1474c.mo1658a());
        } else if (f <= 0.0f) {
            r0 = (C0564f) this.f1476e.get(1);
            r1 = r0.f1484c;
            if (r1 != null) {
                f = r1.getInterpolation(f);
            }
            r1 = this.f1473b.f1482a;
            return this.f1477f.mo1654a((f - r1) / (r0.f1482a - r1), this.f1473b.mo1658a(), r0.mo1658a());
        } else if (f >= DefaultRetryPolicy.DEFAULT_BACKOFF_MULT) {
            r0 = (C0564f) this.f1476e.get(this.f1472a - 2);
            r1 = this.f1474c.f1484c;
            if (r1 != null) {
                f = r1.getInterpolation(f);
            }
            r1 = r0.f1482a;
            return this.f1477f.mo1654a((f - r1) / (this.f1474c.f1482a - r1), r0.mo1658a(), this.f1474c.mo1658a());
        } else {
            C0564f c0564f = this.f1473b;
            int i = 1;
            while (i < this.f1472a) {
                r0 = (C0564f) this.f1476e.get(i);
                if (f < r0.f1482a) {
                    r1 = r0.f1484c;
                    if (r1 != null) {
                        f = r1.getInterpolation(f);
                    }
                    r1 = c0564f.f1482a;
                    return this.f1477f.mo1654a((f - r1) / (r0.f1482a - r1), c0564f.mo1658a(), r0.mo1658a());
                }
                i++;
                c0564f = r0;
            }
            return this.f1474c.mo1658a();
        }
    }

    public String toString() {
        String str = " ";
        int i = 0;
        while (i < this.f1472a) {
            String str2 = str + ((C0564f) this.f1476e.get(i)).mo1658a() + "  ";
            i++;
            str = str2;
        }
        return str;
    }
}
