package com.google.android.exoplayer.text;

import java.util.List;

public interface TextRenderer {
    void onCues(List<Cue> list);
}
