package com.google.android.gms.internal;

public interface zzdj {
    void zza(boolean z, float f);

    void zzd(boolean z);
}
