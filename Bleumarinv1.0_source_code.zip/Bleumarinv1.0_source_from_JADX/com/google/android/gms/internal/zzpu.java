package com.google.android.gms.internal;

import android.text.TextUtils;
import com.appyet.data.Document;
import com.google.android.gms.measurement.zze;
import com.google.android.gms.plus.PlusShare;
import java.util.HashMap;
import java.util.Map;

public final class zzpu extends zze<zzpu> {
    private String mCategory;
    private String zzSU;
    private long zzaDV;
    private String zzaUO;

    public final String getAction() {
        return this.zzSU;
    }

    public final String getLabel() {
        return this.zzaUO;
    }

    public final long getValue() {
        return this.zzaDV;
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("category", this.mCategory);
        hashMap.put("action", this.zzSU);
        hashMap.put(PlusShare.KEY_CALL_TO_ACTION_LABEL, this.zzaUO);
        hashMap.put(Document.COLUMN_DOCUMENT_VALUE, Long.valueOf(this.zzaDV));
        return zze.zzF(hashMap);
    }

    public final String zzAZ() {
        return this.mCategory;
    }

    public final void zzN(long j) {
        this.zzaDV = j;
    }

    public final void zza(zzpu com_google_android_gms_internal_zzpu) {
        if (!TextUtils.isEmpty(this.mCategory)) {
            com_google_android_gms_internal_zzpu.zzeE(this.mCategory);
        }
        if (!TextUtils.isEmpty(this.zzSU)) {
            com_google_android_gms_internal_zzpu.zzeF(this.zzSU);
        }
        if (!TextUtils.isEmpty(this.zzaUO)) {
            com_google_android_gms_internal_zzpu.zzeG(this.zzaUO);
        }
        if (this.zzaDV != 0) {
            com_google_android_gms_internal_zzpu.zzN(this.zzaDV);
        }
    }

    public final void zzeE(String str) {
        this.mCategory = str;
    }

    public final void zzeF(String str) {
        this.zzSU = str;
    }

    public final void zzeG(String str) {
        this.zzaUO = str;
    }
}
