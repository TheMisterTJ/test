package com.google.android.gms.internal;

@zzhb
public class zzbx {
    public static zzbz zza(zzcb com_google_android_gms_internal_zzcb, long j) {
        return com_google_android_gms_internal_zzcb == null ? null : com_google_android_gms_internal_zzcb.zzb(j);
    }

    public static boolean zza(zzcb com_google_android_gms_internal_zzcb, zzbz com_google_android_gms_internal_zzbz, long j, String... strArr) {
        return (com_google_android_gms_internal_zzcb == null || com_google_android_gms_internal_zzbz == null) ? false : com_google_android_gms_internal_zzcb.zza(com_google_android_gms_internal_zzbz, j, strArr);
    }

    public static boolean zza(zzcb com_google_android_gms_internal_zzcb, zzbz com_google_android_gms_internal_zzbz, String... strArr) {
        return (com_google_android_gms_internal_zzcb == null || com_google_android_gms_internal_zzbz == null) ? false : com_google_android_gms_internal_zzcb.zza(com_google_android_gms_internal_zzbz, strArr);
    }

    public static zzbz zzb(zzcb com_google_android_gms_internal_zzcb) {
        return com_google_android_gms_internal_zzcb == null ? null : com_google_android_gms_internal_zzcb.zzdB();
    }
}
