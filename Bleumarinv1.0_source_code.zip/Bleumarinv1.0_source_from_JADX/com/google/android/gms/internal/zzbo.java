package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import java.util.List;

public interface zzbo {
    List<String> zza(AdRequestInfoParcel adRequestInfoParcel);
}
