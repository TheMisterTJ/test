package com.google.android.exoplayer.text.ttml;

import android.text.Layout.Alignment;
import com.google.android.exoplayer.util.Assertions;

final class TtmlStyle {
    public static final short FONT_SIZE_UNIT_EM = (short) 2;
    public static final short FONT_SIZE_UNIT_PERCENT = (short) 3;
    public static final short FONT_SIZE_UNIT_PIXEL = (short) 1;
    private static final short OFF = (short) 0;
    private static final short ON = (short) 1;
    public static final short STYLE_BOLD = (short) 1;
    public static final short STYLE_BOLD_ITALIC = (short) 3;
    public static final short STYLE_ITALIC = (short) 2;
    public static final short STYLE_NORMAL = (short) 0;
    public static final short UNSPECIFIED = (short) -1;
    private int backgroundColor;
    private boolean backgroundColorSpecified;
    private short bold = (short) -1;
    private int color;
    private boolean colorSpecified;
    private String fontFamily;
    private float fontSize;
    private short fontSizeUnit = (short) -1;
    private String id;
    private TtmlStyle inheritableStyle;
    private short italic = (short) -1;
    private short linethrough = (short) -1;
    private Alignment textAlign;
    private short underline = (short) -1;

    TtmlStyle() {
    }

    public final short getStyle() {
        if (this.bold == (short) -1 && this.italic == (short) -1) {
            return (short) -1;
        }
        short s = (short) 0;
        if (this.bold != (short) -1) {
            s = (short) (this.bold + 0);
        }
        if (this.italic != (short) -1) {
            return (short) (s + this.italic);
        }
        return s;
    }

    public final boolean isLinethrough() {
        return this.linethrough == (short) 1;
    }

    public final TtmlStyle setLinethrough(boolean z) {
        boolean z2;
        short s = (short) 1;
        if (this.inheritableStyle == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        if (!z) {
            s = (short) 0;
        }
        this.linethrough = s;
        return this;
    }

    public final boolean isUnderline() {
        return this.underline == (short) 1;
    }

    public final TtmlStyle setUnderline(boolean z) {
        boolean z2;
        short s = (short) 1;
        if (this.inheritableStyle == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        if (!z) {
            s = (short) 0;
        }
        this.underline = s;
        return this;
    }

    public final String getFontFamily() {
        return this.fontFamily;
    }

    public final TtmlStyle setFontFamily(String str) {
        Assertions.checkState(this.inheritableStyle == null);
        this.fontFamily = str;
        return this;
    }

    public final int getColor() {
        return this.color;
    }

    public final TtmlStyle setColor(int i) {
        Assertions.checkState(this.inheritableStyle == null);
        this.color = i;
        this.colorSpecified = true;
        return this;
    }

    public final boolean hasColorSpecified() {
        return this.colorSpecified;
    }

    public final int getBackgroundColor() {
        return this.backgroundColor;
    }

    public final TtmlStyle setBackgroundColor(int i) {
        this.backgroundColor = i;
        this.backgroundColorSpecified = true;
        return this;
    }

    public final boolean hasBackgroundColorSpecified() {
        return this.backgroundColorSpecified;
    }

    public final TtmlStyle setBold(boolean z) {
        boolean z2;
        short s = (short) 1;
        if (this.inheritableStyle == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        if (!z) {
            s = (short) 0;
        }
        this.bold = s;
        return this;
    }

    public final TtmlStyle setItalic(boolean z) {
        boolean z2;
        short s = (short) 0;
        if (this.inheritableStyle == null) {
            z2 = true;
        } else {
            z2 = false;
        }
        Assertions.checkState(z2);
        if (z) {
            s = (short) 2;
        }
        this.italic = s;
        return this;
    }

    public final TtmlStyle inherit(TtmlStyle ttmlStyle) {
        return inherit(ttmlStyle, false);
    }

    public final TtmlStyle chain(TtmlStyle ttmlStyle) {
        return inherit(ttmlStyle, true);
    }

    private TtmlStyle inherit(TtmlStyle ttmlStyle, boolean z) {
        if (ttmlStyle != null) {
            if (!this.colorSpecified && ttmlStyle.colorSpecified) {
                setColor(ttmlStyle.color);
            }
            if (this.bold == (short) -1) {
                this.bold = ttmlStyle.bold;
            }
            if (this.italic == (short) -1) {
                this.italic = ttmlStyle.italic;
            }
            if (this.fontFamily == null) {
                this.fontFamily = ttmlStyle.fontFamily;
            }
            if (this.linethrough == (short) -1) {
                this.linethrough = ttmlStyle.linethrough;
            }
            if (this.underline == (short) -1) {
                this.underline = ttmlStyle.underline;
            }
            if (this.textAlign == null) {
                this.textAlign = ttmlStyle.textAlign;
            }
            if (this.fontSizeUnit == (short) -1) {
                this.fontSizeUnit = ttmlStyle.fontSizeUnit;
                this.fontSize = ttmlStyle.fontSize;
            }
            if (z && !this.backgroundColorSpecified && ttmlStyle.backgroundColorSpecified) {
                setBackgroundColor(ttmlStyle.backgroundColor);
            }
        }
        return this;
    }

    public final TtmlStyle setId(String str) {
        this.id = str;
        return this;
    }

    public final String getId() {
        return this.id;
    }

    public final Alignment getTextAlign() {
        return this.textAlign;
    }

    public final TtmlStyle setTextAlign(Alignment alignment) {
        this.textAlign = alignment;
        return this;
    }

    public final TtmlStyle setFontSize(float f) {
        this.fontSize = f;
        return this;
    }

    public final TtmlStyle setFontSizeUnit(short s) {
        this.fontSizeUnit = s;
        return this;
    }

    public final short getFontSizeUnit() {
        return this.fontSizeUnit;
    }

    public final float getFontSize() {
        return this.fontSize;
    }
}
