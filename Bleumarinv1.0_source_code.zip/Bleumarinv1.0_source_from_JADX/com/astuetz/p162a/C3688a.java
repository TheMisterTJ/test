package com.astuetz.p162a;

import com.bleumarin.agency.R;

/* compiled from: R */
public final class C3688a {

    /* compiled from: R */
    public static final class C3686a {
        public static final int background_tab = 2130837606;
    }

    /* compiled from: R */
    public static final class C3687b {
        public static final int[] PagerSlidingTabStrip = new int[]{R.attr.pstsIndicatorColor, R.attr.pstsUnderlineColor, R.attr.pstsDividerColor, R.attr.pstsIndicatorHeight, R.attr.pstsUnderlineHeight, R.attr.pstsDividerPadding, R.attr.pstsTabPaddingLeftRight, R.attr.pstsScrollOffset, R.attr.pstsTabBackground, R.attr.pstsShouldExpand, R.attr.pstsTextAllCaps};
        public static final int PagerSlidingTabStrip_pstsDividerColor = 2;
        public static final int PagerSlidingTabStrip_pstsDividerPadding = 5;
        public static final int PagerSlidingTabStrip_pstsIndicatorColor = 0;
        public static final int PagerSlidingTabStrip_pstsIndicatorHeight = 3;
        public static final int PagerSlidingTabStrip_pstsScrollOffset = 7;
        public static final int PagerSlidingTabStrip_pstsShouldExpand = 9;
        public static final int PagerSlidingTabStrip_pstsTabBackground = 8;
        public static final int PagerSlidingTabStrip_pstsTabPaddingLeftRight = 6;
        public static final int PagerSlidingTabStrip_pstsTextAllCaps = 10;
        public static final int PagerSlidingTabStrip_pstsUnderlineColor = 1;
        public static final int PagerSlidingTabStrip_pstsUnderlineHeight = 4;
    }
}
