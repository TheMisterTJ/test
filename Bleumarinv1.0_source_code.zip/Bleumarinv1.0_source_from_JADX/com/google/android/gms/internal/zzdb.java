package com.google.android.gms.internal;

public interface zzdb {
    void onAppEvent(String str, String str2);
}
