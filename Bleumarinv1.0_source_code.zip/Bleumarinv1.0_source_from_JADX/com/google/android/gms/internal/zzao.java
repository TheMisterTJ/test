package com.google.android.gms.internal;

public class zzao extends Exception {
    public zzao(String str) {
        super(str);
    }
}
