package com.google.android.exoplayer.text.webvtt;

import android.text.Layout.Alignment;
import android.util.Log;
import com.google.android.exoplayer.text.Cue;

final class WebvttCue extends Cue {
    public final long endTime;
    public final long startTime;

    static /* synthetic */ class C19321 {
        static final /* synthetic */ int[] $SwitchMap$android$text$Layout$Alignment = new int[Alignment.values().length];

        static {
            try {
                $SwitchMap$android$text$Layout$Alignment[Alignment.ALIGN_NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$android$text$Layout$Alignment[Alignment.ALIGN_CENTER.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$android$text$Layout$Alignment[Alignment.ALIGN_OPPOSITE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public static final class Builder {
        private static final String TAG = "WebvttCueBuilder";
        private long endTime;
        private float line;
        private int lineAnchor;
        private int lineType;
        private float position;
        private int positionAnchor;
        private long startTime;
        private CharSequence text;
        private Alignment textAlignment;
        private float width;

        public Builder() {
            reset();
        }

        public final void reset() {
            this.startTime = 0;
            this.endTime = 0;
            this.text = null;
            this.textAlignment = null;
            this.line = Cue.DIMEN_UNSET;
            this.lineType = Integer.MIN_VALUE;
            this.lineAnchor = Integer.MIN_VALUE;
            this.position = Cue.DIMEN_UNSET;
            this.positionAnchor = Integer.MIN_VALUE;
            this.width = Cue.DIMEN_UNSET;
        }

        public final WebvttCue build() {
            if (this.position != Cue.DIMEN_UNSET && this.positionAnchor == Integer.MIN_VALUE) {
                derivePositionAnchorFromAlignment();
            }
            return new WebvttCue(this.startTime, this.endTime, this.text, this.textAlignment, this.line, this.lineType, this.lineAnchor, this.position, this.positionAnchor, this.width);
        }

        public final Builder setStartTime(long j) {
            this.startTime = j;
            return this;
        }

        public final Builder setEndTime(long j) {
            this.endTime = j;
            return this;
        }

        public final Builder setText(CharSequence charSequence) {
            this.text = charSequence;
            return this;
        }

        public final Builder setTextAlignment(Alignment alignment) {
            this.textAlignment = alignment;
            return this;
        }

        public final Builder setLine(float f) {
            this.line = f;
            return this;
        }

        public final Builder setLineType(int i) {
            this.lineType = i;
            return this;
        }

        public final Builder setLineAnchor(int i) {
            this.lineAnchor = i;
            return this;
        }

        public final Builder setPosition(float f) {
            this.position = f;
            return this;
        }

        public final Builder setPositionAnchor(int i) {
            this.positionAnchor = i;
            return this;
        }

        public final Builder setWidth(float f) {
            this.width = f;
            return this;
        }

        private Builder derivePositionAnchorFromAlignment() {
            if (this.textAlignment != null) {
                switch (C19321.$SwitchMap$android$text$Layout$Alignment[this.textAlignment.ordinal()]) {
                    case 1:
                        this.positionAnchor = 0;
                        break;
                    case 2:
                        this.positionAnchor = 1;
                        break;
                    case 3:
                        this.positionAnchor = 2;
                        break;
                    default:
                        Log.w(TAG, "Unrecognized alignment: " + this.textAlignment);
                        this.positionAnchor = 0;
                        break;
                }
            }
            this.positionAnchor = Integer.MIN_VALUE;
            return this;
        }
    }

    public WebvttCue(CharSequence charSequence) {
        this(0, 0, charSequence);
    }

    public WebvttCue(long j, long j2, CharSequence charSequence) {
        this(j, j2, charSequence, null, Cue.DIMEN_UNSET, Integer.MIN_VALUE, Integer.MIN_VALUE, Cue.DIMEN_UNSET, Integer.MIN_VALUE, Cue.DIMEN_UNSET);
    }

    public WebvttCue(long j, long j2, CharSequence charSequence, Alignment alignment, float f, int i, int i2, float f2, int i3, float f3) {
        super(charSequence, alignment, f, i, i2, f2, i3, f3);
        this.startTime = j;
        this.endTime = j2;
    }

    public final boolean isNormalCue() {
        return this.line == Cue.DIMEN_UNSET && this.position == Cue.DIMEN_UNSET;
    }
}
