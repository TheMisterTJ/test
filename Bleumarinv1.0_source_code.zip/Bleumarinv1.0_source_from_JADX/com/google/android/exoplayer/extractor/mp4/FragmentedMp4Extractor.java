package com.google.android.exoplayer.extractor.mp4;

import android.util.Log;
import com.google.android.exoplayer.C1893C;
import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.drm.DrmInitData;
import com.google.android.exoplayer.drm.DrmInitData.Mapped;
import com.google.android.exoplayer.drm.DrmInitData.SchemeInitData;
import com.google.android.exoplayer.extractor.ChunkIndex;
import com.google.android.exoplayer.extractor.Extractor;
import com.google.android.exoplayer.extractor.ExtractorInput;
import com.google.android.exoplayer.extractor.ExtractorOutput;
import com.google.android.exoplayer.extractor.PositionHolder;
import com.google.android.exoplayer.extractor.SeekMap;
import com.google.android.exoplayer.extractor.TrackOutput;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.NalUnitUtil;
import com.google.android.exoplayer.util.ParsableByteArray;
import com.google.android.exoplayer.util.Util;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public final class FragmentedMp4Extractor implements Extractor {
    private static final byte[] PIFF_SAMPLE_ENCRYPTION_BOX_EXTENDED_TYPE = new byte[]{(byte) -94, (byte) 57, (byte) 79, (byte) 82, (byte) 90, (byte) -101, (byte) 79, ClosedCaptionCtrl.MISC_CHAN_1, (byte) -94, (byte) 68, (byte) 108, (byte) 66, (byte) 124, (byte) 100, (byte) -115, (byte) -12};
    private static final int STATE_READING_ATOM_HEADER = 0;
    private static final int STATE_READING_ATOM_PAYLOAD = 1;
    private static final int STATE_READING_ENCRYPTION_DATA = 2;
    private static final int STATE_READING_SAMPLE_CONTINUE = 4;
    private static final int STATE_READING_SAMPLE_START = 3;
    private static final String TAG = "FragmentedMp4Extractor";
    public static final int WORKAROUND_EVERY_VIDEO_FRAME_IS_SYNC_FRAME = 1;
    public static final int WORKAROUND_IGNORE_TFDT_BOX = 2;
    private ParsableByteArray atomData;
    private final ParsableByteArray atomHeader;
    private int atomHeaderBytesRead;
    private long atomSize;
    private int atomType;
    private final Stack<ContainerAtom> containerAtoms;
    private final ParsableByteArray encryptionSignalByte;
    private long endOfMdatPosition;
    private final byte[] extendedTypeScratch;
    private DefaultSampleValues extendsDefaults;
    private ExtractorOutput extractorOutput;
    private final TrackFragment fragmentRun;
    private boolean haveOutputSeekMap;
    private final ParsableByteArray nalLength;
    private final ParsableByteArray nalStartCode;
    private int parserState;
    private int sampleBytesWritten;
    private int sampleCurrentNalBytesRemaining;
    private int sampleIndex;
    private int sampleSize;
    private Track track;
    private TrackOutput trackOutput;
    private final int workaroundFlags;

    public FragmentedMp4Extractor() {
        this(0);
    }

    public FragmentedMp4Extractor(int i) {
        this.workaroundFlags = i;
        this.atomHeader = new ParsableByteArray(16);
        this.nalStartCode = new ParsableByteArray(NalUnitUtil.NAL_START_CODE);
        this.nalLength = new ParsableByteArray(4);
        this.encryptionSignalByte = new ParsableByteArray(1);
        this.extendedTypeScratch = new byte[16];
        this.containerAtoms = new Stack();
        this.fragmentRun = new TrackFragment();
        enterReadingAtomHeaderState();
    }

    public final boolean sniff(ExtractorInput extractorInput) throws IOException, InterruptedException {
        return Sniffer.sniffFragmented(extractorInput);
    }

    public final void setTrack(Track track) {
        this.extendsDefaults = new DefaultSampleValues(0, 0, 0, 0);
        this.track = track;
    }

    public final void init(ExtractorOutput extractorOutput) {
        this.extractorOutput = extractorOutput;
        this.trackOutput = extractorOutput.track(0);
        this.extractorOutput.endTracks();
    }

    public final void seek() {
        this.containerAtoms.clear();
        enterReadingAtomHeaderState();
    }

    public final int read(ExtractorInput extractorInput, PositionHolder positionHolder) throws IOException, InterruptedException {
        while (true) {
            switch (this.parserState) {
                case 0:
                    if (readAtomHeader(extractorInput)) {
                        break;
                    }
                    return -1;
                case 1:
                    readAtomPayload(extractorInput);
                    break;
                case 2:
                    readEncryptionData(extractorInput);
                    break;
                default:
                    if (!readSample(extractorInput)) {
                        break;
                    }
                    return 0;
            }
        }
    }

    private void enterReadingAtomHeaderState() {
        this.parserState = 0;
        this.atomHeaderBytesRead = 0;
    }

    private boolean readAtomHeader(ExtractorInput extractorInput) throws IOException, InterruptedException {
        if (this.atomHeaderBytesRead == 0) {
            if (!extractorInput.readFully(this.atomHeader.data, 0, 8, true)) {
                return false;
            }
            this.atomHeaderBytesRead = 8;
            this.atomHeader.setPosition(0);
            this.atomSize = this.atomHeader.readUnsignedInt();
            this.atomType = this.atomHeader.readInt();
        }
        if (this.atomSize == 1) {
            extractorInput.readFully(this.atomHeader.data, 8, 8);
            this.atomHeaderBytesRead += 8;
            this.atomSize = this.atomHeader.readUnsignedLongToLong();
        }
        long position = extractorInput.getPosition() - ((long) this.atomHeaderBytesRead);
        if (this.atomType == Atom.TYPE_moof) {
            this.fragmentRun.auxiliaryDataPosition = position;
            this.fragmentRun.dataPosition = position;
        }
        if (this.atomType == Atom.TYPE_mdat) {
            this.endOfMdatPosition = position + this.atomSize;
            if (!this.haveOutputSeekMap) {
                this.extractorOutput.seekMap(SeekMap.UNSEEKABLE);
                this.haveOutputSeekMap = true;
            }
            if (this.fragmentRun.sampleEncryptionDataNeedsFill) {
                this.parserState = 2;
            } else {
                this.parserState = 3;
            }
            return true;
        }
        if (shouldParseContainerAtom(this.atomType)) {
            this.containerAtoms.add(new ContainerAtom(this.atomType, (extractorInput.getPosition() + this.atomSize) - 8));
            enterReadingAtomHeaderState();
        } else if (shouldParseLeafAtom(this.atomType)) {
            if (this.atomHeaderBytesRead != 8) {
                throw new ParserException("Leaf atom defines extended atom size (unsupported).");
            } else if (this.atomSize > 2147483647L) {
                throw new ParserException("Leaf atom with length > 2147483647 (unsupported).");
            } else {
                this.atomData = new ParsableByteArray((int) this.atomSize);
                System.arraycopy(this.atomHeader.data, 0, this.atomData.data, 0, 8);
                this.parserState = 1;
            }
        } else if (this.atomSize > 2147483647L) {
            throw new ParserException("Skipping atom with length > 2147483647 (unsupported).");
        } else {
            this.atomData = null;
            this.parserState = 1;
        }
        return true;
    }

    private void readAtomPayload(ExtractorInput extractorInput) throws IOException, InterruptedException {
        int i = ((int) this.atomSize) - this.atomHeaderBytesRead;
        if (this.atomData != null) {
            extractorInput.readFully(this.atomData.data, 8, i);
            onLeafAtomRead(new LeafAtom(this.atomType, this.atomData), extractorInput.getPosition());
        } else {
            extractorInput.skipFully(i);
        }
        long position = extractorInput.getPosition();
        while (!this.containerAtoms.isEmpty() && ((ContainerAtom) this.containerAtoms.peek()).endPosition == position) {
            onContainerAtomRead((ContainerAtom) this.containerAtoms.pop());
        }
        enterReadingAtomHeaderState();
    }

    private void onLeafAtomRead(LeafAtom leafAtom, long j) throws ParserException {
        if (!this.containerAtoms.isEmpty()) {
            ((ContainerAtom) this.containerAtoms.peek()).add(leafAtom);
        } else if (leafAtom.type == Atom.TYPE_sidx) {
            this.extractorOutput.seekMap(parseSidx(leafAtom.data, j));
            this.haveOutputSeekMap = true;
        }
    }

    private void onContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        if (containerAtom.type == Atom.TYPE_moov) {
            onMoovContainerAtomRead(containerAtom);
        } else if (containerAtom.type == Atom.TYPE_moof) {
            onMoofContainerAtomRead(containerAtom);
        } else if (!this.containerAtoms.isEmpty()) {
            ((ContainerAtom) this.containerAtoms.peek()).add(containerAtom);
        }
    }

    private void onMoovContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        List list = containerAtom.leafChildren;
        int size = list.size();
        DrmInitData drmInitData = null;
        for (int i = 0; i < size; i++) {
            LeafAtom leafAtom = (LeafAtom) list.get(i);
            if (leafAtom.type == Atom.TYPE_pssh) {
                if (drmInitData == null) {
                    drmInitData = new Mapped();
                }
                byte[] bArr = leafAtom.data.data;
                if (PsshAtomUtil.parseUuid(bArr) == null) {
                    Log.w(TAG, "Skipped pssh atom (failed to extract uuid)");
                } else {
                    drmInitData.put(PsshAtomUtil.parseUuid(bArr), new SchemeInitData(MimeTypes.VIDEO_MP4, bArr));
                }
            }
        }
        if (drmInitData != null) {
            this.extractorOutput.drmInitData(drmInitData);
        }
        this.extendsDefaults = parseTrex(containerAtom.getContainerAtomOfType(Atom.TYPE_mvex).getLeafAtomOfType(Atom.TYPE_trex).data);
        this.track = AtomParsers.parseTrak(containerAtom.getContainerAtomOfType(Atom.TYPE_trak), containerAtom.getLeafAtomOfType(Atom.TYPE_mvhd), false);
        if (this.track == null) {
            throw new ParserException("Track type not supported.");
        }
        this.trackOutput.format(this.track.mediaFormat);
    }

    private void onMoofContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        this.fragmentRun.reset();
        parseMoof(this.track, this.extendsDefaults, containerAtom, this.fragmentRun, this.workaroundFlags, this.extendedTypeScratch);
        this.sampleIndex = 0;
    }

    private static DefaultSampleValues parseTrex(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(16);
        return new DefaultSampleValues(parsableByteArray.readUnsignedIntToInt() - 1, parsableByteArray.readUnsignedIntToInt(), parsableByteArray.readUnsignedIntToInt(), parsableByteArray.readInt());
    }

    private static void parseMoof(Track track, DefaultSampleValues defaultSampleValues, ContainerAtom containerAtom, TrackFragment trackFragment, int i, byte[] bArr) throws ParserException {
        if (containerAtom.getChildAtomOfTypeCount(Atom.TYPE_traf) != 1) {
            throw new ParserException("Traf count in moof != 1 (unsupported).");
        }
        parseTraf(track, defaultSampleValues, containerAtom.getContainerAtomOfType(Atom.TYPE_traf), trackFragment, i, bArr);
    }

    private static void parseTraf(Track track, DefaultSampleValues defaultSampleValues, ContainerAtom containerAtom, TrackFragment trackFragment, int i, byte[] bArr) throws ParserException {
        if (containerAtom.getChildAtomOfTypeCount(Atom.TYPE_trun) != 1) {
            throw new ParserException("Trun count in traf != 1 (unsupported).");
        }
        long j;
        if (containerAtom.getLeafAtomOfType(Atom.TYPE_tfdt) == null || (i & 2) != 0) {
            j = 0;
        } else {
            j = parseTfdt(containerAtom.getLeafAtomOfType(Atom.TYPE_tfdt).data);
        }
        parseTfhd(defaultSampleValues, containerAtom.getLeafAtomOfType(Atom.TYPE_tfhd).data, trackFragment);
        LeafAtom leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_trun);
        parseTrun(track, trackFragment.header, j, i, leafAtomOfType.data, trackFragment);
        leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_saiz);
        if (leafAtomOfType != null) {
            parseSaiz(track.sampleDescriptionEncryptionBoxes[trackFragment.header.sampleDescriptionIndex], leafAtomOfType.data, trackFragment);
        }
        leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_saio);
        if (leafAtomOfType != null) {
            parseSaio(leafAtomOfType.data, trackFragment);
        }
        leafAtomOfType = containerAtom.getLeafAtomOfType(Atom.TYPE_senc);
        if (leafAtomOfType != null) {
            parseSenc(leafAtomOfType.data, trackFragment);
        }
        int size = containerAtom.leafChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            leafAtomOfType = (LeafAtom) containerAtom.leafChildren.get(i2);
            if (leafAtomOfType.type == Atom.TYPE_uuid) {
                parseUuid(leafAtomOfType.data, trackFragment, bArr);
            }
        }
    }

    private static void parseSaiz(TrackEncryptionBox trackEncryptionBox, ParsableByteArray parsableByteArray, TrackFragment trackFragment) throws ParserException {
        boolean z = true;
        int i = trackEncryptionBox.initializationVectorSize;
        parsableByteArray.setPosition(8);
        if ((Atom.parseFullAtomFlags(parsableByteArray.readInt()) & 1) == 1) {
            parsableByteArray.skipBytes(8);
        }
        int readUnsignedByte = parsableByteArray.readUnsignedByte();
        int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
        if (readUnsignedIntToInt != trackFragment.length) {
            throw new ParserException("Length mismatch: " + readUnsignedIntToInt + ", " + trackFragment.length);
        }
        if (readUnsignedByte == 0) {
            boolean[] zArr = trackFragment.sampleHasSubsampleEncryptionTable;
            readUnsignedByte = 0;
            int i2 = 0;
            while (i2 < readUnsignedIntToInt) {
                boolean z2;
                int readUnsignedByte2 = parsableByteArray.readUnsignedByte();
                int i3 = readUnsignedByte + readUnsignedByte2;
                if (readUnsignedByte2 > i) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                zArr[i2] = z2;
                i2++;
                readUnsignedByte = i3;
            }
        } else {
            if (readUnsignedByte <= i) {
                z = false;
            }
            readUnsignedByte = (readUnsignedByte * readUnsignedIntToInt) + 0;
            Arrays.fill(trackFragment.sampleHasSubsampleEncryptionTable, 0, readUnsignedIntToInt, z);
        }
        trackFragment.initEncryptionData(readUnsignedByte);
    }

    private static void parseSaio(ParsableByteArray parsableByteArray, TrackFragment trackFragment) throws ParserException {
        parsableByteArray.setPosition(8);
        int readInt = parsableByteArray.readInt();
        if ((Atom.parseFullAtomFlags(readInt) & 1) == 1) {
            parsableByteArray.skipBytes(8);
        }
        int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
        if (readUnsignedIntToInt != 1) {
            throw new ParserException("Unexpected saio entry count: " + readUnsignedIntToInt);
        }
        readInt = Atom.parseFullAtomVersion(readInt);
        trackFragment.auxiliaryDataPosition = (readInt == 0 ? parsableByteArray.readUnsignedInt() : parsableByteArray.readUnsignedLongToLong()) + trackFragment.auxiliaryDataPosition;
    }

    private static void parseTfhd(DefaultSampleValues defaultSampleValues, ParsableByteArray parsableByteArray, TrackFragment trackFragment) {
        parsableByteArray.setPosition(8);
        int parseFullAtomFlags = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        parsableByteArray.skipBytes(4);
        if ((parseFullAtomFlags & 1) != 0) {
            long readUnsignedLongToLong = parsableByteArray.readUnsignedLongToLong();
            trackFragment.dataPosition = readUnsignedLongToLong;
            trackFragment.auxiliaryDataPosition = readUnsignedLongToLong;
        }
        trackFragment.header = new DefaultSampleValues((parseFullAtomFlags & 2) != 0 ? parsableByteArray.readUnsignedIntToInt() - 1 : defaultSampleValues.sampleDescriptionIndex, (parseFullAtomFlags & 8) != 0 ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.duration, (parseFullAtomFlags & 16) != 0 ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.size, (parseFullAtomFlags & 32) != 0 ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.flags);
    }

    private static long parseTfdt(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(8);
        return Atom.parseFullAtomVersion(parsableByteArray.readInt()) == 1 ? parsableByteArray.readUnsignedLongToLong() : parsableByteArray.readUnsignedInt();
    }

    private static void parseTrun(Track track, DefaultSampleValues defaultSampleValues, long j, int i, ParsableByteArray parsableByteArray, TrackFragment trackFragment) {
        Object obj;
        long scaleLargeTimestamp;
        parsableByteArray.setPosition(8);
        int parseFullAtomFlags = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
        if ((parseFullAtomFlags & 1) != 0) {
            trackFragment.dataPosition += (long) parsableByteArray.readInt();
        }
        Object obj2 = (parseFullAtomFlags & 4) != 0 ? 1 : null;
        int i2 = defaultSampleValues.flags;
        if (obj2 != null) {
            i2 = parsableByteArray.readUnsignedIntToInt();
        }
        Object obj3 = (parseFullAtomFlags & 256) != 0 ? 1 : null;
        Object obj4 = (parseFullAtomFlags & 512) != 0 ? 1 : null;
        Object obj5 = (parseFullAtomFlags & 1024) != 0 ? 1 : null;
        if ((parseFullAtomFlags & 2048) != 0) {
            obj = 1;
        } else {
            obj = null;
        }
        if (track.editListDurations != null && track.editListDurations.length == 1 && track.editListDurations[0] == 0) {
            scaleLargeTimestamp = Util.scaleLargeTimestamp(track.editListMediaTimes[0], 1000, track.timescale);
        } else {
            scaleLargeTimestamp = 0;
        }
        trackFragment.initTables(readUnsignedIntToInt);
        int[] iArr = trackFragment.sampleSizeTable;
        int[] iArr2 = trackFragment.sampleCompositionTimeOffsetTable;
        long[] jArr = trackFragment.sampleDecodingTimeTable;
        boolean[] zArr = trackFragment.sampleIsSyncFrameTable;
        long j2 = track.timescale;
        Object obj6 = (track.type != Track.TYPE_vide || (i & 1) == 0) ? null : 1;
        int i3 = 0;
        long j3 = j;
        while (i3 < readUnsignedIntToInt) {
            int readUnsignedIntToInt2 = obj3 != null ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.duration;
            int readUnsignedIntToInt3 = obj4 != null ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.size;
            int readInt = (i3 != 0 || obj2 == null) ? obj5 != null ? parsableByteArray.readInt() : defaultSampleValues.flags : i2;
            if (obj != null) {
                iArr2[i3] = (int) (((long) (parsableByteArray.readInt() * 1000)) / j2);
            } else {
                iArr2[i3] = 0;
            }
            jArr[i3] = Util.scaleLargeTimestamp(j3, 1000, j2) - scaleLargeTimestamp;
            iArr[i3] = readUnsignedIntToInt3;
            boolean z = ((readInt >> 16) & 1) == 0 && (obj6 == null || i3 == 0);
            zArr[i3] = z;
            j3 += (long) readUnsignedIntToInt2;
            i3++;
        }
    }

    private static void parseUuid(ParsableByteArray parsableByteArray, TrackFragment trackFragment, byte[] bArr) throws ParserException {
        parsableByteArray.setPosition(8);
        parsableByteArray.readBytes(bArr, 0, 16);
        if (Arrays.equals(bArr, PIFF_SAMPLE_ENCRYPTION_BOX_EXTENDED_TYPE)) {
            parseSenc(parsableByteArray, 16, trackFragment);
        }
    }

    private static void parseSenc(ParsableByteArray parsableByteArray, TrackFragment trackFragment) throws ParserException {
        parseSenc(parsableByteArray, 0, trackFragment);
    }

    private static void parseSenc(ParsableByteArray parsableByteArray, int i, TrackFragment trackFragment) throws ParserException {
        parsableByteArray.setPosition(i + 8);
        int parseFullAtomFlags = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        if ((parseFullAtomFlags & 1) != 0) {
            throw new ParserException("Overriding TrackEncryptionBox parameters is unsupported.");
        }
        boolean z;
        if ((parseFullAtomFlags & 2) != 0) {
            z = true;
        } else {
            z = false;
        }
        int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
        if (readUnsignedIntToInt != trackFragment.length) {
            throw new ParserException("Length mismatch: " + readUnsignedIntToInt + ", " + trackFragment.length);
        }
        Arrays.fill(trackFragment.sampleHasSubsampleEncryptionTable, 0, readUnsignedIntToInt, z);
        trackFragment.initEncryptionData(parsableByteArray.bytesLeft());
        trackFragment.fillEncryptionData(parsableByteArray);
    }

    private static ChunkIndex parseSidx(ParsableByteArray parsableByteArray, long j) throws ParserException {
        long readUnsignedInt;
        long readUnsignedInt2;
        parsableByteArray.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray.skipBytes(4);
        long readUnsignedInt3 = parsableByteArray.readUnsignedInt();
        if (parseFullAtomVersion == 0) {
            readUnsignedInt = parsableByteArray.readUnsignedInt() + j;
            readUnsignedInt2 = parsableByteArray.readUnsignedInt();
        } else {
            readUnsignedInt = parsableByteArray.readUnsignedLongToLong() + j;
            readUnsignedInt2 = parsableByteArray.readUnsignedLongToLong();
        }
        parsableByteArray.skipBytes(2);
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        int[] iArr = new int[readUnsignedShort];
        long[] jArr = new long[readUnsignedShort];
        long[] jArr2 = new long[readUnsignedShort];
        long[] jArr3 = new long[readUnsignedShort];
        int i = 0;
        long j2 = readUnsignedInt2;
        readUnsignedInt2 = Util.scaleLargeTimestamp(readUnsignedInt2, C1893C.MICROS_PER_SECOND, readUnsignedInt3);
        while (i < readUnsignedShort) {
            int readInt = parsableByteArray.readInt();
            if ((Integer.MIN_VALUE & readInt) != 0) {
                throw new ParserException("Unhandled indirect reference");
            }
            long readUnsignedInt4 = parsableByteArray.readUnsignedInt();
            iArr[i] = readInt & Integer.MAX_VALUE;
            jArr[i] = readUnsignedInt;
            jArr3[i] = readUnsignedInt2;
            readUnsignedInt2 = j2 + readUnsignedInt4;
            j2 = Util.scaleLargeTimestamp(readUnsignedInt2, C1893C.MICROS_PER_SECOND, readUnsignedInt3);
            jArr2[i] = j2 - jArr3[i];
            parsableByteArray.skipBytes(4);
            readUnsignedInt += (long) iArr[i];
            i++;
            long j3 = j2;
            j2 = readUnsignedInt2;
            readUnsignedInt2 = j3;
        }
        return new ChunkIndex(iArr, jArr, jArr2, jArr3);
    }

    private void readEncryptionData(ExtractorInput extractorInput) throws IOException, InterruptedException {
        int position = (int) (this.fragmentRun.auxiliaryDataPosition - extractorInput.getPosition());
        if (position < 0) {
            throw new ParserException("Offset to encryption data was negative.");
        }
        extractorInput.skipFully(position);
        this.fragmentRun.fillEncryptionData(extractorInput);
        this.parserState = 3;
    }

    private boolean readSample(ExtractorInput extractorInput) throws IOException, InterruptedException {
        int position;
        int i = 2;
        if (this.parserState == 3) {
            if (this.sampleIndex == this.fragmentRun.length) {
                i = (int) (this.endOfMdatPosition - extractorInput.getPosition());
                if (i < 0) {
                    throw new ParserException("Offset to end of mdat was negative.");
                }
                extractorInput.skipFully(i);
                enterReadingAtomHeaderState();
                return false;
            }
            if (this.sampleIndex == 0) {
                position = (int) (this.fragmentRun.dataPosition - extractorInput.getPosition());
                if (position < 0) {
                    throw new ParserException("Offset to sample data was negative.");
                }
                extractorInput.skipFully(position);
            }
            this.sampleSize = this.fragmentRun.sampleSizeTable[this.sampleIndex];
            if (this.fragmentRun.definesEncryptionData) {
                this.sampleBytesWritten = appendSampleEncryptionData(this.fragmentRun.sampleEncryptionData);
                this.sampleSize += this.sampleBytesWritten;
            } else {
                this.sampleBytesWritten = 0;
            }
            this.sampleCurrentNalBytesRemaining = 0;
            this.parserState = 4;
        }
        if (this.track.nalUnitLengthFieldLength != -1) {
            byte[] bArr = this.nalLength.data;
            bArr[0] = (byte) 0;
            bArr[1] = (byte) 0;
            bArr[2] = (byte) 0;
            position = this.track.nalUnitLengthFieldLength;
            int i2 = 4 - this.track.nalUnitLengthFieldLength;
            while (this.sampleBytesWritten < this.sampleSize) {
                if (this.sampleCurrentNalBytesRemaining == 0) {
                    extractorInput.readFully(this.nalLength.data, i2, position);
                    this.nalLength.setPosition(0);
                    this.sampleCurrentNalBytesRemaining = this.nalLength.readUnsignedIntToInt();
                    this.nalStartCode.setPosition(0);
                    this.trackOutput.sampleData(this.nalStartCode, 4);
                    this.sampleBytesWritten += 4;
                    this.sampleSize += i2;
                } else {
                    int sampleData = this.trackOutput.sampleData(extractorInput, this.sampleCurrentNalBytesRemaining, false);
                    this.sampleBytesWritten += sampleData;
                    this.sampleCurrentNalBytesRemaining -= sampleData;
                }
            }
        } else {
            while (this.sampleBytesWritten < this.sampleSize) {
                this.sampleBytesWritten = this.trackOutput.sampleData(extractorInput, this.sampleSize - this.sampleBytesWritten, false) + this.sampleBytesWritten;
            }
        }
        long samplePresentationTime = this.fragmentRun.getSamplePresentationTime(this.sampleIndex) * 1000;
        if (!this.fragmentRun.definesEncryptionData) {
            i = 0;
        }
        this.trackOutput.sampleMetadata(samplePresentationTime, i | (this.fragmentRun.sampleIsSyncFrameTable[this.sampleIndex] ? 1 : 0), this.sampleSize, 0, this.fragmentRun.definesEncryptionData ? this.track.sampleDescriptionEncryptionBoxes[this.fragmentRun.header.sampleDescriptionIndex].keyId : null);
        this.sampleIndex++;
        this.parserState = 3;
        return true;
    }

    private int appendSampleEncryptionData(ParsableByteArray parsableByteArray) {
        int i = this.track.sampleDescriptionEncryptionBoxes[this.fragmentRun.header.sampleDescriptionIndex].initializationVectorSize;
        boolean z = this.fragmentRun.sampleHasSubsampleEncryptionTable[this.sampleIndex];
        this.encryptionSignalByte.data[0] = (byte) ((z ? 128 : 0) | i);
        this.encryptionSignalByte.setPosition(0);
        this.trackOutput.sampleData(this.encryptionSignalByte, 1);
        this.trackOutput.sampleData(parsableByteArray, i);
        if (!z) {
            return i + 1;
        }
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        parsableByteArray.skipBytes(-2);
        readUnsignedShort = (readUnsignedShort * 6) + 2;
        this.trackOutput.sampleData(parsableByteArray, readUnsignedShort);
        return readUnsignedShort + (i + 1);
    }

    private static boolean shouldParseLeafAtom(int i) {
        return i == Atom.TYPE_hdlr || i == Atom.TYPE_mdhd || i == Atom.TYPE_mvhd || i == Atom.TYPE_sidx || i == Atom.TYPE_stsd || i == Atom.TYPE_tfdt || i == Atom.TYPE_tfhd || i == Atom.TYPE_tkhd || i == Atom.TYPE_trex || i == Atom.TYPE_trun || i == Atom.TYPE_pssh || i == Atom.TYPE_saiz || i == Atom.TYPE_saio || i == Atom.TYPE_senc || i == Atom.TYPE_uuid || i == Atom.TYPE_elst;
    }

    private static boolean shouldParseContainerAtom(int i) {
        return i == Atom.TYPE_moov || i == Atom.TYPE_trak || i == Atom.TYPE_mdia || i == Atom.TYPE_minf || i == Atom.TYPE_stbl || i == Atom.TYPE_moof || i == Atom.TYPE_traf || i == Atom.TYPE_mvex || i == Atom.TYPE_edts;
    }
}
