package com.google.android.exoplayer.text.eia608;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import com.google.android.exoplayer.ExoPlaybackException;
import com.google.android.exoplayer.MediaFormat;
import com.google.android.exoplayer.MediaFormatHolder;
import com.google.android.exoplayer.SampleHolder;
import com.google.android.exoplayer.SampleSource;
import com.google.android.exoplayer.SampleSourceTrackRenderer;
import com.google.android.exoplayer.text.Cue;
import com.google.android.exoplayer.text.TextRenderer;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.Util;
import java.util.Collections;
import java.util.TreeSet;

public final class Eia608TrackRenderer extends SampleSourceTrackRenderer implements Callback {
    private static final int CC_MODE_PAINT_ON = 3;
    private static final int CC_MODE_POP_ON = 2;
    private static final int CC_MODE_ROLL_UP = 1;
    private static final int CC_MODE_UNKNOWN = 0;
    private static final int DEFAULT_CAPTIONS_ROW_COUNT = 4;
    private static final int MAX_SAMPLE_READAHEAD_US = 5000000;
    private static final int MSG_INVOKE_RENDERER = 0;
    private String caption;
    private int captionMode;
    private int captionRowCount;
    private final StringBuilder captionStringBuilder;
    private final Eia608Parser eia608Parser;
    private final MediaFormatHolder formatHolder;
    private boolean inputStreamEnded;
    private String lastRenderedCaption;
    private final TreeSet<ClosedCaptionList> pendingCaptionLists;
    private ClosedCaptionCtrl repeatableControl;
    private final SampleHolder sampleHolder;
    private final TextRenderer textRenderer;
    private final Handler textRendererHandler;

    public Eia608TrackRenderer(SampleSource sampleSource, TextRenderer textRenderer, Looper looper) {
        super(sampleSource);
        this.textRenderer = (TextRenderer) Assertions.checkNotNull(textRenderer);
        this.textRendererHandler = looper == null ? null : new Handler(looper, this);
        this.eia608Parser = new Eia608Parser();
        this.formatHolder = new MediaFormatHolder();
        this.sampleHolder = new SampleHolder(1);
        this.captionStringBuilder = new StringBuilder();
        this.pendingCaptionLists = new TreeSet();
    }

    protected final boolean handlesTrack(MediaFormat mediaFormat) {
        return this.eia608Parser.canParse(mediaFormat.mimeType);
    }

    protected final void onEnabled(int i, long j, boolean z) throws ExoPlaybackException {
        super.onEnabled(i, j, z);
    }

    protected final void onDiscontinuity(long j) {
        this.inputStreamEnded = false;
        this.repeatableControl = null;
        this.pendingCaptionLists.clear();
        clearPendingSample();
        this.captionRowCount = 4;
        setCaptionMode(0);
        invokeRenderer(null);
    }

    protected final void doSomeWork(long j, long j2, boolean z) throws ExoPlaybackException {
        int i;
        if (isSamplePending()) {
            maybeParsePendingSample(j);
        }
        if (this.inputStreamEnded) {
            i = -1;
        } else {
            i = -3;
        }
        while (!isSamplePending() && r0 == -3) {
            i = readSource(j, this.formatHolder, this.sampleHolder);
            if (i == -3) {
                maybeParsePendingSample(j);
            } else if (i == -1) {
                this.inputStreamEnded = true;
            }
        }
        while (!this.pendingCaptionLists.isEmpty() && ((ClosedCaptionList) this.pendingCaptionLists.first()).timeUs <= j) {
            ClosedCaptionList closedCaptionList = (ClosedCaptionList) this.pendingCaptionLists.pollFirst();
            consumeCaptionList(closedCaptionList);
            if (!closedCaptionList.decodeOnly) {
                invokeRenderer(this.caption);
            }
        }
    }

    protected final long getBufferedPositionUs() {
        return -3;
    }

    protected final boolean isEnded() {
        return this.inputStreamEnded;
    }

    protected final boolean isReady() {
        return true;
    }

    private void invokeRenderer(String str) {
        if (!Util.areEqual(this.lastRenderedCaption, str)) {
            this.lastRenderedCaption = str;
            if (this.textRendererHandler != null) {
                this.textRendererHandler.obtainMessage(0, str).sendToTarget();
            } else {
                invokeRendererInternal(str);
            }
        }
    }

    public final boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                invokeRendererInternal((String) message.obj);
                return true;
            default:
                return false;
        }
    }

    private void invokeRendererInternal(String str) {
        if (str == null) {
            this.textRenderer.onCues(Collections.emptyList());
        } else {
            this.textRenderer.onCues(Collections.singletonList(new Cue(str)));
        }
    }

    private void maybeParsePendingSample(long j) {
        if (this.sampleHolder.timeUs <= 5000000 + j) {
            ClosedCaptionList parse = this.eia608Parser.parse(this.sampleHolder);
            clearPendingSample();
            if (parse != null) {
                this.pendingCaptionLists.add(parse);
            }
        }
    }

    private void consumeCaptionList(ClosedCaptionList closedCaptionList) {
        int length = closedCaptionList.captions.length;
        if (length != 0) {
            int i = 0;
            Object obj = null;
            while (i < length) {
                Object obj2;
                ClosedCaption closedCaption = closedCaptionList.captions[i];
                if (closedCaption.type == 0) {
                    ClosedCaptionCtrl closedCaptionCtrl = (ClosedCaptionCtrl) closedCaption;
                    if (length == 1 && closedCaptionCtrl.isRepeatable()) {
                        obj = 1;
                    } else {
                        obj = null;
                    }
                    if (obj == null || this.repeatableControl == null || this.repeatableControl.cc1 != closedCaptionCtrl.cc1 || this.repeatableControl.cc2 != closedCaptionCtrl.cc2) {
                        if (obj != null) {
                            this.repeatableControl = closedCaptionCtrl;
                        }
                        if (closedCaptionCtrl.isMiscCode()) {
                            handleMiscCode(closedCaptionCtrl);
                            obj2 = obj;
                        } else {
                            if (closedCaptionCtrl.isPreambleAddressCode()) {
                                handlePreambleAddressCode();
                            }
                            obj2 = obj;
                        }
                    } else {
                        this.repeatableControl = null;
                        obj2 = obj;
                    }
                } else {
                    handleText((ClosedCaptionText) closedCaption);
                    obj2 = obj;
                }
                i++;
                obj = obj2;
            }
            if (obj == null) {
                this.repeatableControl = null;
            }
            if (this.captionMode == 1 || this.captionMode == 3) {
                this.caption = getDisplayCaption();
            }
        }
    }

    private void handleText(ClosedCaptionText closedCaptionText) {
        if (this.captionMode != 0) {
            this.captionStringBuilder.append(closedCaptionText.text);
        }
    }

    private void handleMiscCode(ClosedCaptionCtrl closedCaptionCtrl) {
        switch (closedCaptionCtrl.cc2) {
            case (byte) 32:
                setCaptionMode(2);
                return;
            case (byte) 37:
                this.captionRowCount = 2;
                setCaptionMode(1);
                return;
            case (byte) 38:
                this.captionRowCount = 3;
                setCaptionMode(1);
                return;
            case (byte) 39:
                this.captionRowCount = 4;
                setCaptionMode(1);
                return;
            case (byte) 41:
                setCaptionMode(3);
                return;
            default:
                if (this.captionMode != 0) {
                    switch (closedCaptionCtrl.cc2) {
                        case (byte) 33:
                            if (this.captionStringBuilder.length() > 0) {
                                this.captionStringBuilder.setLength(this.captionStringBuilder.length() - 1);
                                return;
                            }
                            return;
                        case (byte) 44:
                            this.caption = null;
                            if (this.captionMode == 1 || this.captionMode == 3) {
                                this.captionStringBuilder.setLength(0);
                                return;
                            }
                            return;
                        case (byte) 45:
                            maybeAppendNewline();
                            return;
                        case (byte) 46:
                            this.captionStringBuilder.setLength(0);
                            return;
                        case (byte) 47:
                            this.caption = getDisplayCaption();
                            this.captionStringBuilder.setLength(0);
                            return;
                        default:
                            return;
                    }
                }
                return;
        }
    }

    private void handlePreambleAddressCode() {
        maybeAppendNewline();
    }

    private void setCaptionMode(int i) {
        if (this.captionMode != i) {
            this.captionMode = i;
            this.captionStringBuilder.setLength(0);
            if (i == 1 || i == 0) {
                this.caption = null;
            }
        }
    }

    private void maybeAppendNewline() {
        int length = this.captionStringBuilder.length();
        if (length > 0 && this.captionStringBuilder.charAt(length - 1) != '\n') {
            this.captionStringBuilder.append('\n');
        }
    }

    private String getDisplayCaption() {
        int length = this.captionStringBuilder.length();
        if (length == 0) {
            return null;
        }
        int i;
        if (this.captionStringBuilder.charAt(length - 1) == '\n') {
            i = 1;
        } else {
            i = 0;
        }
        if (length == 1 && i != 0) {
            return null;
        }
        if (i != 0) {
            length--;
        }
        if (this.captionMode != 1) {
            return this.captionStringBuilder.substring(0, length);
        }
        int i2;
        i = length;
        for (i2 = 0; i2 < this.captionRowCount && i != -1; i2++) {
            i = this.captionStringBuilder.lastIndexOf("\n", i - 1);
        }
        if (i != -1) {
            i2 = i + 1;
        } else {
            i2 = 0;
        }
        this.captionStringBuilder.delete(0, i2);
        return this.captionStringBuilder.substring(0, length - i2);
    }

    private void clearPendingSample() {
        this.sampleHolder.timeUs = -1;
        this.sampleHolder.clearData();
    }

    private boolean isSamplePending() {
        return this.sampleHolder.timeUs != -1;
    }
}
