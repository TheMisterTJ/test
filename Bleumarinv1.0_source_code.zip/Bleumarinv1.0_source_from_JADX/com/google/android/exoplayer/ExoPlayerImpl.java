package com.google.android.exoplayer;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.exoplayer.ExoPlayer.ExoPlayerComponent;
import com.google.android.exoplayer.ExoPlayer.Listener;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

final class ExoPlayerImpl implements ExoPlayer {
    private static final String TAG = "ExoPlayerImpl";
    private final Handler eventHandler;
    private final ExoPlayerImplInternal internalPlayer;
    private final CopyOnWriteArraySet<Listener> listeners = new CopyOnWriteArraySet();
    private int pendingPlayWhenReadyAcks;
    private boolean playWhenReady = false;
    private int playbackState = 1;
    private final int[] selectedTrackIndices;
    private final MediaFormat[][] trackFormats;

    class C18951 extends Handler {
        C18951() {
        }

        public void handleMessage(Message message) {
            ExoPlayerImpl.this.handleEvent(message);
        }
    }

    @SuppressLint({"HandlerLeak"})
    public ExoPlayerImpl(int i, int i2, int i3) {
        Log.i(TAG, "Init 1.5.6");
        this.trackFormats = new MediaFormat[i][];
        this.selectedTrackIndices = new int[i];
        this.eventHandler = new C18951();
        this.internalPlayer = new ExoPlayerImplInternal(this.eventHandler, this.playWhenReady, this.selectedTrackIndices, i2, i3);
    }

    public final Looper getPlaybackLooper() {
        return this.internalPlayer.getPlaybackLooper();
    }

    public final void addListener(Listener listener) {
        this.listeners.add(listener);
    }

    public final void removeListener(Listener listener) {
        this.listeners.remove(listener);
    }

    public final int getPlaybackState() {
        return this.playbackState;
    }

    public final void prepare(TrackRenderer... trackRendererArr) {
        Arrays.fill(this.trackFormats, null);
        this.internalPlayer.prepare(trackRendererArr);
    }

    public final int getTrackCount(int i) {
        return this.trackFormats[i] != null ? this.trackFormats[i].length : 0;
    }

    public final MediaFormat getTrackFormat(int i, int i2) {
        return this.trackFormats[i][i2];
    }

    public final void setSelectedTrack(int i, int i2) {
        if (this.selectedTrackIndices[i] != i2) {
            this.selectedTrackIndices[i] = i2;
            this.internalPlayer.setRendererSelectedTrack(i, i2);
        }
    }

    public final int getSelectedTrack(int i) {
        return this.selectedTrackIndices[i];
    }

    public final void setPlayWhenReady(boolean z) {
        if (this.playWhenReady != z) {
            this.playWhenReady = z;
            this.pendingPlayWhenReadyAcks++;
            this.internalPlayer.setPlayWhenReady(z);
            Iterator it = this.listeners.iterator();
            while (it.hasNext()) {
                ((Listener) it.next()).onPlayerStateChanged(z, this.playbackState);
            }
        }
    }

    public final boolean getPlayWhenReady() {
        return this.playWhenReady;
    }

    public final boolean isPlayWhenReadyCommitted() {
        return this.pendingPlayWhenReadyAcks == 0;
    }

    public final void seekTo(long j) {
        this.internalPlayer.seekTo(j);
    }

    public final void stop() {
        this.internalPlayer.stop();
    }

    public final void release() {
        this.internalPlayer.release();
        this.eventHandler.removeCallbacksAndMessages(null);
    }

    public final void sendMessage(ExoPlayerComponent exoPlayerComponent, int i, Object obj) {
        this.internalPlayer.sendMessage(exoPlayerComponent, i, obj);
    }

    public final void blockingSendMessage(ExoPlayerComponent exoPlayerComponent, int i, Object obj) {
        this.internalPlayer.blockingSendMessage(exoPlayerComponent, i, obj);
    }

    public final long getDuration() {
        return this.internalPlayer.getDuration();
    }

    public final long getCurrentPosition() {
        return this.internalPlayer.getCurrentPosition();
    }

    public final long getBufferedPosition() {
        return this.internalPlayer.getBufferedPosition();
    }

    public final int getBufferedPercentage() {
        long j = 100;
        long bufferedPosition = getBufferedPosition();
        long duration = getDuration();
        if (bufferedPosition == -1 || duration == -1) {
            return 0;
        }
        if (duration != 0) {
            j = (100 * bufferedPosition) / duration;
        }
        return (int) j;
    }

    final void handleEvent(Message message) {
        Iterator it;
        switch (message.what) {
            case 1:
                System.arraycopy(message.obj, 0, this.trackFormats, 0, this.trackFormats.length);
                this.playbackState = message.arg1;
                it = this.listeners.iterator();
                while (it.hasNext()) {
                    ((Listener) it.next()).onPlayerStateChanged(this.playWhenReady, this.playbackState);
                }
                return;
            case 2:
                this.playbackState = message.arg1;
                it = this.listeners.iterator();
                while (it.hasNext()) {
                    ((Listener) it.next()).onPlayerStateChanged(this.playWhenReady, this.playbackState);
                }
                return;
            case 3:
                this.pendingPlayWhenReadyAcks--;
                if (this.pendingPlayWhenReadyAcks == 0) {
                    it = this.listeners.iterator();
                    while (it.hasNext()) {
                        ((Listener) it.next()).onPlayWhenReadyCommitted();
                    }
                    return;
                }
                return;
            case 4:
                ExoPlaybackException exoPlaybackException = (ExoPlaybackException) message.obj;
                Iterator it2 = this.listeners.iterator();
                while (it2.hasNext()) {
                    ((Listener) it2.next()).onPlayerError(exoPlaybackException);
                }
                return;
            default:
                return;
        }
    }
}
