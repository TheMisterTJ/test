package com.google.android.exoplayer;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer.ExoPlayer.ExoPlayerComponent;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.PriorityHandlerThread;
import com.google.android.exoplayer.util.TraceUtil;
import com.google.android.exoplayer.util.Util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

final class ExoPlayerImplInternal implements Callback {
    private static final int IDLE_INTERVAL_MS = 1000;
    private static final int MSG_CUSTOM = 9;
    private static final int MSG_DO_SOME_WORK = 7;
    public static final int MSG_ERROR = 4;
    private static final int MSG_INCREMENTAL_PREPARE = 2;
    private static final int MSG_PREPARE = 1;
    public static final int MSG_PREPARED = 1;
    private static final int MSG_RELEASE = 5;
    private static final int MSG_SEEK_TO = 6;
    private static final int MSG_SET_PLAY_WHEN_READY = 3;
    public static final int MSG_SET_PLAY_WHEN_READY_ACK = 3;
    private static final int MSG_SET_RENDERER_SELECTED_TRACK = 8;
    public static final int MSG_STATE_CHANGED = 2;
    private static final int MSG_STOP = 4;
    private static final int PREPARE_INTERVAL_MS = 10;
    private static final int RENDERING_INTERVAL_MS = 10;
    private static final String TAG = "ExoPlayerImplInternal";
    private volatile long bufferedPositionUs;
    private int customMessagesProcessed = 0;
    private int customMessagesSent = 0;
    private volatile long durationUs;
    private long elapsedRealtimeUs;
    private final List<TrackRenderer> enabledRenderers;
    private final Handler eventHandler;
    private final Handler handler;
    private final HandlerThread internalPlaybackThread;
    private long lastSeekPositionMs;
    private final long minBufferUs;
    private final long minRebufferUs;
    private final AtomicInteger pendingSeekCount;
    private boolean playWhenReady;
    private volatile long positionUs;
    private boolean rebuffering;
    private boolean released;
    private MediaClock rendererMediaClock;
    private TrackRenderer rendererMediaClockSource;
    private TrackRenderer[] renderers;
    private final int[] selectedTrackIndices;
    private final StandaloneMediaClock standaloneMediaClock;
    private int state;
    private final MediaFormat[][] trackFormats;

    public ExoPlayerImplInternal(Handler handler, boolean z, int[] iArr, int i, int i2) {
        this.eventHandler = handler;
        this.playWhenReady = z;
        this.minBufferUs = ((long) i) * 1000;
        this.minRebufferUs = ((long) i2) * 1000;
        this.selectedTrackIndices = Arrays.copyOf(iArr, iArr.length);
        this.state = 1;
        this.durationUs = -1;
        this.bufferedPositionUs = -1;
        this.standaloneMediaClock = new StandaloneMediaClock();
        this.pendingSeekCount = new AtomicInteger();
        this.enabledRenderers = new ArrayList(iArr.length);
        this.trackFormats = new MediaFormat[iArr.length][];
        this.internalPlaybackThread = new PriorityHandlerThread("ExoPlayerImplInternal:Handler", -16);
        this.internalPlaybackThread.start();
        this.handler = new Handler(this.internalPlaybackThread.getLooper(), this);
    }

    public final Looper getPlaybackLooper() {
        return this.internalPlaybackThread.getLooper();
    }

    public final long getCurrentPosition() {
        return this.pendingSeekCount.get() > 0 ? this.lastSeekPositionMs : this.positionUs / 1000;
    }

    public final long getBufferedPosition() {
        return this.bufferedPositionUs == -1 ? -1 : this.bufferedPositionUs / 1000;
    }

    public final long getDuration() {
        return this.durationUs == -1 ? -1 : this.durationUs / 1000;
    }

    public final void prepare(TrackRenderer... trackRendererArr) {
        this.handler.obtainMessage(1, trackRendererArr).sendToTarget();
    }

    public final void setPlayWhenReady(boolean z) {
        int i;
        Handler handler = this.handler;
        if (z) {
            i = 1;
        } else {
            i = 0;
        }
        handler.obtainMessage(3, i, 0).sendToTarget();
    }

    public final void seekTo(long j) {
        this.lastSeekPositionMs = j;
        this.pendingSeekCount.incrementAndGet();
        this.handler.obtainMessage(6, Util.getTopInt(j), Util.getBottomInt(j)).sendToTarget();
    }

    public final void stop() {
        this.handler.sendEmptyMessage(4);
    }

    public final void setRendererSelectedTrack(int i, int i2) {
        this.handler.obtainMessage(8, i, i2).sendToTarget();
    }

    public final void sendMessage(ExoPlayerComponent exoPlayerComponent, int i, Object obj) {
        this.customMessagesSent++;
        this.handler.obtainMessage(9, i, 0, Pair.create(exoPlayerComponent, obj)).sendToTarget();
    }

    public final synchronized void blockingSendMessage(ExoPlayerComponent exoPlayerComponent, int i, Object obj) {
        if (this.released) {
            Log.w(TAG, "Sent message(" + i + ") after release. Message ignored.");
        } else {
            int i2 = this.customMessagesSent;
            this.customMessagesSent = i2 + 1;
            this.handler.obtainMessage(9, i, 0, Pair.create(exoPlayerComponent, obj)).sendToTarget();
            while (this.customMessagesProcessed <= i2) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    public final synchronized void release() {
        if (!this.released) {
            this.handler.sendEmptyMessage(5);
            while (!this.released) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            this.internalPlaybackThread.quit();
        }
    }

    public final boolean handleMessage(Message message) {
        boolean z = false;
        try {
            switch (message.what) {
                case 1:
                    prepareInternal((TrackRenderer[]) message.obj);
                    return true;
                case 2:
                    incrementalPrepareInternal();
                    return true;
                case 3:
                    if (message.arg1 != 0) {
                        z = true;
                    }
                    setPlayWhenReadyInternal(z);
                    return true;
                case 4:
                    stopInternal();
                    return true;
                case 5:
                    releaseInternal();
                    return true;
                case 6:
                    seekToInternal(Util.getLong(message.arg1, message.arg2));
                    return true;
                case 7:
                    doSomeWork();
                    return true;
                case 8:
                    setRendererSelectedTrackInternal(message.arg1, message.arg2);
                    return true;
                case 9:
                    sendMessageInternal(message.arg1, message.obj);
                    return true;
                default:
                    return false;
            }
        } catch (Throwable e) {
            Log.e(TAG, "Internal track renderer error.", e);
            this.eventHandler.obtainMessage(4, e).sendToTarget();
            stopInternal();
            return true;
        } catch (Throwable e2) {
            Log.e(TAG, "Internal runtime error.", e2);
            this.eventHandler.obtainMessage(4, new ExoPlaybackException(e2, true)).sendToTarget();
            stopInternal();
            return true;
        }
    }

    private void setState(int i) {
        if (this.state != i) {
            this.state = i;
            this.eventHandler.obtainMessage(2, i, 0).sendToTarget();
        }
    }

    private void prepareInternal(TrackRenderer[] trackRendererArr) throws ExoPlaybackException {
        resetInternal();
        this.renderers = trackRendererArr;
        Arrays.fill(this.trackFormats, null);
        for (int i = 0; i < trackRendererArr.length; i++) {
            MediaClock mediaClock = trackRendererArr[i].getMediaClock();
            if (mediaClock != null) {
                boolean z;
                if (this.rendererMediaClock == null) {
                    z = true;
                } else {
                    z = false;
                }
                Assertions.checkState(z);
                this.rendererMediaClock = mediaClock;
                this.rendererMediaClockSource = trackRendererArr[i];
            }
        }
        setState(2);
        incrementalPrepareInternal();
    }

    private void incrementalPrepareInternal() throws ExoPlaybackException {
        int i;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        Object obj = 1;
        for (TrackRenderer trackRenderer : this.renderers) {
            if (trackRenderer.getState() == 0 && trackRenderer.prepare(this.positionUs) == 0) {
                trackRenderer.maybeThrowError();
                obj = null;
            }
        }
        if (obj == null) {
            scheduleNextOperation(2, elapsedRealtime, 10);
            return;
        }
        ExoPlayerImplInternal exoPlayerImplInternal;
        long j = 0;
        Object obj2 = 1;
        Object obj3 = 1;
        int i2 = 0;
        while (i2 < this.renderers.length) {
            int i3;
            Object obj4;
            Object obj5;
            TrackRenderer trackRenderer2 = this.renderers[i2];
            int trackCount = trackRenderer2.getTrackCount();
            MediaFormat[] mediaFormatArr = new MediaFormat[trackCount];
            for (i3 = 0; i3 < trackCount; i3++) {
                mediaFormatArr[i3] = trackRenderer2.getFormat(i3);
            }
            this.trackFormats[i2] = mediaFormatArr;
            if (trackCount > 0) {
                if (j != -1) {
                    long durationUs = trackRenderer2.getDurationUs();
                    if (durationUs == -1) {
                        j = -1;
                    } else if (durationUs != -2) {
                        j = Math.max(j, durationUs);
                    }
                }
                i3 = this.selectedTrackIndices[i2];
                if (i3 >= 0 && i3 < mediaFormatArr.length) {
                    trackRenderer2.enable(i3, this.positionUs, false);
                    this.enabledRenderers.add(trackRenderer2);
                    Object obj6 = (obj2 == null || !trackRenderer2.isEnded()) ? null : 1;
                    if (obj3 == null || !rendererReadyOrEnded(trackRenderer2)) {
                        obj2 = null;
                    } else {
                        obj2 = 1;
                    }
                    long j2 = j;
                    obj4 = obj6;
                    obj = obj2;
                    elapsedRealtime = j2;
                    i2++;
                    obj3 = obj;
                    obj5 = obj4;
                    j = elapsedRealtime;
                    obj2 = obj5;
                }
            }
            obj5 = obj2;
            elapsedRealtime = j;
            obj4 = obj5;
            obj = obj3;
            i2++;
            obj3 = obj;
            obj5 = obj4;
            j = elapsedRealtime;
            obj2 = obj5;
        }
        this.durationUs = j;
        if (obj2 != null && (j == -1 || j <= this.positionUs)) {
            i = 5;
            exoPlayerImplInternal = this;
        } else if (obj3 != null) {
            i = 4;
            exoPlayerImplInternal = this;
        } else {
            i = 3;
            exoPlayerImplInternal = this;
        }
        exoPlayerImplInternal.state = i;
        this.eventHandler.obtainMessage(1, this.state, 0, this.trackFormats).sendToTarget();
        if (this.playWhenReady && this.state == 4) {
            startRenderers();
        }
        this.handler.sendEmptyMessage(7);
    }

    private boolean rendererReadyOrEnded(TrackRenderer trackRenderer) {
        if (trackRenderer.isEnded()) {
            return true;
        }
        if (!trackRenderer.isReady()) {
            return false;
        }
        if (this.state == 4) {
            return true;
        }
        long durationUs = trackRenderer.getDurationUs();
        long bufferedPositionUs = trackRenderer.getBufferedPositionUs();
        long j = this.rebuffering ? this.minRebufferUs : this.minBufferUs;
        if (j <= 0 || bufferedPositionUs == -1 || bufferedPositionUs == -3 || bufferedPositionUs >= j + this.positionUs) {
            return true;
        }
        if (durationUs == -1 || durationUs == -2 || bufferedPositionUs < durationUs) {
            return false;
        }
        return true;
    }

    private void setPlayWhenReadyInternal(boolean z) throws ExoPlaybackException {
        try {
            this.rebuffering = false;
            this.playWhenReady = z;
            if (!z) {
                stopRenderers();
                updatePositionUs();
            } else if (this.state == 4) {
                startRenderers();
                this.handler.sendEmptyMessage(7);
            } else if (this.state == 3) {
                this.handler.sendEmptyMessage(7);
            }
            this.eventHandler.obtainMessage(3).sendToTarget();
        } catch (Throwable th) {
            this.eventHandler.obtainMessage(3).sendToTarget();
        }
    }

    private void startRenderers() throws ExoPlaybackException {
        this.rebuffering = false;
        this.standaloneMediaClock.start();
        for (int i = 0; i < this.enabledRenderers.size(); i++) {
            ((TrackRenderer) this.enabledRenderers.get(i)).start();
        }
    }

    private void stopRenderers() throws ExoPlaybackException {
        this.standaloneMediaClock.stop();
        for (int i = 0; i < this.enabledRenderers.size(); i++) {
            ensureStopped((TrackRenderer) this.enabledRenderers.get(i));
        }
    }

    private void updatePositionUs() {
        if (this.rendererMediaClock == null || !this.enabledRenderers.contains(this.rendererMediaClockSource) || this.rendererMediaClockSource.isEnded()) {
            this.positionUs = this.standaloneMediaClock.getPositionUs();
        } else {
            this.positionUs = this.rendererMediaClock.getPositionUs();
            this.standaloneMediaClock.setPositionUs(this.positionUs);
        }
        this.elapsedRealtimeUs = SystemClock.elapsedRealtime() * 1000;
    }

    private void doSomeWork() throws ExoPlaybackException {
        TraceUtil.beginSection("doSomeWork");
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j = this.durationUs != -1 ? this.durationUs : Long.MAX_VALUE;
        updatePositionUs();
        Object obj = 1;
        Object obj2 = 1;
        long j2 = j;
        for (int i = 0; i < this.enabledRenderers.size(); i++) {
            TrackRenderer trackRenderer = (TrackRenderer) this.enabledRenderers.get(i);
            trackRenderer.doSomeWork(this.positionUs, this.elapsedRealtimeUs);
            obj2 = (obj2 == null || !trackRenderer.isEnded()) ? null : 1;
            boolean rendererReadyOrEnded = rendererReadyOrEnded(trackRenderer);
            if (!rendererReadyOrEnded) {
                trackRenderer.maybeThrowError();
            }
            obj = (obj == null || !rendererReadyOrEnded) ? null : 1;
            if (j2 != -1) {
                long durationUs = trackRenderer.getDurationUs();
                long bufferedPositionUs = trackRenderer.getBufferedPositionUs();
                if (bufferedPositionUs == -1) {
                    j2 = -1;
                } else if (bufferedPositionUs != -3 && (durationUs == -1 || durationUs == -2 || bufferedPositionUs < durationUs)) {
                    j2 = Math.min(j2, bufferedPositionUs);
                }
            }
        }
        this.bufferedPositionUs = j2;
        if (obj2 != null && (this.durationUs == -1 || this.durationUs <= this.positionUs)) {
            setState(5);
            stopRenderers();
        } else if (this.state == 3 && obj != null) {
            setState(4);
            if (this.playWhenReady) {
                startRenderers();
            }
        } else if (this.state == 4 && obj == null) {
            this.rebuffering = this.playWhenReady;
            setState(3);
            stopRenderers();
        }
        this.handler.removeMessages(7);
        if ((this.playWhenReady && this.state == 4) || this.state == 3) {
            scheduleNextOperation(7, elapsedRealtime, 10);
        } else if (!this.enabledRenderers.isEmpty()) {
            scheduleNextOperation(7, elapsedRealtime, 1000);
        }
        TraceUtil.endSection();
    }

    private void scheduleNextOperation(int i, long j, long j2) {
        long elapsedRealtime = (j + j2) - SystemClock.elapsedRealtime();
        if (elapsedRealtime <= 0) {
            this.handler.sendEmptyMessage(i);
        } else {
            this.handler.sendEmptyMessageDelayed(i, elapsedRealtime);
        }
    }

    private void seekToInternal(long j) throws ExoPlaybackException {
        try {
            if (j != this.positionUs / 1000) {
                this.rebuffering = false;
                this.positionUs = j * 1000;
                this.standaloneMediaClock.stop();
                this.standaloneMediaClock.setPositionUs(this.positionUs);
                if (this.state == 1 || this.state == 2) {
                    this.pendingSeekCount.decrementAndGet();
                    return;
                }
                for (int i = 0; i < this.enabledRenderers.size(); i++) {
                    TrackRenderer trackRenderer = (TrackRenderer) this.enabledRenderers.get(i);
                    ensureStopped(trackRenderer);
                    trackRenderer.seekTo(this.positionUs);
                }
                setState(3);
                this.handler.sendEmptyMessage(7);
                this.pendingSeekCount.decrementAndGet();
            }
        } finally {
            this.pendingSeekCount.decrementAndGet();
        }
    }

    private void stopInternal() {
        resetInternal();
        setState(1);
    }

    private void releaseInternal() {
        resetInternal();
        setState(1);
        synchronized (this) {
            this.released = true;
            notifyAll();
        }
    }

    private void resetInternal() {
        int i = 0;
        this.handler.removeMessages(7);
        this.handler.removeMessages(2);
        this.rebuffering = false;
        this.standaloneMediaClock.stop();
        if (this.renderers != null) {
            while (i < this.renderers.length) {
                TrackRenderer trackRenderer = this.renderers[i];
                stopAndDisable(trackRenderer);
                release(trackRenderer);
                i++;
            }
            this.renderers = null;
            this.rendererMediaClock = null;
            this.rendererMediaClockSource = null;
            this.enabledRenderers.clear();
        }
    }

    private void stopAndDisable(TrackRenderer trackRenderer) {
        try {
            ensureStopped(trackRenderer);
            if (trackRenderer.getState() == 2) {
                trackRenderer.disable();
            }
        } catch (Throwable e) {
            Log.e(TAG, "Stop failed.", e);
        } catch (Throwable e2) {
            Log.e(TAG, "Stop failed.", e2);
        }
    }

    private void release(TrackRenderer trackRenderer) {
        try {
            trackRenderer.release();
        } catch (Throwable e) {
            Log.e(TAG, "Release failed.", e);
        } catch (Throwable e2) {
            Log.e(TAG, "Release failed.", e2);
        }
    }

    private <T> void sendMessageInternal(int i, Object obj) throws ExoPlaybackException {
        try {
            Pair pair = (Pair) obj;
            ((ExoPlayerComponent) pair.first).handleMessage(i, pair.second);
            if (!(this.state == 1 || this.state == 2)) {
                this.handler.sendEmptyMessage(7);
            }
            synchronized (this) {
                this.customMessagesProcessed++;
                notifyAll();
            }
        } catch (Throwable th) {
            synchronized (this) {
                this.customMessagesProcessed++;
                notifyAll();
            }
        }
    }

    private void setRendererSelectedTrackInternal(int i, int i2) throws ExoPlaybackException {
        boolean z = true;
        if (this.selectedTrackIndices[i] != i2) {
            this.selectedTrackIndices[i] = i2;
            if (this.state != 1 && this.state != 2) {
                TrackRenderer trackRenderer = this.renderers[i];
                int state = trackRenderer.getState();
                if (state != 0 && state != -1 && trackRenderer.getTrackCount() != 0) {
                    boolean z2;
                    boolean z3 = state == 2 || state == 3;
                    if (i2 < 0 || i2 >= this.trackFormats[i].length) {
                        z2 = false;
                    } else {
                        z2 = true;
                    }
                    if (z3) {
                        if (!z2 && trackRenderer == this.rendererMediaClockSource) {
                            this.standaloneMediaClock.setPositionUs(this.rendererMediaClock.getPositionUs());
                        }
                        ensureStopped(trackRenderer);
                        this.enabledRenderers.remove(trackRenderer);
                        trackRenderer.disable();
                    }
                    if (z2) {
                        z2 = this.playWhenReady && this.state == 4;
                        if (z3 || !z2) {
                            z = false;
                        }
                        trackRenderer.enable(i2, this.positionUs, z);
                        this.enabledRenderers.add(trackRenderer);
                        if (z2) {
                            trackRenderer.start();
                        }
                        this.handler.sendEmptyMessage(7);
                    }
                }
            }
        }
    }

    private void ensureStopped(TrackRenderer trackRenderer) throws ExoPlaybackException {
        if (trackRenderer.getState() == 3) {
            trackRenderer.stop();
        }
    }
}
