package com.astuetz;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.astuetz.a.a.a;
import com.astuetz.a.a.b;
import com.mopub.volley.DefaultRetryPolicy;
import java.util.Locale;

public class PagerSlidingTabStrip extends HorizontalScrollView {
    private static final int[] f1399b = new int[]{16842901, 16842904};
    private int f1400A;
    private int f1401B;
    private int f1402C;
    private Locale f1403D;
    public OnPageChangeListener f1404a;
    private LayoutParams f1405c;
    private LayoutParams f1406d;
    private final C0545b f1407e;
    private LinearLayout f1408f;
    private ViewPager f1409g;
    private int f1410h;
    private int f1411i;
    private float f1412j;
    private Paint f1413k;
    private Paint f1414l;
    private int f1415m;
    private int f1416n;
    private int f1417o;
    private boolean f1418p;
    private boolean f1419q;
    private int f1420r;
    private int f1421s;
    private int f1422t;
    private int f1423u;
    private int f1424v;
    private int f1425w;
    private int f1426x;
    private int f1427y;
    private Typeface f1428z;

    class C05411 implements OnGlobalLayoutListener {
        final /* synthetic */ PagerSlidingTabStrip f1394a;

        C05411(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f1394a = pagerSlidingTabStrip;
        }

        @SuppressLint({"NewApi"})
        public final void onGlobalLayout() {
            if (VERSION.SDK_INT < 16) {
                this.f1394a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                this.f1394a.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
            this.f1394a.f1411i = this.f1394a.f1409g.getCurrentItem();
            PagerSlidingTabStrip.m1188a(this.f1394a, this.f1394a.f1411i, 0);
        }
    }

    static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new C05431();
        int f1397a;

        static class C05431 implements Creator<SavedState> {
            C05431() {
            }

            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        private SavedState(Parcel parcel) {
            super(parcel);
            this.f1397a = parcel.readInt();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1397a);
        }
    }

    public interface C0544a {
        int m1182a();
    }

    private class C0545b implements OnPageChangeListener {
        final /* synthetic */ PagerSlidingTabStrip f1398a;

        private C0545b(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f1398a = pagerSlidingTabStrip;
        }

        public final void onPageScrolled(int i, float f, int i2) {
            this.f1398a.f1411i = i;
            this.f1398a.f1412j = f;
            PagerSlidingTabStrip.m1188a(this.f1398a, i, (int) (((float) this.f1398a.f1408f.getChildAt(i).getWidth()) * f));
            this.f1398a.invalidate();
            if (this.f1398a.f1404a != null) {
                this.f1398a.f1404a.onPageScrolled(i, f, i2);
            }
        }

        public final void onPageScrollStateChanged(int i) {
            if (i == 0) {
                PagerSlidingTabStrip.m1188a(this.f1398a, this.f1398a.f1409g.getCurrentItem(), 0);
            }
            if (this.f1398a.f1404a != null) {
                this.f1398a.f1404a.onPageScrollStateChanged(i);
            }
        }

        public final void onPageSelected(int i) {
            if (this.f1398a.f1404a != null) {
                this.f1398a.f1404a.onPageSelected(i);
            }
        }
    }

    public PagerSlidingTabStrip(Context context) {
        this(context, null);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1407e = new C0545b();
        this.f1411i = 0;
        this.f1412j = 0.0f;
        this.f1415m = -10066330;
        this.f1416n = 436207616;
        this.f1417o = 436207616;
        this.f1418p = false;
        this.f1419q = true;
        this.f1420r = 52;
        this.f1421s = 8;
        this.f1422t = 2;
        this.f1423u = 12;
        this.f1424v = 24;
        this.f1425w = 1;
        this.f1426x = 12;
        this.f1427y = -10066330;
        this.f1428z = null;
        this.f1400A = 1;
        this.f1401B = 0;
        this.f1402C = a.background_tab;
        setFillViewport(true);
        setWillNotDraw(false);
        this.f1408f = new LinearLayout(context);
        this.f1408f.setOrientation(0);
        this.f1408f.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        addView(this.f1408f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.f1420r = (int) TypedValue.applyDimension(1, (float) this.f1420r, displayMetrics);
        this.f1421s = (int) TypedValue.applyDimension(1, (float) this.f1421s, displayMetrics);
        this.f1422t = (int) TypedValue.applyDimension(1, (float) this.f1422t, displayMetrics);
        this.f1423u = (int) TypedValue.applyDimension(1, (float) this.f1423u, displayMetrics);
        this.f1424v = (int) TypedValue.applyDimension(1, (float) this.f1424v, displayMetrics);
        this.f1425w = (int) TypedValue.applyDimension(1, (float) this.f1425w, displayMetrics);
        this.f1426x = (int) TypedValue.applyDimension(2, (float) this.f1426x, displayMetrics);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1399b);
        this.f1426x = obtainStyledAttributes.getDimensionPixelSize(0, this.f1426x);
        this.f1427y = obtainStyledAttributes.getColor(1, this.f1427y);
        obtainStyledAttributes.recycle();
        obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.PagerSlidingTabStrip);
        this.f1415m = obtainStyledAttributes.getColor(0, this.f1415m);
        this.f1416n = obtainStyledAttributes.getColor(1, this.f1416n);
        this.f1417o = obtainStyledAttributes.getColor(2, this.f1417o);
        this.f1421s = obtainStyledAttributes.getDimensionPixelSize(3, this.f1421s);
        this.f1422t = obtainStyledAttributes.getDimensionPixelSize(4, this.f1422t);
        this.f1423u = obtainStyledAttributes.getDimensionPixelSize(5, this.f1423u);
        this.f1424v = obtainStyledAttributes.getDimensionPixelSize(6, this.f1424v);
        this.f1402C = obtainStyledAttributes.getResourceId(8, this.f1402C);
        this.f1418p = obtainStyledAttributes.getBoolean(9, this.f1418p);
        this.f1420r = obtainStyledAttributes.getDimensionPixelSize(7, this.f1420r);
        this.f1419q = obtainStyledAttributes.getBoolean(10, this.f1419q);
        obtainStyledAttributes.recycle();
        this.f1413k = new Paint();
        this.f1413k.setAntiAlias(true);
        this.f1413k.setStyle(Style.FILL);
        this.f1414l = new Paint();
        this.f1414l.setAntiAlias(true);
        this.f1414l.setStrokeWidth((float) this.f1425w);
        this.f1405c = new LayoutParams(-2, -1);
        this.f1406d = new LayoutParams(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        if (this.f1403D == null) {
            this.f1403D = getResources().getConfiguration().locale;
        }
    }

    public void setViewPager(ViewPager viewPager) {
        this.f1409g = viewPager;
        if (viewPager.getAdapter() == null) {
            throw new IllegalStateException("ViewPager does not have adapter instance.");
        }
        viewPager.setOnPageChangeListener(this.f1407e);
        m1186a();
    }

    public void setOnPageChangeListener(OnPageChangeListener onPageChangeListener) {
        this.f1404a = onPageChangeListener;
    }

    private void m1186a() {
        this.f1408f.removeAllViews();
        this.f1410h = this.f1409g.getAdapter().getCount();
        for (int i = 0; i < this.f1410h; i++) {
            View imageButton;
            if (this.f1409g.getAdapter() instanceof C0544a) {
                int a = ((C0544a) this.f1409g.getAdapter()).m1182a();
                imageButton = new ImageButton(getContext());
                imageButton.setImageResource(a);
                m1187a(i, imageButton);
            } else {
                CharSequence charSequence = this.f1409g.getAdapter().getPageTitle(i).toString();
                imageButton = new TextView(getContext());
                imageButton.setText(charSequence);
                imageButton.setGravity(17);
                imageButton.setSingleLine();
                m1187a(i, imageButton);
            }
        }
        m1190b();
        getViewTreeObserver().addOnGlobalLayoutListener(new C05411(this));
    }

    private void m1187a(final int i, View view) {
        view.setFocusable(true);
        view.setOnClickListener(new OnClickListener(this) {
            final /* synthetic */ PagerSlidingTabStrip f1396b;

            public final void onClick(View view) {
                this.f1396b.f1409g.setCurrentItem(i);
            }
        });
        view.setPadding(this.f1424v, 0, this.f1424v, 0);
        this.f1408f.addView(view, i, this.f1418p ? this.f1406d : this.f1405c);
    }

    private void m1190b() {
        for (int i = 0; i < this.f1410h; i++) {
            View childAt = this.f1408f.getChildAt(i);
            childAt.setBackgroundResource(this.f1402C);
            if (childAt instanceof TextView) {
                TextView textView = (TextView) childAt;
                textView.setTextSize(0, (float) this.f1426x);
                textView.setTypeface(this.f1428z, this.f1400A);
                textView.setTextColor(this.f1427y);
                if (this.f1419q) {
                    if (VERSION.SDK_INT >= 14) {
                        textView.setAllCaps(true);
                    } else {
                        textView.setText(textView.getText().toString().toUpperCase(this.f1403D));
                    }
                }
            }
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!isInEditMode() && this.f1410h != 0) {
            int height = getHeight();
            this.f1413k.setColor(this.f1415m);
            View childAt = this.f1408f.getChildAt(this.f1411i);
            float left = (float) childAt.getLeft();
            float right = (float) childAt.getRight();
            if (this.f1412j > 0.0f && this.f1411i < this.f1410h - 1) {
                childAt = this.f1408f.getChildAt(this.f1411i + 1);
                float left2 = (float) childAt.getLeft();
                left = (left * (DefaultRetryPolicy.DEFAULT_BACKOFF_MULT - this.f1412j)) + (left2 * this.f1412j);
                right = (((float) childAt.getRight()) * this.f1412j) + ((DefaultRetryPolicy.DEFAULT_BACKOFF_MULT - this.f1412j) * right);
            }
            canvas.drawRect(left, (float) (height - this.f1421s), right, (float) height, this.f1413k);
            this.f1413k.setColor(this.f1416n);
            canvas.drawRect(0.0f, (float) (height - this.f1422t), (float) this.f1408f.getWidth(), (float) height, this.f1413k);
            this.f1414l.setColor(this.f1417o);
            for (int i = 0; i < this.f1410h - 1; i++) {
                childAt = this.f1408f.getChildAt(i);
                canvas.drawLine((float) childAt.getRight(), (float) this.f1423u, (float) childAt.getRight(), (float) (height - this.f1423u), this.f1414l);
            }
        }
    }

    public void setIndicatorColor(int i) {
        this.f1415m = i;
        invalidate();
    }

    public void setIndicatorColorResource(int i) {
        this.f1415m = getResources().getColor(i);
        invalidate();
    }

    public int getIndicatorColor() {
        return this.f1415m;
    }

    public void setIndicatorHeight(int i) {
        this.f1421s = i;
        invalidate();
    }

    public int getIndicatorHeight() {
        return this.f1421s;
    }

    public void setUnderlineColor(int i) {
        this.f1416n = i;
        invalidate();
    }

    public void setUnderlineColorResource(int i) {
        this.f1416n = getResources().getColor(i);
        invalidate();
    }

    public int getUnderlineColor() {
        return this.f1416n;
    }

    public void setDividerColor(int i) {
        this.f1417o = i;
        invalidate();
    }

    public void setDividerColorResource(int i) {
        this.f1417o = getResources().getColor(i);
        invalidate();
    }

    public int getDividerColor() {
        return this.f1417o;
    }

    public void setUnderlineHeight(int i) {
        this.f1422t = i;
        invalidate();
    }

    public int getUnderlineHeight() {
        return this.f1422t;
    }

    public void setDividerPadding(int i) {
        this.f1423u = i;
        invalidate();
    }

    public int getDividerPadding() {
        return this.f1423u;
    }

    public void setScrollOffset(int i) {
        this.f1420r = i;
        invalidate();
    }

    public int getScrollOffset() {
        return this.f1420r;
    }

    public void setShouldExpand(boolean z) {
        this.f1418p = z;
        requestLayout();
    }

    public boolean getShouldExpand() {
        return this.f1418p;
    }

    public void setAllCaps(boolean z) {
        this.f1419q = z;
    }

    public void setTextSize(int i) {
        this.f1426x = i;
        m1190b();
    }

    public int getTextSize() {
        return this.f1426x;
    }

    public void setTextColor(int i) {
        this.f1427y = i;
        m1190b();
    }

    public void setTextColorResource(int i) {
        this.f1427y = getResources().getColor(i);
        m1190b();
    }

    public int getTextColor() {
        return this.f1427y;
    }

    public void setTabBackground(int i) {
        this.f1402C = i;
    }

    public int getTabBackground() {
        return this.f1402C;
    }

    public void setTabPaddingLeftRight(int i) {
        this.f1424v = i;
        m1190b();
    }

    public int getTabPaddingLeftRight() {
        return this.f1424v;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f1411i = savedState.f1397a;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.f1397a = this.f1411i;
        return savedState;
    }

    static /* synthetic */ void m1188a(PagerSlidingTabStrip pagerSlidingTabStrip, int i, int i2) {
        if (pagerSlidingTabStrip.f1410h != 0) {
            int left = pagerSlidingTabStrip.f1408f.getChildAt(i).getLeft() + i2;
            if (i > 0 || i2 > 0) {
                left -= pagerSlidingTabStrip.f1420r;
            }
            if (left != pagerSlidingTabStrip.f1401B) {
                pagerSlidingTabStrip.f1401B = left;
                pagerSlidingTabStrip.scrollTo(left, 0);
            }
        }
    }
}
