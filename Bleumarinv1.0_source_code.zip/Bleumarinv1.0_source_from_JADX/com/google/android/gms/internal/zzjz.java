package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;

public interface zzjz extends MediationBannerAdapter {
    Bundle zzeH();
}
