package com.google.android.gms.internal;

@zzhb
public class zzbz {
    private final long zzxv;
    private final String zzxw;
    private final zzbz zzxx;

    public zzbz(long j, String str, zzbz com_google_android_gms_internal_zzbz) {
        this.zzxv = j;
        this.zzxw = str;
        this.zzxx = com_google_android_gms_internal_zzbz;
    }

    long getTime() {
        return this.zzxv;
    }

    String zzdy() {
        return this.zzxw;
    }

    zzbz zzdz() {
        return this.zzxx;
    }
}
