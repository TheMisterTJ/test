package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzx;
import com.google.android.gms.measurement.zze;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class zzkd extends zze<zzkd> {
    private final Map<String, Object> zzxA = new HashMap();

    private String zzaW(String str) {
        zzx.zzcM(str);
        if (str != null && str.startsWith("&")) {
            str = str.substring(1);
        }
        zzx.zzh(str, "Name can not be empty or \"&\"");
        return str;
    }

    public final void set(String str, String str2) {
        this.zzxA.put(zzaW(str), str2);
    }

    public final String toString() {
        return zze.zzF(this.zzxA);
    }

    public final void zza(zzkd com_google_android_gms_internal_zzkd) {
        zzx.zzz(com_google_android_gms_internal_zzkd);
        com_google_android_gms_internal_zzkd.zzxA.putAll(this.zzxA);
    }

    public final Map<String, Object> zziR() {
        return Collections.unmodifiableMap(this.zzxA);
    }
}
